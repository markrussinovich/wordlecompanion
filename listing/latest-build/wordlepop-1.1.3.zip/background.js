var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// src/utils/mergeGames.ts
function mergeGames(existing, incoming) {
  const defined = Object.fromEntries(
    Object.entries(incoming).filter(
      ([, value]) => value !== void 0 && value !== null
    )
  );
  const merged = { ...existing, ...defined };
  if (!incoming.attempts && existing.attempts) {
    merged.attempts = existing.attempts;
    merged.guesses = existing.guesses;
    merged.won = existing.won;
  }
  if (!incoming.guessPattern?.length && existing.guessPattern?.length) {
    merged.guessPattern = existing.guessPattern;
  }
  merged.hardMode = existing.hardMode || incoming.hardMode;
  return merged;
}

// src/extension/utils/logger.ts
var g = globalThis;
function resolveEnvFlag() {
  try {
    if (typeof import.meta !== "undefined" && import.meta?.env) {
      const val = import.meta.env.VITE_DEBUG_LOGS;
      if (val != null) return val === "true" || val === true;
    }
  } catch {
  }
  try {
    if (typeof process !== "undefined" && process?.env) {
      const v = process.env.VITE_DEBUG_LOGS;
      if (v != null) return v === "true";
    }
  } catch {
  }
  return false;
}
function resolveStorageFlag() {
  try {
    return localStorage.getItem("WORDLE_DEBUG_LOGS") === "true";
  } catch {
    return false;
  }
}
var enabled = resolveEnvFlag() || resolveStorageFlag();
function setDebugLogging(on) {
  enabled = on;
  try {
    localStorage.setItem("WORDLE_DEBUG_LOGS", on ? "true" : "false");
  } catch {
  }
}
g.WORDLE_ENABLE_DEBUG_LOGS = () => setDebugLogging(true);
g.WORDLE_DISABLE_DEBUG_LOGS = () => setDebugLogging(false);
function prefix() {
  return `[${(/* @__PURE__ */ new Date()).toISOString()}]`;
}
function build(method) {
  return (...args) => {
    if (enabled) console[method](prefix(), ...args);
  };
}
var logger = {
  enabled: () => enabled,
  log: build("log"),
  warn: build("warn"),
  error: build("error")
};
var logger_default = logger;

// src/extension/background/extensionStorage.ts
var log = logger_default.log;
var errorLog = logger_default.error;
var _ExtensionStorage = class _ExtensionStorage {
  constructor() {
    __publicField(this, "writeQueue", Promise.resolve());
  }
  static getInstance() {
    if (!_ExtensionStorage.instance) {
      _ExtensionStorage.instance = new _ExtensionStorage();
    }
    return _ExtensionStorage.instance;
  }
  async initialize() {
    log("[ExtensionStorage] Initialized");
  }
  async getAllGames() {
    try {
      const result = await chrome.storage.local.get("games");
      return result.games || [];
    } catch (error) {
      errorLog("[ExtensionStorage] Failed to get games:", error);
      throw error;
    }
  }
  async saveGame(game) {
    const result = await this.bulkImportGames([game]);
    if (result.errors) throw new Error("Game could not be saved");
  }
  async updateReaderAverage(date, readers, hardMode) {
    const operation = this.writeQueue.then(async () => {
      const games = await this.getAllGames();
      const index = games.findIndex((game2) => game2.date === date);
      const game = games[index];
      if (!game) return null;
      if (readers.nytReaderMode !== (hardMode ?? game.hardMode ? "hard" : "normal")) {
        return game;
      }
      const unchanged = (game.nytReaderSource === "manual" || game.nytReaderAverage === readers.nytReaderAverage && game.nytReaderMode === readers.nytReaderMode && game.nytReaderSource === readers.nytReaderSource) && (hardMode === void 0 || game.hardMode === hardMode);
      if (unchanged) return game;
      games[index] = {
        ...game,
        ...game.nytReaderSource === "manual" ? {} : readers,
        ...hardMode !== void 0 ? { hardMode } : {}
      };
      await chrome.storage.local.set({ games });
      return games[index];
    });
    this.writeQueue = operation.catch(() => void 0);
    return operation;
  }
  async bulkImportGames(newGames) {
    const operation = this.writeQueue.then(() => this.importGames(newGames));
    this.writeQueue = operation.catch(() => void 0);
    return operation;
  }
  async importGames(newGames) {
    log(`[ExtensionStorage] =====> bulkImportGames called with ${newGames.length} games`);
    let imported = 0;
    let duplicates = 0;
    let errors = 0;
    try {
      log(`[ExtensionStorage] =====> Reading existing games...`);
      const startRead = performance.now();
      const existingGames = await this.getAllGames();
      log(`[ExtensionStorage] =====> Read ${existingGames.length} existing games in ${(performance.now() - startRead).toFixed(0)}ms`);
      const gameMap = /* @__PURE__ */ new Map();
      existingGames.forEach((game) => {
        gameMap.set(game.date, game);
      });
      log(`[ExtensionStorage] =====> Processing ${newGames.length} new games...`);
      for (const game of newGames) {
        try {
          if (!/^\d{4}-\d{2}-\d{2}$/.test(game.date) || !Number.isFinite(Date.parse(game.date)) || new Date(game.date).toISOString().slice(0, 10) !== game.date) {
            throw new Error("Invalid game date");
          }
          const existing = gameMap.get(game.date);
          if (existing) {
            const merged = mergeGames(existing, game);
            const meaningful = (value) => JSON.stringify({
              ...value,
              importedAt: void 0,
              boardImageUrl: void 0
            });
            const shouldReplace = meaningful(merged) !== meaningful(existing);
            if (shouldReplace) {
              gameMap.set(game.date, merged);
              imported++;
            } else {
              duplicates++;
            }
          } else {
            gameMap.set(game.date, game);
            imported++;
          }
        } catch (error) {
          errorLog("[ExtensionStorage] Failed to process game:", game.date, error);
          errors++;
        }
      }
      log(`[ExtensionStorage] =====> Writing ${gameMap.size} total games to storage...`);
      const startWrite = performance.now();
      const allGames = Array.from(gameMap.values());
      log(`[ExtensionStorage] =====> Stripping board images from ${allGames.length} games...`);
      const lightweightGames = allGames.map((g2) => ({
        ...g2,
        boardImageUrl: void 0
        // Strip large base64 data URLs
      }));
      log(`[ExtensionStorage] =====> Calling chrome.storage.local.set...`);
      await chrome.storage.local.set({ games: lightweightGames });
      log(`[ExtensionStorage] =====> Write completed in ${(performance.now() - startWrite).toFixed(0)}ms`);
    } catch (error) {
      console.error("[ExtensionStorage] Bulk import failed:", error);
      throw error;
    }
    log(`[ExtensionStorage] =====> bulkImportGames complete: imported=${imported}, duplicates=${duplicates}, errors=${errors}`);
    return { imported, duplicates, errors };
  }
  async getNewestGame() {
    try {
      const games = await this.getAllGames();
      if (games.length === 0) return null;
      return games.reduce((newest, game) => {
        return new Date(game.date) > new Date(newest.date) ? game : newest;
      });
    } catch (error) {
      console.error("[ExtensionStorage] Failed to get newest game:", error);
      return null;
    }
  }
  async getScraperMetadata() {
    try {
      const result = await chrome.storage.local.get("scraperMetadata");
      const metadata = result.scraperMetadata || {};
      return {
        lastScrape: metadata.lastScrape || null,
        lastScrapeMode: metadata.lastScrapeMode || null,
        totalScraped: metadata.totalScraped || 0,
        lastError: metadata.lastError || null
      };
    } catch (error) {
      console.error("[ExtensionStorage] Failed to get scraper metadata:", error);
      return {
        lastScrape: null,
        lastScrapeMode: null,
        totalScraped: 0,
        lastError: null
      };
    }
  }
  async updateScraperMetadata(update) {
    try {
      const current = await this.getScraperMetadata();
      const newMetadata = {
        lastScrape: update.lastScrape || current.lastScrape,
        lastScrapeMode: update.lastScrapeMode || current.lastScrapeMode,
        totalScraped: update.totalScraped !== void 0 ? update.totalScraped : current.totalScraped,
        lastError: update.lastError !== void 0 ? update.lastError : current.lastError
      };
      await chrome.storage.local.set({ scraperMetadata: newMetadata });
    } catch (error) {
      console.error("[ExtensionStorage] Failed to update scraper metadata:", error);
    }
  }
  async getPreferences() {
    try {
      const result = await chrome.storage.sync.get("preferences");
      return result.preferences || null;
    } catch (error) {
      console.error("[ExtensionStorage] Failed to get preferences:", error);
      return null;
    }
  }
};
__publicField(_ExtensionStorage, "instance");
var ExtensionStorage = _ExtensionStorage;

// src/utils/nytReaderAverage.ts
function parseNytReaderAverage(summary, hardMode) {
  const mode = hardMode ? "hard" : "normal";
  const counts = (summary?.botUserSteps ?? summary?.steps)?.[mode];
  if (!Array.isArray(counts) || counts.length !== 7 || !counts.every((count) => Number.isSafeInteger(count) && count >= 0))
    return null;
  const total = counts.reduce((sum, count) => sum + count, 0);
  const penalty = summary.unsolvedPenalty?.[mode] ?? 0;
  if (!total || !Number.isFinite(penalty) || penalty < 0) return null;
  const average = (counts.reduce((sum, count, index) => sum + count * (index + 1), 0) + penalty) / total;
  if (!Number.isFinite(average) || average < 1 || average > 7) return null;
  return {
    nytReaderAverage: average,
    nytReaderMode: mode,
    nytReaderSource: "wordlebot"
  };
}
var summaries = /* @__PURE__ */ new Map();
async function fetchNytReaderAverage(game) {
  const solution = game.solution?.trim().toLowerCase();
  if (!solution || !/^[a-z]{5}$/.test(solution) || !/^\d{4}-\d{2}-\d{2}$/.test(game.date) || !Number.isFinite(Date.parse(game.date)) || new Date(game.date).toISOString().slice(0, 10) !== game.date)
    return null;
  const key = `${solution}-${game.date}`;
  let cached = summaries.get(key);
  if (!cached || cached.expires < Date.now()) {
    const data = (async () => {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5e3);
      try {
        const response = await fetch(
          `https://static01.nyt.com/newsgraphics/2022/wordlebot/${key}/summary.json`,
          { credentials: "omit", signal: controller.signal }
        );
        if (!response.ok) return null;
        return await response.json();
      } catch {
        return null;
      } finally {
        clearTimeout(timeout);
      }
    })();
    cached = { expires: Date.now() + 5 * 60 * 1e3, data };
    summaries.set(key, cached);
  }
  return parseNytReaderAverage(await cached.data, game.hardMode);
}

// src/solver/data/words.json
var words_default = ["AAHED", "AALII", "AARGH", "AARON", "ABACA", "ABACI", "ABACK", "ABADA", "ABAFF", "ABAFT", "ABAKA", "ABAMA", "ABAMP", "ABAND", "ABASE", "ABASH", "ABASK", "ABATE", "ABAUE", "ABAVE", "ABAZE", "ABBAS", "ABBES", "ABBEY", "ABBIE", "ABBOT", "ABDAL", "ABDAT", "ABDOM", "ABEAM", "ABEAR", "ABEDE", "ABELE", "ABEND", "ABERR", "ABETS", "ABHOR", "ABIDE", "ABIDI", "ABIES", "ABILO", "ABIME", "ABKAR", "ABLED", "ABLER", "ABLES", "ABLET", "ABLOW", "ABMHO", "ABNER", "ABNET", "ABODE", "ABODY", "ABOHM", "ABOIL", "ABOMA", "ABOON", "ABORD", "ABORT", "ABOTE", "ABOUT", "ABOVE", "ABRAM", "ABRAY", "ABRET", "ABRIM", "ABRIN", "ABRIS", "ABRUS", "ABSEE", "ABSEY", "ABSIS", "ABSIT", "ABSTR", "ABUNA", "ABUNE", "ABURA", "ABUSE", "ABUSH", "ABUTA", "ABUTS", "ABUZZ", "ABWAB", "ABYES", "ABYSM", "ABYSS", "ACALE", "ACANA", "ACAPU", "ACARA", "ACARI", "ACAST", "ACATE", "ACCEL", "ACCOY", "ACCRA", "ACCTS", "ACCUM", "ACCUR", "ACCUS", "ACEDY", "ACERB", "ACETA", "ACHAR", "ACHED", "ACHEN", "ACHER", "ACHES", "ACHOO", "ACHOR", "ACIDS", "ACIDY", "ACIER", "ACIES", "ACING", "ACINI", "ACKEE", "ACKER", "ACKEY", "ACLYS", "ACMES", "ACMIC", "ACNED", "ACNES", "ACOCK", "ACOIN", "ACOLD", "ACOMA", "ACONE", "ACOOL", "ACORN", "ACOST", "ACOUP", "ACRAB", "ACRED", "ACRES", "ACRID", "ACROA", "ACRON", "ACRUX", "ACRYL", "ACTED", "ACTIN", "ACTON", "ACTOR", "ACTOS", "ACTUS", "ACUAN", "ACUTE", "ACYLS", "ADAGE", "ADAGY", "ADAMS", "ADAPA", "ADAPT", "ADATI", "ADATY", "ADAWE", "ADAWN", "ADAYS", "ADCON", "ADDAX", "ADDDA", "ADDED", "ADDER", "ADDIE", "ADDIO", "ADDIS", "ADDLE", "ADDNL", "ADEAD", "ADEEM", "ADEEP", "ADELA", "ADEPS", "ADEPT", "ADFIX", "ADIEL", "ADIEU", "ADION", "ADIOS", "ADITS", "ADJAG", "ADLAI", "ADLAY", "ADLET", "ADMAN", "ADMEN", "ADMIN", "ADMIT", "ADMIX", "ADMOV", "ADMRX", "ADNEX", "ADOBE", "ADOBO", "ADOLF", "ADOPT", "ADORE", "ADORN", "ADOWN", "ADOXA", "ADOXY", "ADOZE", "ADPAO", "ADRAD", "ADRET", "ADRIP", "ADROP", "ADRUE", "ADSUM", "ADULT", "ADUNC", "ADURE", "ADUSK", "ADUST", "ADYTA", "ADZER", "ADZES", "AECIA", "AEDES", "AEGER", "AEGIR", "AEGIS", "AEGLE", "AEONS", "AEQUI", "AERIC", "AERIE", "AERON", "AESIR", "AESOP", "AETAT", "AEVIA", "AEVUM", "AFACE", "AFARA", "AFARS", "AFEAR", "AFFIX", "AFGOD", "AFIFI", "AFIRE", "AFLAT", "AFLEY", "AFLOW", "AFOAM", "AFOOT", "AFORE", "AFOUL", "AFRAY", "AFRET", "AFRIC", "AFRIT", "AFROS", "AFTER", "AGADA", "AGADE", "AGAIN", "AGAMA", "AGAMI", "AGAMY", "AGAPE", "AGARS", "AGASP", "AGAST", "AGATA", "AGATE", "AGATY", "AGAVE", "AGAZE", "AGENA", "AGEND", "AGENE", "AGENT", "AGERS", "AGETE", "AGGER", "AGGIE", "AGGRO", "AGGRY", "AGGUR", "AGHAN", "AGHAS", "AGIEL", "AGILE", "AGING", "AGIOS", "AGISM", "AGIST", "AGLEE", "AGLET", "AGLEY", "AGLOW", "AGMAS", "AGNAT", "AGNEL", "AGNES", "AGNUS", "AGOGE", "AGOHO", "AGONE", "AGONS", "AGONY", "AGORA", "AGRAH", "AGRAL", "AGREE", "AGRIA", "AGRIC", "AGRIN", "AGROM", "AGRON", "AGSAM", "AGUES", "AGUEY", "AGURA", "AGUSH", "AGUST", "AHEAD", "AHEAP", "AHEMS", "AHIND", "AHINT", "AHMED", "AHMET", "AHOLD", "AHOLT", "AHONG", "AHSAN", "AHULL", "AHUNT", "AHURA", "AHUSH", "AHWAL", "AIDED", "AIDER", "AIDES", "AIERY", "AIGER", "AIGRE", "AILED", "AILIE", "AILLT", "AIMAK", "AIMED", "AIMEE", "AIMER", "AINEE", "AINOI", "AINUS", "AIOLI", "AIRAN", "AIRED", "AIRER", "AIRNS", "AIRTH", "AIRTS", "AISLE", "AITCH", "AITIS", "AIVER", "AIWAN", "AIZLE", "AJAJA", "AJARI", "AJAVA", "AJHAR", "AJIVA", "AJUGA", "AKALA", "AKALI", "AKASA", "AKEBI", "AKEES", "AKEKI", "AKELA", "AKENE", "AKING", "AKKAD", "AKNEE", "AKNOW", "AKPEK", "AKRON", "AKULE", "AKUND", "ALACK", "ALADA", "ALAIN", "ALAKI", "ALALA", "ALAMO", "ALAND", "ALANE", "ALANG", "ALANI", "ALANS", "ALANT", "ALAPA", "ALARM", "ALARY", "ALATE", "ALAWI", "ALBAN", "ALBAS", "ALBEE", "ALBIN", "ALBUM", "ALBUS", "ALBYN", "ALCAE", "ALCES", "ALCID", "ALCOR", "ALDAY", "ALDEA", "ALDEN", "ALDER", "ALDIM", "ALDOL", "ALDUS", "ALEAK", "ALECK", "ALECS", "ALEFS", "ALEFT", "ALENU", "ALEPH", "ALERT", "ALEUT", "ALFAS", "ALFET", "ALFIN", "ALFUR", "ALGAE", "ALGAL", "ALGAS", "ALGIC", "ALGID", "ALGIN", "ALGOL", "ALGOR", "ALGUM", "ALHET", "ALIAS", "ALIBI", "ALICE", "ALICK", "ALIDA", "ALIDS", "ALIEN", "ALIET", "ALIFE", "ALIFS", "ALIGN", "ALIKE", "ALIMA", "ALINE", "ALISH", "ALISO", "ALISP", "ALIST", "ALITE", "ALITY", "ALIVE", "ALIYA", "ALKES", "ALKIN", "ALKYD", "ALKYL", "ALLAH", "ALLAN", "ALLAY", "ALLEN", "ALLER", "ALLEY", "ALLEZ", "ALLIE", "ALLIS", "ALLOD", "ALLOO", "ALLOT", "ALLOW", "ALLOY", "ALLYL", "ALMAH", "ALMAN", "ALMAS", "ALMEH", "ALMES", "ALMON", "ALMUD", "ALMUG", "ALNUS", "ALODY", "ALOED", "ALOES", "ALOFT", "ALOGY", "ALOHA", "ALOID", "ALOIN", "ALOIS", "ALOMA", "ALONE", "ALONG", "ALOOF", "ALOSA", "ALOSE", "ALOUD", "ALOUT", "ALOWE", "ALPAX", "ALPEN", "ALPHA", "ALPID", "ALTAR", "ALTER", "ALTHO", "ALTIN", "ALTOS", "ALTUN", "ALTUS", "ALUCO", "ALULA", "ALUMS", "ALURE", "ALUTA", "ALVAH", "ALVAN", "ALVAR", "ALVIA", "ALVIN", "ALVUS", "ALWAY", "AMAAS", "AMADI", "AMAGA", "AMAHS", "AMAIN", "AMALA", "AMALG", "AMANG", "AMANI", "AMANT", "AMAPA", "AMARA", "AMASS", "AMATE", "AMATI", "AMAUT", "AMAZE", "AMBAN", "AMBAR", "AMBAS", "AMBAY", "AMBER", "AMBIT", "AMBLE", "AMBON", "AMBOS", "AMBRY", "AMEBA", "AMEED", "AMEEN", "AMEER", "AMELU", "AMEND", "AMENE", "AMENS", "AMENT", "AMESS", "AMHAR", "AMIAS", "AMICE", "AMICI", "AMIDE", "AMIDO", "AMIDS", "AMIES", "AMIGA", "AMIGO", "AMINE", "AMINI", "AMINO", "AMINS", "AMIRE", "AMIRS", "AMISH", "AMISS", "AMITA", "AMITY", "AMLET", "AMMAN", "AMMER", "AMMOS", "AMNIA", "AMNIC", "AMOKE", "AMOKS", "AMOLE", "AMONG", "AMORA", "AMORT", "AMOUR", "AMOVE", "AMOWT", "AMPER", "AMPHI", "AMPLE", "AMPLY", "AMPUL", "AMPYX", "AMRIT", "AMSEL", "AMUCK", "AMULA", "AMUSE", "AMUZE", "AMVIS", "AMYLO", "AMYLS", "AMZEL", "ANABO", "ANACK", "ANAMA", "ANANA", "ANASA", "ANCHA", "ANCLE", "ANCON", "ANCOR", "ANCRE", "ANDES", "ANDIA", "ANDOR", "ANDRE", "ANEAR", "ANELE", "ANEND", "ANENT", "ANGAS", "ANGEL", "ANGER", "ANGIA", "ANGIE", "ANGKA", "ANGLE", "ANGLO", "ANGOR", "ANGRY", "ANGST", "ANGUS", "ANHYD", "ANIBA", "ANICE", "ANIGH", "ANILE", "ANILS", "ANIMA", "ANIME", "ANIMI", "ANIMO", "ANION", "ANISE", "ANITA", "ANJAN", "ANJOU", "ANKEE", "ANKER", "ANKHS", "ANKLE", "ANKOU", "ANKUS", "ANLAS", "ANLET", "ANLIA", "ANMIA", "ANNAL", "ANNAM", "ANNAS", "ANNAT", "ANNET", "ANNEX", "ANNIE", "ANNIV", "ANNOT", "ANNOY", "ANNUL", "ANNUM", "ANNUS", "ANOAS", "ANODE", "ANOIA", "ANOIL", "ANOLE", "ANOLI", "ANOMY", "ANORN", "ANOUR", "ANOUS", "ANOVA", "ANSAE", "ANSAR", "ANSEL", "ANSER", "ANTAE", "ANTAL", "ANTAR", "ANTAS", "ANTED", "ANTES", "ANTIC", "ANTIQ", "ANTIS", "ANTON", "ANTRA", "ANTRE", "ANTSY", "ANTUM", "ANURA", "ANURY", "ANVIL", "ANZAC", "AOIFE", "AORTA", "AOTEA", "AOTES", "AOTUS", "AOUAD", "APACE", "APAID", "APAIR", "APAMA", "APART", "APASS", "APAST", "APEAK", "APEEK", "APERS", "APERT", "APERU", "APERY", "APHID", "APHIS", "APHRA", "APIAN", "APIIN", "APILI", "APINA", "APING", "APIOL", "APIOS", "APISH", "APISM", "APIUM", "APNEA", "APODA", "APODS", "APOOP", "APORT", "APOUT", "APPAL", "APPAR", "APPAY", "APPEL", "APPET", "APPLE", "APPLY", "APPMT", "APPRO", "APPTD", "APPUI", "APRES", "APRIL", "APRON", "APSES", "APSID", "APSIS", "APTAL", "APTER", "APTLY", "AQUAE", "AQUAS", "ARABA", "ARABS", "ARABY", "ARACA", "ARACE", "ARACH", "ARADO", "ARAGE", "ARAIN", "ARAKE", "ARAKS", "ARAMU", "ARANK", "ARARA", "ARARU", "ARASE", "ARATI", "ARAUA", "ARAWA", "ARBER", "ARBOR", "ARCAE", "ARCED", "ARCES", "ARCHD", "ARCHE", "ARCHT", "ARCHY", "ARCOS", "ARCUS", "ARDEA", "ARDEB", "ARDER", "ARDOR", "ARDRI", "AREAD", "AREAE", "AREAL", "AREAN", "AREAR", "AREAS", "ARECA", "AREEK", "AREEL", "AREFY", "AREIC", "ARENA", "AREND", "ARENG", "ARENT", "ARERE", "AREST", "ARETE", "ARGAL", "ARGAN", "ARGAS", "ARGEL", "ARGID", "ARGIL", "ARGIN", "ARGLE", "ARGOL", "ARGON", "ARGOS", "ARGOT", "ARGUE", "ARGUS", "ARHAR", "ARHAT", "ARIAN", "ARIAS", "ARIEL", "ARIES", "ARIKI", "ARILS", "ARIOI", "ARION", "ARIOT", "ARISE", "ARISH", "ARIST", "ARITE", "ARITH", "ARIUS", "ARJUN", "ARKAB", "ARKIE", "ARLES", "ARMED", "ARMER", "ARMET", "ARMIL", "ARMIT", "ARMOR", "ARNEB", "ARNEE", "ARNUT", "AROAR", "AROCK", "AROID", "AROMA", "AROON", "AROPH", "AROSE", "ARPEN", "ARRAH", "ARRAS", "ARRAU", "ARRAY", "ARRET", "ARRGT", "ARRHA", "ARRIE", "ARRIS", "ARROW", "ARROZ", "ARSES", "ARSIS", "ARSLE", "ARSON", "ARSYL", "ARTAL", "ARTAR", "ARTEL", "ARTER", "ARTHA", "ARTIC", "ARTIE", "ARTLY", "ARTOU", "ARTSY", "ARTUS", "ARUAC", "ARUKE", "ARULO", "ARUMS", "ARUPA", "ARUSA", "ARVAL", "ARVEL", "ARVOS", "ARYAN", "ARYLS", "ARZAN", "ARZUN", "ASALE", "ASANA", "ASAPH", "ASARH", "ASCAN", "ASCII", "ASCON", "ASCOT", "ASCRY", "ASCUS", "ASDIC", "ASGMT", "ASHED", "ASHEN", "ASHER", "ASHES", "ASHET", "ASHIR", "ASHOT", "ASHUR", "ASIAN", "ASIDE", "ASKAR", "ASKED", "ASKER", "ASKEW", "ASKIP", "ASKOI", "ASKOS", "ASLOP", "ASOAK", "ASOKA", "ASPCA", "ASPEN", "ASPER", "ASPIC", "ASPIS", "ASSAI", "ASSAM", "ASSAY", "ASSES", "ASSET", "ASSIS", "ASSOC", "ASSOT", "ASTAY", "ASTEL", "ASTER", "ASTIR", "ASTOR", "ASTRE", "ASTUR", "ASURI", "ASWAY", "ASWIM", "ASYLA", "ASYLE", "ASYNC", "ATAKE", "ATAME", "ATAVI", "ATAXY", "ATEBA", "ATEES", "ATELO", "ATELY", "ATHAR", "ATHEL", "ATILT", "ATIMY", "ATING", "ATLAS", "ATLEE", "ATMAN", "ATMAS", "ATMID", "ATMOS", "ATNAH", "ATOKE", "ATOLE", "ATOLL", "ATOMS", "ATOMY", "ATONE", "ATONY", "ATOPY", "ATOUR", "ATREN", "ATRIA", "ATRIP", "ATTAL", "ATTAR", "ATTER", "ATTIC", "ATTID", "ATTLE", "ATTRY", "ATULE", "ATUNE", "ATWIN", "ATYPY", "AUBIN", "AUCAN", "AUCHT", "AUDAD", "AUDIO", "AUDIT", "AUETO", "AUGEN", "AUGER", "AUGET", "AUGHT", "AUGUR", "AULAE", "AULAS", "AULIC", "AULOI", "AULOS", "AUMIL", "AUNTS", "AUNTY", "AURAE", "AURAL", "AURAR", "AURAS", "AUREI", "AURES", "AURIC", "AURIN", "AURIR", "AURIS", "AURUM", "AURYL", "AUTEM", "AUTOR", "AUTOS", "AUTRE", "AUXIL", "AUXIN", "AVAHI", "AVAIL", "AVALE", "AVANT", "AVARS", "AVAST", "AVELL", "AVENA", "AVENS", "AVENY", "AVERA", "AVERN", "AVERS", "AVERT", "AVERY", "AVGAS", "AVIAN", "AVICK", "AVIEW", "AVILE", "AVINE", "AVION", "AVISO", "AVOID", "AVOIR", "AVOKE", "AVOUE", "AVOUR", "AVOWE", "AVOWS", "AWABI", "AWACS", "AWAFT", "AWAIT", "AWAKE", "AWALD", "AWALT", "AWANE", "AWARD", "AWARE", "AWARN", "AWASH", "AWAVE", "AWAYS", "AWBER", "AWEEK", "AWEEL", "AWEST", "AWETO", "AWFUL", "AWHET", "AWHIR", "AWIDE", "AWING", "AWINK", "AWIWI", "AWKLY", "AWNED", "AWNER", "AWOKE", "AWOLS", "AWORK", "AXELS", "AXERS", "AXIAL", "AXILE", "AXILS", "AXINE", "AXING", "AXIOM", "AXION", "AXITE", "AXLED", "AXLES", "AXMAN", "AXMEN", "AXOID", "AXONE", "AXONS", "AYAHS", "AYELP", "AYENS", "AYINS", "AYLET", "AYLLU", "AYOND", "AYONT", "AYOUS", "AYUYU", "AZANS", "AZIDE", "AZIDO", "AZINE", "AZLON", "AZOCH", "AZOFY", "AZOIC", "AZOLE", "AZONS", "AZOTE", "AZOTH", "AZOXY", "AZTEC", "AZURE", "AZURY", "AZYME", "BAAED", "BAALS", "BABAI", "BABAS", "BABBY", "BABEL", "BABES", "BABIS", "BABKA", "BABLE", "BABOO", "BABUA", "BABUL", "BABUS", "BACAO", "BACCA", "BACCY", "BACHE", "BACIN", "BACIS", "BACKS", "BACKY", "BACON", "BADAN", "BADDY", "BADGE", "BADJU", "BADLY", "BADON", "BAFFS", "BAFFY", "BAFTA", "BAGDI", "BAGEL", "BAGGE", "BAGGY", "BAGIE", "BAGIO", "BAGLE", "BAGNE", "BAGRE", "BAHAI", "BAHAM", "BAHAN", "BAHAR", "BAHAY", "BAHOE", "BAHOO", "BAHTS", "BAHUR", "BAHUT", "BAIGN", "BAILE", "BAILO", "BAILS", "BAIOC", "BAIRN", "BAITH", "BAITS", "BAIZA", "BAIZE", "BAJAN", "BAJAU", "BAJRA", "BAJRI", "BAKAL", "BAKED", "BAKEN", "BAKER", "BAKES", "BAKIE", "BAKLI", "BAKRA", "BALAI", "BALAK", "BALAN", "BALAO", "BALAS", "BALAT", "BALAU", "BALDS", "BALDY", "BALED", "BALEI", "BALER", "BALES", "BALKS", "BALKY", "BALLI", "BALLO", "BALLS", "BALLY", "BALMS", "BALMY", "BALON", "BALOO", "BALOR", "BALOW", "BALSA", "BALTI", "BALUN", "BALUT", "BALZA", "BAMAH", "BANAK", "BANAL", "BANAT", "BANBA", "BANCA", "BANCO", "BANDA", "BANDE", "BANDH", "BANDI", "BANDO", "BANDS", "BANDY", "BANED", "BANES", "BANFF", "BANGA", "BANGE", "BANGS", "BANGY", "BANIA", "BANIG", "BANJO", "BANKS", "BANKY", "BANNS", "BANTU", "BANTY", "BANUS", "BANYA", "BARAD", "BARAT", "BARBA", "BARBE", "BARBS", "BARBU", "BARDE", "BARDO", "BARDS", "BARDY", "BARED", "BARER", "BARES", "BARET", "BARFF", "BARFS", "BARFY", "BARGE", "BARGH", "BARIA", "BARIC", "BARID", "BARIE", "BARIH", "BARIS", "BARIT", "BARKS", "BARKY", "BARLY", "BARMS", "BARMY", "BARNS", "BARNY", "BAROI", "BARON", "BARRA", "BARRE", "BARRY", "BARSE", "BARTH", "BARYE", "BASAD", "BASAL", "BASAN", "BASAT", "BASED", "BASER", "BASES", "BASIC", "BASIL", "BASIN", "BASIS", "BASKE", "BASKS", "BASON", "BASOS", "BASSA", "BASSI", "BASSO", "BASSY", "BASTA", "BASTE", "BASTI", "BASTO", "BASTS", "BASYL", "BATAD", "BATAK", "BATAN", "BATCH", "BATEA", "BATED", "BATEL", "BATER", "BATES", "BATHE", "BATHS", "BATIK", "BATIS", "BATON", "BATTA", "BATTS", "BATTU", "BATTY", "BATWA", "BAUBO", "BAUCH", "BAUDS", "BAUGE", "BAULD", "BAULK", "BAUME", "BAUNO", "BAURE", "BAUTA", "BAVIN", "BAWDS", "BAWDY", "BAWKE", "BAWLS", "BAWLY", "BAWRA", "BAWTY", "BAYAL", "BAYED", "BAYOK", "BAYOU", "BAZAR", "BAZOO", "BEACH", "BEADS", "BEADY", "BEAKS", "BEAKY", "BEALA", "BEAMS", "BEAMY", "BEANO", "BEANS", "BEANT", "BEANY", "BEARD", "BEARM", "BEARS", "BEAST", "BEATA", "BEATH", "BEATI", "BEATS", "BEAUS", "BEAUT", "BEAUX", "BEBAR", "BEBAT", "BEBAY", "BEBED", "BEBOG", "BEBOP", "BECAP", "BECCO", "BECHE", "BECKS", "BECKY", "BECRY", "BECUT", "BEDAD", "BEDAY", "BEDEL", "BEDEN", "BEDEW", "BEDIM", "BEDIN", "BEDIP", "BEDOG", "BEDOT", "BEDUB", "BEDUR", "BEDYE", "BEECH", "BEEDI", "BEEFS", "BEEFY", "BEELE", "BEENT", "BEEPS", "BEERS", "BEERY", "BEEST", "BEETH", "BEETS", "BEETY", "BEEVE", "BEFAN", "BEFIT", "BEFOG", "BEFOP", "BEFUR", "BEGAD", "BEGAN", "BEGAR", "BEGAT", "BEGAY", "BEGEM", "BEGET", "BEGIN", "BEGOB", "BEGOD", "BEGOT", "BEGUM", "BEGUN", "BEGUT", "BEHAP", "BEHAV", "BEHEN", "BEHEW", "BEICE", "BEIGE", "BEIGY", "BEILD", "BEING", "BEIRA", "BEISA", "BEJAN", "BEJEL", "BEJIG", "BEKAH", "BEKKO", "BELAH", "BELAM", "BELAP", "BELAR", "BELAT", "BELAY", "BELCH", "BELEE", "BELGA", "BELIE", "BELIS", "BELLA", "BELLE", "BELLI", "BELLO", "BELLS", "BELLY", "BELOW", "BELTS", "BELUE", "BELVE", "BEMAD", "BEMAN", "BEMAR", "BEMAS", "BEMAT", "BEMBA", "BEMIX", "BEMOL", "BEMUD", "BENAB", "BENCH", "BENDA", "BENDS", "BENDY", "BENES", "BENET", "BENIC", "BENIM", "BENIN", "BENJY", "BENNE", "BENNI", "BENNY", "BENSH", "BENTS", "BENTY", "BENZO", "BEODE", "BEPAT", "BEPAW", "BEPEN", "BEPUN", "BERAT", "BERAY", "BERET", "BERGH", "BERGS", "BERGY", "BERME", "BERMS", "BERNE", "BEROB", "BEROE", "BERRI", "BERRY", "BERTH", "BERUN", "BERYL", "BERYX", "BESAN", "BESEE", "BESET", "BESEW", "BESIN", "BESIT", "BESOM", "BESOT", "BESPY", "BESRA", "BESSI", "BESSY", "BESTS", "BETAG", "BETAS", "BETEL", "BETES", "BETHS", "BETIS", "BETON", "BETSO", "BETSY", "BETTA", "BETTY", "BEVEL", "BEVER", "BEVIL", "BEVOR", "BEVUE", "BEVVY", "BEWET", "BEWIG", "BEWIT", "BEWRY", "BEZAN", "BEZEL", "BEZIL", "BEZZI", "BEZZO", "BHAGA", "BHALU", "BHANG", "BHARA", "BHAVA", "BHILI", "BHIMA", "BHOOT", "BHUTS", "BIABO", "BIALI", "BIALY", "BIBBS", "BIBBY", "BIBIO", "BIBLE", "BICEP", "BICES", "BICHY", "BIDAR", "BIDDY", "BIDED", "BIDER", "BIDES", "BIDET", "BIDRI", "BIDRY", "BIELD", "BIENS", "BIERS", "BIFER", "BIFFS", "BIFFY", "BIFID", "BIGAE", "BIGAM", "BIGAS", "BIGGY", "BIGHA", "BIGHT", "BIGLY", "BIGOT", "BIHAI", "BIHAM", "BIJOU", "BIKED", "BIKER", "BIKES", "BIKIE", "BIKOL", "BILBI", "BILBO", "BILBY", "BILCH", "BILES", "BILGE", "BILGY", "BILIC", "BILIN", "BILIO", "BILKS", "BILLA", "BILLS", "BILLY", "BILOS", "BILSH", "BIMAH", "BIMAS", "BIMBO", "BINAL", "BINDI", "BINDS", "BINES", "BINGE", "BINGO", "BINGY", "BINIT", "BINNA", "BINNY", "BINTS", "BIOME", "BIONT", "BIOSE", "BIOTA", "BIPED", "BIPOD", "BIRCH", "BIRDE", "BIRDS", "BIRDY", "BIRKS", "BIRKY", "BIRLE", "BIRLS", "BIRMA", "BIRNE", "BIRNY", "BIRON", "BIRRI", "BIRRS", "BIRSE", "BIRSY", "BIRTH", "BISES", "BISET", "BISIE", "BISKS", "BISME", "BISON", "BISSO", "BISTI", "BITCH", "BITED", "BITER", "BITES", "BITIS", "BITSY", "BITTE", "BITTS", "BITTY", "BIUNE", "BIVVY", "BIXIN", "BIZEL", "BIZEN", "BIZES", "BIZET", "BLABS", "BLACK", "BLADE", "BLADY", "BLAFF", "BLAHS", "BLAIN", "BLAIR", "BLAKE", "BLAME", "BLAMS", "BLANC", "BLAND", "BLANK", "BLARE", "BLART", "BLASE", "BLASH", "BLAST", "BLATE", "BLATS", "BLAWN", "BLAWS", "BLAYK", "BLAZE", "BLAZY", "BLEAK", "BLEAR", "BLEAT", "BLEBS", "BLECK", "BLEED", "BLEEP", "BLEND", "BLENK", "BLENS", "BLENT", "BLERE", "BLESS", "BLEST", "BLETS", "BLIBE", "BLICK", "BLIER", "BLIMP", "BLIMY", "BLIND", "BLINI", "BLINK", "BLINY", "BLIPS", "BLIRT", "BLISS", "BLIST", "BLITE", "BLITZ", "BLIZZ", "BLOAT", "BLOBS", "BLOCK", "BLOCS", "BLOKE", "BLOND", "BLOOD", "BLOOM", "BLOOP", "BLORE", "BLOTE", "BLOTS", "BLOUT", "BLOWN", "BLOWS", "BLOWY", "BLUED", "BLUER", "BLUES", "BLUET", "BLUEY", "BLUFF", "BLUME", "BLUNK", "BLUNT", "BLURB", "BLURS", "BLURT", "BLUSH", "BLYPE", "BOARD", "BOARS", "BOART", "BOAST", "BOATS", "BOBAC", "BOBBY", "BOBET", "BOBOL", "BOCAL", "BOCCA", "BOCCE", "BOCCI", "BOCHE", "BOCKS", "BOCOY", "BODED", "BODEN", "BODER", "BODES", "BODGE", "BODHI", "BODLE", "BOERS", "BOFFO", "BOFFS", "BOGAN", "BOGET", "BOGEY", "BOGGY", "BOGIE", "BOGLE", "BOGUE", "BOGUM", "BOGUS", "BOHEA", "BOHOR", "BOIKO", "BOILS", "BOILY", "BOING", "BOISE", "BOIST", "BOITE", "BOKOM", "BOKOS", "BOLAG", "BOLAR", "BOLAS", "BOLDO", "BOLDU", "BOLED", "BOLES", "BOLIS", "BOLLS", "BOLLY", "BOLOS", "BOLTI", "BOLTS", "BOLTY", "BOLUS", "BOMBE", "BOMBO", "BOMBS", "BOMOS", "BONAV", "BONBO", "BONCE", "BONDS", "BONED", "BONER", "BONES", "BONEY", "BONGO", "BONGS", "BONKS", "BONNE", "BONNY", "BONOS", "BONUM", "BONUS", "BONZE", "BOOBS", "BOOBY", "BOODH", "BOODY", "BOOED", "BOOKS", "BOOKY", "BOOLY", "BOOMS", "BOOMY", "BOONE", "BOONG", "BOONK", "BOONS", "BOORS", "BOORT", "BOOSE", "BOOST", "BOOSY", "BOOTH", "BOOTS", "BOOTY", "BOOZE", "BOOZY", "BORAK", "BORAL", "BORAN", "BORAS", "BORAX", "BORED", "BOREE", "BOREL", "BORER", "BORES", "BORGH", "BORIC", "BORID", "BORIS", "BORNE", "BORON", "BORTS", "BORTY", "BORTZ", "BORYL", "BOSCH", "BOSER", "BOSEY", "BOSKS", "BOSKY", "BOSOM", "BOSON", "BOSSA", "BOSSY", "BOSUN", "BOTAN", "BOTAS", "BOTCH", "BOTEL", "BOTHY", "BOTRY", "BOTTE", "BOTTS", "BOTTU", "BOUCH", "BOUCL", "BOUET", "BOUGE", "BOUGH", "BOULE", "BOULT", "BOUND", "BOURD", "BOURG", "BOURN", "BOURR", "BOUSE", "BOUSY", "BOUTO", "BOUTS", "BOVEY", "BOVID", "BOVLD", "BOWED", "BOWEL", "BOWER", "BOWET", "BOWGE", "BOWIE", "BOWLA", "BOWLE", "BOWLS", "BOWLY", "BOWNE", "BOWSE", "BOXED", "BOXEN", "BOXER", "BOXES", "BOXTY", "BOYAR", "BOYAU", "BOYCE", "BOYER", "BOYLA", "BOYOS", "BOZAL", "BOZOS", "BOZZE", "BRACA", "BRACE", "BRACH", "BRACK", "BRACT", "BRADS", "BRAES", "BRAGI", "BRAGS", "BRAHM", "BRAID", "BRAIL", "BRAIN", "BRAKE", "BRAKY", "BRAME", "BRAND", "BRANK", "BRANS", "BRANT", "BRASH", "BRASS", "BRAST", "BRATS", "BRAVA", "BRAVE", "BRAVI", "BRAVO", "BRAWL", "BRAWN", "BRAWS", "BRAXY", "BRAYE", "BRAYS", "BRAZA", "BRAZE", "BREAD", "BREAK", "BREAM", "BREBA", "BRECK", "BREDE", "BREDI", "BREED", "BREEK", "BREES", "BREME", "BRENS", "BRENT", "BRERD", "BRERE", "BREST", "BRETH", "BRETT", "BREVA", "BREVE", "BREVI", "BREWS", "BRIAN", "BRIAR", "BRIBE", "BRICK", "BRIDE", "BRIEF", "BRIER", "BRIES", "BRIGS", "BRIKE", "BRILL", "BRIMS", "BRINE", "BRING", "BRINK", "BRINS", "BRINY", "BRIOS", "BRISA", "BRISE", "BRISK", "BRISS", "BRIST", "BRITE", "BRITH", "BRITS", "BRITT", "BRIZA", "BRIZZ", "BROAD", "BROCH", "BROCK", "BROGH", "BROID", "BROIL", "BROKE", "BROLL", "BROMA", "BROME", "BROMO", "BRONC", "BRONK", "BRONX", "BROOD", "BROOK", "BROOL", "BROOM", "BROON", "BROOS", "BROSE", "BROSY", "BROTH", "BROTT", "BROWD", "BROWN", "BROWS", "BRUBU", "BRUCE", "BRUET", "BRUGH", "BRUIN", "BRUIT", "BRUJA", "BRUJO", "BRUKE", "BRULE", "BRUME", "BRUNE", "BRUNO", "BRUNT", "BRUSH", "BRUSK", "BRUTA", "BRUTE", "BRUZZ", "BRYAN", "BRYCE", "BRYON", "BRYUM", "BTISE", "BUAZE", "BUBAL", "BUBAS", "BUBBA", "BUBBY", "BUBOS", "BUCCA", "BUCCO", "BUCHU", "BUCKO", "BUCKS", "BUCKU", "BUCKY", "BUDDH", "BUDDY", "BUDGE", "BUDGY", "BUENO", "BUFFA", "BUFFE", "BUFFI", "BUFFO", "BUFFS", "BUFFY", "BUGAN", "BUGGY", "BUGHT", "BUGLE", "BUGRE", "BUHLS", "BUHRS", "BUICK", "BUILD", "BUILT", "BUIST", "BUKAT", "BULAK", "BULBS", "BULBY", "BULGE", "BULGY", "BULKS", "BULKY", "BULLA", "BULLS", "BULLY", "BULSE", "BUMBO", "BUMFS", "BUMPH", "BUMPS", "BUMPY", "BUNCE", "BUNCH", "BUNCO", "BUNDA", "BUNDH", "BUNDS", "BUNDT", "BUNDU", "BUNDY", "BUNGA", "BUNGO", "BUNGS", "BUNGY", "BUNKO", "BUNKS", "BUNNS", "BUNNY", "BUNTS", "BUNTY", "BUNYA", "BUOYS", "BURAN", "BURAO", "BURAS", "BURBS", "BURDS", "BUREL", "BURET", "BUREZ", "BURGA", "BURGE", "BURGH", "BURGS", "BURIN", "BURKA", "BURKE", "BURLS", "BURLY", "BURMA", "BURNS", "BURNT", "BURNY", "BUROO", "BURPS", "BURRO", "BURRS", "BURRY", "BURSA", "BURSE", "BURST", "BURUT", "BURYS", "BUSBY", "BUSED", "BUSES", "BUSHI", "BUSHY", "BUSKS", "BUSKY", "BUSSU", "BUSSY", "BUSTI", "BUSTO", "BUSTS", "BUSTY", "BUTAT", "BUTCH", "BUTEA", "BUTEO", "BUTIC", "BUTIN", "BUTLE", "BUTSU", "BUTTE", "BUTTS", "BUTTY", "BUTUT", "BUTYL", "BUTYN", "BUTYR", "BUXOM", "BUXUS", "BUYER", "BUZZY", "BWANA", "BYARD", "BYLAW", "BYNIN", "BYOUS", "BYRES", "BYRLS", "BYRON", "BYRRI", "BYSEN", "BYSSI", "BYTES", "BYWAY", "CAABA", "CAAMA", "CABAA", "CABAL", "CABAN", "CABAS", "CABBY", "CABDA", "CABER", "CABIN", "CABIO", "CABLE", "CABOB", "CABOT", "CABRE", "CACAM", "CACAN", "CACAO", "CACAS", "CACEI", "CACHE", "CACKS", "CACTI", "CACUR", "CADDO", "CADDY", "CADEE", "CADER", "CADES", "CADET", "CADEW", "CADGE", "CADGY", "CADIE", "CADIS", "CADOS", "CADRE", "CADUA", "CADUS", "CAECA", "CAFES", "CAFFA", "CAFIZ", "CAFOY", "CAGED", "CAGER", "CAGES", "CAGEY", "CAGGY", "CAGIT", "CAGOT", "CAGUI", "CAHIZ", "CAHOT", "CAHOW", "CAHUY", "CAIDS", "CAINS", "CAIRD", "CAIRN", "CAIRO", "CAITE", "CAJAN", "CAJON", "CAJOU", "CAJUN", "CAKED", "CAKER", "CAKES", "CAKEY", "CAKRA", "CALAS", "CALCI", "CALEB", "CALEF", "CALFS", "CALIC", "CALID", "CALIF", "CALIN", "CALIX", "CALKS", "CALLA", "CALLI", "CALLO", "CALLS", "CALMS", "CALMY", "CALOR", "CALVE", "CALYX", "CAMAN", "CAMAS", "CAMAY", "CAMEL", "CAMEO", "CAMES", "CAMIS", "CAMLA", "CAMPA", "CAMPE", "CAMPI", "CAMPO", "CAMPS", "CAMPY", "CAMUS", "CANAL", "CANAP", "CANCH", "CANDY", "CANED", "CANEL", "CANER", "CANES", "CANGY", "CANID", "CANIS", "CANLI", "CANNA", "CANNY", "CANOE", "CANON", "CANOS", "CANSO", "CANST", "CANTO", "CANTS", "CANTY", "CANUN", "CANZO", "CAOBA", "CAPAX", "CAPED", "CAPEL", "CAPER", "CAPES", "CAPHS", "CAPOC", "CAPON", "CAPOS", "CAPOT", "CAPPY", "CAPRA", "CAPRI", "CAPSA", "CAPUT", "CAQUE", "CARAP", "CARAT", "CARBO", "CARBY", "CARDO", "CARDS", "CARED", "CARER", "CARES", "CARET", "CAREX", "CAREY", "CARGA", "CARGO", "CARIB", "CARID", "CARKS", "CARLE", "CARLI", "CARLO", "CARLS", "CARNE", "CARNS", "CARNY", "CAROA", "CAROB", "CAROL", "CAROM", "CAROT", "CARPE", "CARPI", "CARPS", "CARRI", "CARRS", "CARRY", "CARSE", "CARTE", "CARTS", "CARTY", "CARUA", "CARUM", "CARUS", "CARVE", "CARVY", "CARYA", "CARYL", "CASAL", "CASAS", "CASCO", "CASED", "CASEL", "CASER", "CASES", "CASEY", "CASHA", "CASKS", "CASKY", "CASSE", "CASSY", "CASTE", "CASTS", "CASUS", "CATAN", "CATCH", "CATEL", "CATER", "CATES", "CATHA", "CATHY", "CATSO", "CATTI", "CATTY", "CATUR", "CAUCH", "CAUDA", "CAULD", "CAULI", "CAULK", "CAULS", "CAUMA", "CAUPO", "CAUSA", "CAUSE", "CAVAE", "CAVAL", "CAVEA", "CAVED", "CAVEL", "CAVER", "CAVES", "CAVEY", "CAVIA", "CAVIE", "CAVIL", "CAVIN", "CAVUM", "CAVUS", "CAWED", "CAWKY", "CAWNY", "CAXON", "CAYOS", "CCITT", "CCOYA", "CEASE", "CEBID", "CEBIL", "CEBUR", "CEBUS", "CECAL", "CECCA", "CECIL", "CECUM", "CEDAR", "CEDED", "CEDER", "CEDES", "CEDIS", "CEDRE", "CEDRY", "CEIBA", "CEIBO", "CEILE", "CEILS", "CEINT", "CELEB", "CELIA", "CELLA", "CELLI", "CELLO", "CELLS", "CELOM", "CELTS", "CENSE", "CENTI", "CENTO", "CENTS", "CEORL", "CEPES", "CEQUI", "CERAL", "CERAS", "CERAT", "CERCI", "CERED", "CERER", "CERES", "CERIA", "CERIC", "CERIN", "CEROS", "CERTY", "CERYL", "CESAR", "CESTA", "CESTE", "CESTI", "CETES", "CETIC", "CETID", "CETIN", "CETUS", "CETYL", "CHACE", "CHACK", "CHACO", "CHADS", "CHAFE", "CHAFF", "CHAFT", "CHAGA", "CHAIN", "CHAIR", "CHAIS", "CHAIT", "CHAJA", "CHAKA", "CHALK", "CHAMA", "CHAMM", "CHAMP", "CHAMS", "CHANE", "CHANG", "CHANK", "CHANT", "CHAOS", "CHAPE", "CHAPS", "CHAPT", "CHARA", "CHARD", "CHARE", "CHARK", "CHARM", "CHARR", "CHARS", "CHART", "CHARY", "CHASE", "CHASM", "CHASS", "CHATI", "CHATS", "CHAUI", "CHAUK", "CHAUM", "CHAUS", "CHAVE", "CHAWK", "CHAWL", "CHAWN", "CHAWS", "CHAYA", "CHAYS", "CHAZY", "CHEAP", "CHEAT", "CHECK", "CHEEK", "CHEEP", "CHEER", "CHEET", "CHEFS", "CHEGO", "CHEIR", "CHEKA", "CHEKE", "CHEKI", "CHELA", "CHELP", "CHENA", "CHENG", "CHERA", "CHERE", "CHERT", "CHESE", "CHESS", "CHEST", "CHETH", "CHEVE", "CHEVY", "CHEWS", "CHEWY", "CHIAM", "CHIAN", "CHIAO", "CHIAS", "CHIBA", "CHICA", "CHICH", "CHICK", "CHICO", "CHICS", "CHIDE", "CHIEF", "CHIEL", "CHIEN", "CHILD", "CHILE", "CHILI", "CHILL", "CHIMB", "CHIME", "CHIMP", "CHIMU", "CHINA", "CHINE", "CHING", "CHINK", "CHINO", "CHINS", "CHINT", "CHIOT", "CHIPS", "CHIRK", "CHIRL", "CHIRM", "CHIRO", "CHIRP", "CHIRR", "CHIRT", "CHIRU", "CHITA", "CHITS", "CHIVE", "CHIVW", "CHIVY", "CHIZZ", "CHLOE", "CHLOR", "CHOAK", "CHOCA", "CHOCK", "CHOCO", "CHOEL", "CHOES", "CHOGA", "CHOIL", "CHOIR", "CHOKE", "CHOKO", "CHOKY", "CHOLA", "CHOLD", "CHOLI", "CHOLO", "CHOMP", "CHONK", "CHOOK", "CHOOM", "CHOOP", "CHOPA", "CHOPS", "CHORA", "CHORD", "CHORE", "CHORT", "CHOSE", "CHOTT", "CHOUP", "CHOUS", "CHOUT", "CHOUX", "CHOWK", "CHOWS", "CHOYA", "CHRIA", "CHRIS", "CHRON", "CHUBB", "CHUBS", "CHUCK", "CHUDE", "CHUET", "CHUFA", "CHUFF", "CHUGS", "CHUJE", "CHUMP", "CHUMS", "CHUNG", "CHUNK", "CHURL", "CHURM", "CHURN", "CHURR", "CHUSE", "CHUTE", "CHWAS", "CHYAK", "CHYLE", "CHYME", "CIBOL", "CICAD", "CICER", "CIDER", "CIGAR", "CIGUA", "CILIA", "CIMEX", "CINCH", "CINCT", "CINDY", "CINEL", "CINES", "CIONS", "CIPPI", "CIRCA", "CIRCE", "CIRCS", "CIRES", "CIRRI", "CISCO", "CISSY", "CISTA", "CISTS", "CITAL", "CITED", "CITEE", "CITER", "CITES", "CITUA", "CIVET", "CIVIC", "CIVIE", "CIVIL", "CIVVY", "CIZAR", "CLACH", "CLACK", "CLADE", "CLADS", "CLAES", "CLAGS", "CLAIK", "CLAIM", "CLAIR", "CLAKE", "CLAMB", "CLAME", "CLAMP", "CLAMS", "CLANG", "CLANK", "CLANS", "CLAPE", "CLAPS", "CLAPT", "CLARA", "CLARE", "CLARK", "CLARO", "CLART", "CLARY", "CLASH", "CLASP", "CLASS", "CLAST", "CLAUS", "CLAUT", "CLAVA", "CLAVE", "CLAVI", "CLAVY", "CLAWK", "CLAWS", "CLAYE", "CLAYS", "CLEAD", "CLEAM", "CLEAN", "CLEAR", "CLEAT", "CLECK", "CLEEK", "CLEFS", "CLEFT", "CLEPE", "CLEPT", "CLERK", "CLEUK", "CLEVE", "CLEWS", "CLICH", "CLICK", "CLIFF", "CLIFT", "CLIMA", "CLIMB", "CLIME", "CLINE", "CLING", "CLINK", "CLINT", "CLIPS", "CLIPT", "CLITE", "CLIVE", "CLOAK", "CLOAM", "CLOCK", "CLODS", "CLOES", "CLOFF", "CLOGS", "CLOIT", "CLOKE", "CLOKY", "CLOMB", "CLOMP", "CLONE", "CLONG", "CLONK", "CLONS", "CLOOF", "CLOOP", "CLOOT", "CLOPS", "CLOSE", "CLOSH", "CLOTE", "CLOTH", "CLOTS", "CLOUD", "CLOUR", "CLOUT", "CLOVE", "CLOWN", "CLOYS", "CLOZE", "CLUBS", "CLUCK", "CLUED", "CLUES", "CLUFF", "CLUMP", "CLUNG", "CLUNK", "CLYDE", "CLYER", "CLYPE", "CNIDA", "COACH", "COACT", "COAID", "COALA", "COALS", "COALY", "COAPT", "COARB", "COART", "COAST", "COATI", "COATS", "COAXY", "COBBS", "COBBY", "COBIA", "COBLE", "COBOL", "COBRA", "COBUS", "COCAO", "COCAS", "COCCI", "COCCO", "COCIN", "COCKS", "COCKY", "COCLE", "COCOA", "COCOS", "COCUS", "CODAL", "CODAS", "CODDY", "CODEC", "CODED", "CODEN", "CODER", "CODES", "CODEX", "CODOL", "CODON", "COEDS", "COEFF", "COENO", "COFFS", "COGIE", "COGIT", "COGON", "COGUE", "COHEN", "COHOB", "COHOG", "COHOL", "COHOS", "COHOW", "COHUE", "COIFS", "COIGN", "COILS", "COING", "COINS", "COINY", "COIRS", "COKED", "COKER", "COKES", "COKEY", "COKIE", "COLAN", "COLAS", "COLAT", "COLDS", "COLEN", "COLES", "COLET", "COLEY", "COLIC", "COLIN", "COLLA", "COLLY", "COLOB", "COLOG", "COLON", "COLOR", "COLTS", "COLZA", "COMAE", "COMAL", "COMAN", "COMAS", "COMBE", "COMBO", "COMBS", "COMBY", "COMDG", "COMDR", "COMDT", "COMER", "COMES", "COMET", "COMFY", "COMIC", "COMID", "COMMA", "COMME", "COMMO", "COMMY", "COMOX", "COMPD", "COMPO", "COMPS", "COMPT", "COMTE", "COMUS", "CONAL", "CONCH", "CONCN", "CONDO", "CONED", "CONER", "CONES", "CONEY", "CONFR", "CONGA", "CONGE", "CONGO", "CONIA", "CONIC", "CONIN", "CONKS", "CONKY", "CONLI", "CONNS", "CONNU", "CONNY", "CONOR", "CONOY", "CONST", "CONSY", "CONTD", "CONTE", "CONTG", "CONTO", "CONTR", "CONUS", "COOBA", "COOCH", "COOED", "COOEE", "COOER", "COOEY", "COOFS", "COOJA", "COOKS", "COOKY", "COOLS", "COOLY", "COOMB", "COOMY", "COONS", "COONY", "COOPS", "COOPT", "COORG", "COOST", "COOTH", "COOTS", "COOTY", "COPAL", "COPED", "COPEI", "COPEN", "COPER", "COPES", "COPIA", "COPIS", "COPPA", "COPPS", "COPPY", "COPRA", "COPSE", "COPSY", "COPUS", "COQUE", "CORAH", "CORAL", "CORAM", "CORAN", "CORBE", "CORBY", "CORDS", "CORDY", "CORED", "COREE", "CORER", "CORES", "COREY", "CORGE", "CORGI", "CORIA", "CORIN", "CORKE", "CORKS", "CORKY", "CORMS", "CORNO", "CORNS", "CORNU", "CORNY", "COROA", "COROL", "CORPL", "CORPN", "CORPS", "CORSE", "CORSO", "CORSY", "CORTA", "CORVE", "CORVO", "CORYL", "COSEC", "COSED", "COSEN", "COSES", "COSET", "COSEY", "COSIE", "COSIN", "COSMO", "COSSE", "COSTA", "COSTS", "COTAN", "COTCH", "COTED", "COTES", "COTHE", "COTHY", "COTTA", "COTTE", "COTTY", "COTYS", "COUAC", "COUCH", "COUDE", "COUGH", "COULD", "COUMA", "COUNT", "COUPE", "COUPS", "COURB", "COURS", "COURT", "COUTH", "COUVE", "COVED", "COVEN", "COVER", "COVES", "COVET", "COVEY", "COVID", "COVIN", "COWAL", "COWAN", "COWED", "COWER", "COWLE", "COWLS", "COWRY", "COXAE", "COXAL", "COXED", "COXES", "COYAN", "COYED", "COYER", "COYLY", "COYOL", "COYOS", "COYPU", "COZED", "COZEN", "COZES", "COZEY", "COZIE", "CRAAL", "CRABS", "CRACK", "CRAFT", "CRAGS", "CRAIE", "CRAIG", "CRAIK", "CRAIN", "CRAKE", "CRAMP", "CRAMS", "CRANE", "CRANG", "CRANK", "CRANY", "CRAPE", "CRAPS", "CRAPY", "CRARE", "CRASH", "CRASS", "CRATE", "CRAVE", "CRAVO", "CRAWL", "CRAWM", "CRAWS", "CRAYE", "CRAZE", "CRAZY", "CRCAO", "CRCHE", "CREAD", "CREAK", "CREAM", "CREAT", "CREDA", "CREDO", "CREED", "CREEK", "CREEL", "CREEM", "CREEN", "CREEP", "CREES", "CREME", "CRENA", "CREPE", "CREPT", "CREPY", "CRESC", "CRESS", "CREST", "CRETA", "CRETE", "CREWE", "CREWS", "CRIBO", "CRIBS", "CRICK", "CRIED", "CRIER", "CRIES", "CRIEY", "CRILE", "CRIME", "CRIMP", "CRINE", "CRINK", "CRIPS", "CRISP", "CRISS", "CRITH", "CROAK", "CROAT", "CROCI", "CROCK", "CROFT", "CROIS", "CROME", "CRONE", "CRONK", "CRONY", "CROOD", "CROOK", "CROOL", "CROON", "CROPS", "CRORE", "CROSA", "CROSE", "CROSS", "CROST", "CROUP", "CROUT", "CROWD", "CROWL", "CROWN", "CROWS", "CROYL", "CROZE", "CRUCE", "CRUCK", "CRUDE", "CRUDS", "CRUDY", "CRUEL", "CRUET", "CRULL", "CRUMB", "CRUMP", "CRUNK", "CRUNT", "CRUOR", "CRURA", "CRUSE", "CRUSH", "CRUST", "CRUTH", "CRWTH", "CRYAL", "CRYPT", "CRYST", "CSECT", "CSNET", "CTENE", "CTIMO", "CUBAN", "CUBAS", "CUBBY", "CUBEB", "CUBED", "CUBER", "CUBES", "CUBIC", "CUBIT", "CUBLA", "CUBTI", "CUCUY", "CUDDY", "CUECA", "CUEVA", "CUFFS", "CUFFY", "CUFIC", "CUIFS", "CUING", "CUISH", "CUJAM", "CUKES", "CULCH", "CULET", "CULEX", "CULLA", "CULLS", "CULLY", "CULMS", "CULMY", "CULOT", "CULPA", "CULTI", "CULTS", "CUMAL", "CUMAR", "CUMAY", "CUMBU", "CUMIC", "CUMIN", "CUMLY", "CUMOL", "CUMYL", "CUNAN", "CUNAS", "CUNDY", "CUNEA", "CUNEI", "CUNIT", "CUNNI", "CUNNY", "CUNTS", "CUNYE", "CUNZA", "CUPAY", "CUPEL", "CUPID", "CUPPA", "CUPPY", "CURAT", "CURBS", "CURBY", "CURCH", "CURDS", "CURDY", "CURED", "CURER", "CURES", "CURET", "CURFS", "CURIA", "CURIE", "CURIN", "CURIO", "CURLS", "CURLY", "CURNS", "CURRS", "CURRY", "CURSA", "CURSE", "CURST", "CURUA", "CURVE", "CURVY", "CUSEC", "CUSHY", "CUSIE", "CUSKS", "CUSPS", "CUSSO", "CUTCH", "CUTER", "CUTES", "CUTEY", "CUTIE", "CUTIN", "CUTIS", "CUTTY", "CUTUP", "CUVEE", "CUYAS", "CYANO", "CYANS", "CYATH", "CYBER", "CYCAD", "CYCAS", "CYCLE", "CYCLO", "CYDER", "CYDON", "CYLIX", "CYMAE", "CYMAR", "CYMAS", "CYMBA", "CYMES", "CYMOL", "CYMRY", "CYNIC", "CYPRE", "CYRIL", "CYRUS", "CYSTS", "CYTOL", "CYTON", "CZARS", "CZECH", "DABBA", "DABBY", "DABIH", "DABUH", "DACES", "DACHA", "DACHS", "DACUS", "DADAP", "DADAS", "DADDY", "DADOS", "DAEVA", "DAFFS", "DAFFY", "DAFLA", "DAGGA", "DAGGY", "DAGON", "DAGOS", "DAHMS", "DAIJO", "DAILY", "DAINT", "DAIRA", "DAIRI", "DAIRT", "DAIRY", "DAISY", "DAIVA", "DAKER", "DAKIR", "DALAI", "DALAN", "DALAR", "DALEA", "DALER", "DALES", "DALIS", "DALLE", "DALLY", "DAMAN", "DAMAR", "DAMAS", "DAMES", "DAMIA", "DAMIE", "DAMME", "DAMNS", "DAMON", "DAMPS", "DAMPY", "DANAE", "DANAI", "DANCE", "DANCY", "DANDA", "DANDY", "DANES", "DANGS", "DANIC", "DANIO", "DANKE", "DANLI", "DANNY", "DANSK", "DANSY", "DANTA", "DANTE", "DARAC", "DARAF", "DARAT", "DARBS", "DARBY", "DARCI", "DARCY", "DARED", "DAREN", "DARER", "DARES", "DARGO", "DARIC", "DARII", "DARIN", "DARKS", "DARKY", "DARNS", "DAROO", "DARST", "DARTS", "DARYA", "DARYL", "DASHT", "DASHY", "DASNT", "DASSY", "DASYA", "DATCH", "DATED", "DATER", "DATES", "DATIL", "DATOS", "DATSW", "DATTO", "DATUM", "DAUBE", "DAUBS", "DAUBY", "DAUKE", "DAULT", "DAUNT", "DAURI", "DAUTS", "DAVEN", "DAVER", "DAVID", "DAVIS", "DAVIT", "DAWDY", "DAWED", "DAWEN", "DAWKS", "DAWNS", "DAWNY", "DAWTS", "DAWUT", "DAYAK", "DAYAL", "DAYAN", "DAZED", "DAZES", "DEADS", "DEADY", "DEAIR", "DEALS", "DEALT", "DEANS", "DEARE", "DEARN", "DEARS", "DEARY", "DEASH", "DEATH", "DEAVE", "DEBAG", "DEBAR", "DEBAT", "DEBBY", "DEBEL", "DEBEN", "DEBIT", "DEBTS", "DEBUG", "DEBUS", "DEBUT", "DEBYE", "DECAD", "DECAL", "DECAN", "DECAP", "DECAY", "DECEM", "DECIL", "DECKE", "DECKS", "DECOR", "DECOY", "DECRY", "DECUS", "DECYL", "DEDAL", "DEDAN", "DEDDY", "DEDIT", "DEEDS", "DEEDY", "DEEMS", "DEENY", "DEEPS", "DEERS", "DEESS", "DEFAT", "DEFER", "DEFET", "DEFIS", "DEFIX", "DEFOG", "DEGAS", "DEGUM", "DEICE", "DEIFY", "DEIGN", "DEILS", "DEINK", "DEINO", "DEISM", "DEIST", "DEITY", "DEKED", "DEKES", "DEKKO", "DEKLE", "DELAW", "DELAY", "DELED", "DELES", "DELFS", "DELFT", "DELHI", "DELIA", "DELIM", "DELIS", "DELIT", "DELLA", "DELLS", "DELLY", "DELOO", "DELPH", "DELTA", "DELVE", "DEMAL", "DEMES", "DEMIT", "DEMOB", "DEMON", "DEMOS", "DEMOT", "DEMUR", "DENAR", "DENAT", "DENAY", "DENDA", "DENEB", "DENES", "DENIM", "DENIS", "DENOM", "DENSE", "DENTS", "DENTY", "DEOTA", "DEPAS", "DEPEL", "DEPIT", "DEPOH", "DEPOT", "DEPTH", "DERAH", "DERAT", "DERAY", "DERBY", "DEREK", "DERIC", "DERIV", "DERMA", "DERMS", "DEROG", "DERRI", "DERRY", "DERTH", "DERVE", "DESEX", "DESKS", "DESMA", "DESSA", "DESTO", "DESYL", "DETAR", "DETAT", "DETAX", "DETER", "DETIN", "DETTE", "DETUR", "DEUCE", "DEVAL", "DEVAS", "DEVEL", "DEVEX", "DEVIL", "DEVON", "DEVOT", "DEVOW", "DEWAL", "DEWAN", "DEWAR", "DEWAX", "DEWED", "DEWER", "DEWEY", "DEXES", "DEYNT", "DHABB", "DHAKS", "DHAVA", "DHERI", "DHIKR", "DHOBI", "DHOBY", "DHOLE", "DHONI", "DHOON", "DHOTI", "DHOTY", "DHOUL", "DHOWS", "DHUTI", "DHYAL", "DIACT", "DIAKA", "DIALS", "DIAMB", "DIANA", "DIANE", "DIARY", "DIAZO", "DICED", "DICER", "DICES", "DICEY", "DICHT", "DICKS", "DICKY", "DICOT", "DICTA", "DICTY", "DIDAL", "DIDDY", "DIDIE", "DIDLE", "DIDNA", "DIDNT", "DIDOS", "DIDST", "DIDUS", "DIDYM", "DIEGO", "DIENE", "DIERI", "DIETS", "DIETY", "DIFDA", "DIGHT", "DIGIT", "DIGNE", "DIGOR", "DIGUE", "DIKED", "DIKER", "DIKES", "DILDO", "DILIS", "DILLI", "DILLS", "DILLY", "DILOS", "DIMER", "DIMES", "DIMIN", "DIMIT", "DIMLY", "DIMMY", "DIMNA", "DIMPS", "DINAH", "DINAR", "DINED", "DINER", "DINES", "DINGE", "DINGO", "DINGS", "DINGY", "DINIC", "DINKA", "DINKS", "DINKY", "DINOS", "DINTS", "DINUS", "DIODE", "DIOLS", "DIONE", "DIOON", "DIOSE", "DIOTA", "DIOTI", "DIOXY", "DIPLE", "DIPPY", "DIPSO", "DIPSY", "DIPUS", "DIRCA", "DIRER", "DIREX", "DIRGE", "DIRGY", "DIRKS", "DIRLS", "DIRTS", "DIRTY", "DISCI", "DISCO", "DISCS", "DISHY", "DISKS", "DISLI", "DISME", "DISNA", "DISTN", "DISTR", "DISTY", "DITAL", "DITAS", "DITCH", "DITER", "DITES", "DITTO", "DITTY", "DIURN", "DIVAN", "DIVAS", "DIVED", "DIVEL", "DIVER", "DIVES", "DIVET", "DIVIA", "DIVID", "DIVOT", "DIVUS", "DIVVY", "DIWAN", "DIXIE", "DIXIT", "DIZEN", "DIZZY", "DJAVE", "DJINN", "DJINS", "DJUKA", "DOAND", "DOATS", "DOATY", "DOBBY", "DOBIE", "DOBLA", "DOBOS", "DOBRA", "DOCKS", "DODDY", "DODGE", "DODGY", "DODOS", "DOERS", "DOESN", "DOEST", "DOETH", "DOFFS", "DOGAL", "DOGES", "DOGEY", "DOGGO", "DOGGY", "DOGIE", "DOGLY", "DOGMA", "DOGRA", "DOIGT", "DOILY", "DOINA", "DOING", "DOITS", "DOJOS", "DOLCE", "DOLCI", "DOLED", "DOLES", "DOLEY", "DOLIA", "DOLLS", "DOLLY", "DOLOR", "DOLOS", "DOLPH", "DOLTS", "DOLUS", "DOMAL", "DOMBA", "DOMED", "DOMER", "DOMES", "DOMIC", "DOMPT", "DOMUS", "DONAL", "DONAR", "DONAS", "DONAT", "DONAX", "DONCY", "DONEC", "DONEE", "DONET", "DONEY", "DONGA", "DONGS", "DONIA", "DONIS", "DONNA", "DONNE", "DONNY", "DONOR", "DONSY", "DONUM", "DONUT", "DOOJA", "DOOLI", "DOOLY", "DOOMS", "DOORS", "DOOZY", "DOPAS", "DOPED", "DOPER", "DOPES", "DOPEY", "DORAB", "DORAD", "DORAY", "DOREE", "DOREY", "DORIA", "DORIC", "DORIS", "DORJE", "DORMS", "DORMY", "DORPS", "DORRS", "DORSA", "DORSE", "DORSI", "DORTS", "DORTY", "DOSED", "DOSER", "DOSES", "DOSIS", "DOSSY", "DOTAL", "DOTED", "DOTER", "DOTES", "DOTTY", "DOUAR", "DOUBT", "DOUCE", "DOUGH", "DOUGL", "DOUMA", "DOURA", "DOUSE", "DOVEN", "DOVER", "DOVES", "DOVEY", "DOWDY", "DOWED", "DOWEL", "DOWER", "DOWIE", "DOWLY", "DOWNS", "DOWNY", "DOWRY", "DOWSE", "DOWVE", "DOXIE", "DOYEN", "DOYLE", "DOYLT", "DOYLY", "DOYST", "DOZED", "DOZEN", "DOZER", "DOZES", "DRABA", "DRABS", "DRACO", "DRAFF", "DRAFT", "DRAGO", "DRAGS", "DRAIL", "DRAIN", "DRAKE", "DRAMA", "DRAME", "DRAMM", "DRAMS", "DRANG", "DRANK", "DRANT", "DRAPE", "DRATE", "DRATS", "DRAVE", "DRAWK", "DRAWL", "DRAWN", "DRAWS", "DRAYS", "DREAD", "DREAM", "DREAR", "DRECK", "DREED", "DREEP", "DREES", "DREGS", "DREKS", "DRENG", "DRENT", "DRESS", "DREST", "DRIAS", "DRIBS", "DRIED", "DRIER", "DRIES", "DRIFT", "DRILL", "DRILY", "DRINK", "DRINN", "DRIPS", "DRIPT", "DRISK", "DRIVE", "DROGH", "DROIL", "DROIT", "DROLL", "DROME", "DRONA", "DRONE", "DRONY", "DROOB", "DROOL", "DROOP", "DROPS", "DROPT", "DROSS", "DROUD", "DROUK", "DROVE", "DROVY", "DROWN", "DROYL", "DRUBS", "DRUGS", "DRUID", "DRUMS", "DRUNG", "DRUNK", "DRUNT", "DRUPA", "DRUPE", "DRURY", "DRUSE", "DRUSY", "DRUXY", "DRUZE", "DRYAD", "DRYAS", "DRYER", "DRYLY", "DRYTH", "DSECT", "DTSET", "DUADS", "DUALA", "DUALI", "DUALS", "DUANE", "DUANT", "DUBBA", "DUBBY", "DUBHE", "DUBIO", "DUCAL", "DUCAT", "DUCES", "DUCHY", "DUCKS", "DUCKY", "DUCTS", "DUDDY", "DUDES", "DUELS", "DUETS", "DUFFS", "DUFFY", "DUGAL", "DUHAT", "DUITS", "DUJAN", "DUKES", "DUKHN", "DULAT", "DULCE", "DULER", "DULIA", "DULLS", "DULLY", "DULSE", "DUMAS", "DUMBA", "DUMBS", "DUMBY", "DUMKA", "DUMKY", "DUMMY", "DUMPS", "DUMPY", "DUNAL", "DUNCE", "DUNCH", "DUNES", "DUNGS", "DUNGY", "DUNKS", "DUNNE", "DUNNO", "DUNNY", "DUNST", "DUNTS", "DUOLE", "DUOMI", "DUOMO", "DUPED", "DUPER", "DUPES", "DUPLA", "DUPLE", "DUPLY", "DUPPA", "DUPPY", "DURAL", "DURAS", "DURAX", "DURED", "DUREE", "DURES", "DURET", "DURIO", "DURNS", "DUROC", "DUROS", "DUROY", "DURRA", "DURRS", "DURRY", "DURST", "DURUM", "DURYL", "DURZI", "DUSIO", "DUSKS", "DUSKY", "DUSTS", "DUSTY", "DUSUN", "DUTCH", "DUTRA", "DUVET", "DUXES", "DVIGU", "DWALE", "DWALM", "DWANG", "DWARF", "DWELL", "DWELT", "DWINE", "DWYKA", "DYADS", "DYAUS", "DYERS", "DYING", "DYKED", "DYKER", "DYKES", "DYLAN", "DYNAM", "DYNEL", "DYNES", "EABLY", "EAGER", "EAGLE", "EAGRE", "EARED", "EARLE", "EARLS", "EARLY", "EARNS", "EARSH", "EARTH", "EASED", "EASEL", "EASER", "EASES", "EASTS", "EATEN", "EATER", "EAVED", "EAVER", "EAVES", "EBBED", "EBBET", "EBLIS", "EBONS", "EBONY", "ECART", "ECHAR", "ECHEA", "ECHED", "ECHES", "ECHIS", "ECHOS", "ECIZE", "ECLAT", "ECOID", "ECOLE", "ECRUS", "ECTAD", "ECTAL", "EDANA", "EDDER", "EDDIC", "EDDIE", "EDEMA", "EDGAR", "EDGED", "EDGER", "EDGES", "EDICT", "EDIFY", "EDILE", "EDITH", "EDITS", "EDIYA", "EDONI", "EDUCE", "EDUCT", "EDWIN", "EELER", "EEMIS", "EERIE", "EETEN", "EFFET", "EFFIE", "EGADS", "EGALL", "EGERS", "EGEST", "EGGAR", "EGGED", "EGGER", "EGRET", "EGRID", "EGYPT", "EIDER", "EIDOS", "EIGHT", "EIGNE", "EIKON", "EIMAK", "EIMER", "EJECT", "EJIDO", "EJUSD", "EKAHA", "EKING", "EKRON", "ELAIC", "ELAIN", "ELAMP", "ELAND", "ELANS", "ELAPS", "ELATE", "ELAYL", "ELBOW", "ELDER", "ELDIN", "ELEAN", "ELECT", "ELEGY", "ELEME", "ELEMI", "ELEUT", "ELEVE", "ELFIC", "ELFIN", "ELIAN", "ELIAS", "ELIDE", "ELIHU", "ELIOT", "ELITE", "ELIZA", "ELLAN", "ELLEN", "ELMER", "ELOAH", "ELOGE", "ELOGY", "ELOIN", "ELONG", "ELOPE", "ELOPS", "ELRIC", "ELSES", "ELSIN", "ELUDE", "ELUTE", "ELVAN", "ELVER", "ELVES", "ELVET", "ELVIS", "ELYMI", "EMAIL", "EMANE", "EMBAR", "EMBAY", "EMBED", "EMBER", "EMBOG", "EMBOW", "EMBOX", "EMBUE", "EMBUS", "EMCEE", "EMDEN", "EMEER", "EMEND", "EMERY", "EMESA", "EMEUS", "EMIGR", "EMILY", "EMIRS", "EMITS", "EMLEN", "EMMER", "EMMET", "EMMEW", "EMONG", "EMONY", "EMORY", "EMOTE", "EMOVE", "EMPEO", "EMPTY", "EMULE", "EMULS", "EMYDE", "EMYDS", "ENACT", "ENAGE", "ENAMI", "ENAPT", "ENARM", "ENATE", "ENCIA", "ENCUP", "ENCYC", "ENDED", "ENDER", "ENDEW", "ENDIA", "ENDOW", "ENDUE", "ENEAS", "ENEID", "ENEMA", "ENEMY", "ENENT", "ENFIN", "ENGEM", "ENGIN", "ENGLE", "ENHAT", "ENIAC", "ENJOY", "ENLAY", "ENMEW", "ENNEW", "ENNIA", "ENNOY", "ENNUI", "ENOCH", "ENODE", "ENOIL", "ENOLS", "ENORM", "ENORN", "ENOWS", "ENPIA", "ENRAY", "ENRIB", "ENROL", "ENRUT", "ENSKY", "ENSUE", "ENTAD", "ENTAL", "ENTEA", "ENTER", "ENTIA", "ENTOM", "ENTRE", "ENTRY", "ENTTE", "ENURE", "ENVOI", "ENVOY", "ENWEB", "ENZYM", "EOITH", "EOSIN", "EPACT", "EPEES", "EPEUS", "EPHAH", "EPHAS", "EPHOD", "EPHOI", "EPHOR", "EPICS", "EPIKY", "EPIST", "EPLOT", "EPOCH", "EPODE", "EPOPT", "EPOXY", "EPPES", "EPPIE", "EPRIS", "EPSOM", "EPULO", "EQUAL", "EQUES", "EQUID", "EQUIP", "EQUIV", "EQUUS", "ERADE", "ERASE", "ERATO", "ERAVA", "ERBIA", "ERECT", "EREPT", "ERGAL", "ERGON", "ERGOT", "ERIAN", "ERICA", "ERICK", "ERIKA", "ERIZO", "ERMIT", "ERNES", "ERNIE", "ERNST", "ERODE", "EROSE", "ERRED", "ERRON", "ERROR", "ERSAR", "ERSES", "ERUCA", "ERUCT", "ERUGO", "ERUMP", "ERUPT", "ERVIL", "ERVUM", "ERWIN", "ERYON", "ESBAY", "ESCAR", "ESCOT", "ESCRY", "ESERE", "ESHIN", "ESKAR", "ESKER", "ESPEC", "ESROG", "ESSAY", "ESSED", "ESSEE", "ESSES", "ESSEX", "ESSIE", "ESTAB", "ESTER", "ESTOC", "ESTOP", "ESTRE", "ESTUS", "ETANG", "ETAPE", "ETHAL", "ETHAN", "ETHEL", "ETHER", "ETHIC", "ETHID", "ETHOS", "ETHYL", "ETIAM", "ETNAS", "ETROG", "ETTLE", "ETUDE", "ETUIS", "ETUVE", "ETWAS", "ETWEE", "ETYMA", "EUCRE", "EUCTI", "EULER", "EUPAD", "EUROS", "EURUS", "EUSOL", "EVADE", "EVANG", "EVANS", "EVASE", "EVECK", "EVENE", "EVENS", "EVENT", "EVERT", "EVERY", "EVESE", "EVICT", "EVILS", "EVITE", "EVOKE", "EWDER", "EWERS", "EWERY", "EWEST", "EWHOW", "EWING", "EXACT", "EXALT", "EXAMS", "EXAUN", "EXCEL", "EXCUD", "EXCUR", "EXDIE", "EXEAT", "EXECS", "EXECT", "EXEDE", "EXERT", "EXHBN", "EXIES", "EXILE", "EXINE", "EXING", "EXION", "EXIST", "EXITE", "EXITS", "EXLEX", "EXODE", "EXODY", "EXOPT", "EXPDT", "EXPEL", "EXPOS", "EXPTL", "EXPWY", "EXSEC", "EXTER", "EXTOL", "EXTRA", "EXUDE", "EXULT", "EXURB", "EXUST", "EXXON", "EYASS", "EYERS", "EYESS", "EYGHT", "EYING", "EYOTY", "EYRAR", "EYRAS", "EYREN", "EYRER", "EYRES", "EYRIE", "EYRIR", "FAADE", "FABES", "FABLE", "FACED", "FACER", "FACES", "FACET", "FACIA", "FACIE", "FACIT", "FACKS", "FACTO", "FACTS", "FACTY", "FADDY", "FADED", "FADEN", "FADER", "FADES", "FADGE", "FADME", "FADOS", "FAENA", "FAERY", "FAFFY", "FAGER", "FAGGY", "FAGIN", "FAGOT", "FAGUS", "FAHAM", "FAILS", "FAINS", "FAINT", "FAIRE", "FAIRM", "FAIRS", "FAIRY", "FAITH", "FAITS", "FAKED", "FAKER", "FAKES", "FAKIR", "FALCO", "FALDA", "FALLA", "FALLS", "FALLY", "FALSE", "FALUN", "FALUS", "FAMED", "FAMES", "FANAL", "FANAM", "FANCY", "FANES", "FANGA", "FANGO", "FANGS", "FANGY", "FANIT", "FANNY", "FANON", "FANOS", "FANTI", "FANUM", "FANWE", "FAQIR", "FARAD", "FARCE", "FARCI", "FARCY", "FARDE", "FARDH", "FARDO", "FARDS", "FARED", "FARER", "FARES", "FARIO", "FARLE", "FARLS", "FARMS", "FARMY", "FAROS", "FARSE", "FARSI", "FARTH", "FARTS", "FASTI", "FASTS", "FATAL", "FATED", "FATES", "FATIL", "FATLY", "FATOR", "FATSO", "FATTY", "FATWA", "FAUGH", "FAULD", "FAULT", "FAULX", "FAUNA", "FAUNS", "FAURD", "FAUSE", "FAUST", "FAUTE", "FAUVE", "FAVEL", "FAVOR", "FAVUS", "FAWNS", "FAWNY", "FAXED", "FAXES", "FAYAL", "FAYED", "FAZED", "FAZES", "FCHAR", "FCOMP", "FCONV", "FDUBS", "FEARS", "FEASE", "FEAST", "FEATS", "FEATY", "FEAZE", "FECAL", "FECES", "FECIT", "FECKS", "FEDIA", "FEEDS", "FEEDY", "FEELS", "FEELY", "FEERE", "FEEST", "FEEZE", "FEIGN", "FEINT", "FEIST", "FELID", "FELIS", "FELIX", "FELLA", "FELLS", "FELLY", "FELON", "FELTS", "FELTY", "FELUP", "FEMES", "FEMIC", "FEMME", "FEMUR", "FENCE", "FENDS", "FENDY", "FENKS", "FENNY", "FEODS", "FEOFF", "FERAE", "FERAL", "FERES", "FERIA", "FERIE", "FERIO", "FERLY", "FERME", "FERMI", "FERNS", "FERNY", "FEROX", "FERRI", "FERRY", "FERTH", "FESSE", "FESTA", "FESTE", "FESTY", "FETAL", "FETAS", "FETCH", "FETED", "FETES", "FETID", "FETIS", "FETOR", "FETUS", "FETWA", "FEUAR", "FEUDS", "FEUED", "FEUTE", "FEVER", "FEWER", "FEYER", "FEZES", "FEZZY", "FGRID", "FHRER", "FIANT", "FIARD", "FIARS", "FIATS", "FIBER", "FIBRA", "FIBRE", "FIBRO", "FIBRY", "FICES", "FICHE", "FICHU", "FICIN", "FICUS", "FIDAC", "FIDEL", "FIDES", "FIDGE", "FIDIA", "FIDOS", "FIEFS", "FIELD", "FIEND", "FIENT", "FIERI", "FIERY", "FIFED", "FIFER", "FIFES", "FIFIE", "FIFTH", "FIFTY", "FIGGY", "FIGHT", "FIKED", "FIKEY", "FIKIE", "FILAO", "FILAR", "FILCH", "FILEA", "FILED", "FILER", "FILES", "FILET", "FILII", "FILIX", "FILLA", "FILLE", "FILLS", "FILLY", "FILMS", "FILMY", "FILTH", "FILUM", "FINAL", "FINCA", "FINCH", "FINDS", "FINDY", "FINED", "FINER", "FINES", "FINEW", "FINGU", "FINIS", "FINKS", "FINNS", "FINNY", "FIORD", "FIQUE", "FIRCA", "FIRED", "FIRER", "FIRES", "FIRMA", "FIRMS", "FIRNS", "FIRRY", "FIRST", "FIRTH", "FISCS", "FISHY", "FISTS", "FISTY", "FITCH", "FITLY", "FITTY", "FIVER", "FIVES", "FIXED", "FIXER", "FIXES", "FIXUP", "FIZZY", "FJELD", "FJORD", "FLABS", "FLACK", "FLAFF", "FLAGS", "FLAIL", "FLAIN", "FLAIR", "FLAKE", "FLAKY", "FLAMB", "FLAME", "FLAMS", "FLAMY", "FLANE", "FLANG", "FLANK", "FLANS", "FLAPS", "FLARE", "FLARY", "FLASH", "FLASK", "FLATS", "FLAVO", "FLAWN", "FLAWS", "FLAWY", "FLAXY", "FLAYS", "FLCHE", "FLDXT", "FLEAK", "FLEAM", "FLEAR", "FLEAS", "FLEAY", "FLECK", "FLECT", "FLEER", "FLEES", "FLEET", "FLEGM", "FLEME", "FLESH", "FLETA", "FLEUR", "FLEWS", "FLEXO", "FLEYS", "FLICK", "FLICS", "FLIED", "FLIER", "FLIES", "FLIMP", "FLING", "FLINT", "FLIPE", "FLIPS", "FLIRT", "FLISK", "FLITE", "FLITS", "FLOAD", "FLOAT", "FLOCK", "FLOCS", "FLOES", "FLOEY", "FLOGS", "FLOIT", "FLONG", "FLOOD", "FLOOK", "FLOOR", "FLOPS", "FLORA", "FLORY", "FLOSH", "FLOSS", "FLOTA", "FLOTE", "FLOTS", "FLOUR", "FLOUT", "FLOWE", "FLOWK", "FLOWN", "FLOWS", "FLOYD", "FLOYT", "FLRIE", "FLUBS", "FLUED", "FLUER", "FLUES", "FLUEY", "FLUFF", "FLUID", "FLUKE", "FLUKY", "FLUME", "FLUMP", "FLUNG", "FLUNK", "FLUOR", "FLURN", "FLURR", "FLURT", "FLUSH", "FLUSK", "FLUTE", "FLUTY", "FLUYT", "FLYBY", "FLYER", "FLYPE", "FLYTE", "FNAME", "FNESE", "FOALS", "FOALY", "FOAMS", "FOAMY", "FOCAL", "FOCUS", "FODDA", "FODER", "FODGE", "FOEHN", "FOETI", "FOGAS", "FOGEY", "FOGGY", "FOGIE", "FOGLE", "FOGON", "FOGOU", "FOGUS", "FOHAT", "FOHNS", "FOILS", "FOINS", "FOISM", "FOIST", "FOLDS", "FOLDY", "FOLIA", "FOLIC", "FOLIE", "FOLIO", "FOLKS", "FOLKY", "FOLLY", "FOMES", "FONDS", "FONDU", "FONLY", "FONTS", "FOODS", "FOODY", "FOOLS", "FOOTS", "FOOTY", "FOPPY", "FORAM", "FORAY", "FORBS", "FORBY", "FORCE", "FORCY", "FORDO", "FORDS", "FORDY", "FOREL", "FORES", "FORET", "FOREX", "FORGE", "FORGO", "FORKS", "FORKY", "FORMA", "FORME", "FORMS", "FORMY", "FORRA", "FORST", "FORTE", "FORTH", "FORTS", "FORTY", "FORUM", "FOSIE", "FOSSA", "FOSSE", "FOTCH", "FOTUI", "FOULS", "FOUND", "FOUNT", "FOURB", "FOURS", "FOUTE", "FOUTH", "FOUTY", "FOVEA", "FOWLS", "FOXED", "FOXER", "FOXES", "FOXIE", "FOXLY", "FOYER", "FPLOT", "FPSPS", "FRACK", "FRACT", "FRAGS", "FRAID", "FRAIK", "FRAIL", "FRAME", "FRANC", "FRANK", "FRANZ", "FRAPE", "FRAPP", "FRAPS", "FRARY", "FRASE", "FRASS", "FRATE", "FRATS", "FRAUD", "FRAUS", "FRAWN", "FRAYN", "FRAYS", "FRAZE", "FRDEN", "FREAK", "FREAM", "FRECK", "FREED", "FREEN", "FREER", "FREES", "FREET", "FREIR", "FREIT", "FREMD", "FREMT", "FRENA", "FREON", "FRERE", "FRESH", "FRESS", "FRETS", "FRETT", "FREUD", "FREYA", "FREYR", "FRIAR", "FRIED", "FRIER", "FRIES", "FRIGS", "FRIJA", "FRIKE", "FRILL", "FRISE", "FRISK", "FRISS", "FRIST", "FRITH", "FRITS", "FRITT", "FRITZ", "FRIZE", "FRIZZ", "FROCK", "FROES", "FROGS", "FROND", "FRONS", "FRONT", "FROOM", "FRORE", "FRORY", "FROSH", "FROSK", "FROST", "FROTH", "FROWL", "FROWN", "FROWS", "FROWY", "FROZE", "FRUGS", "FRUIT", "FRUMP", "FRUSH", "FRUST", "FRYER", "FUAGE", "FUBBY", "FUBSY", "FUCHI", "FUCKS", "FUCUS", "FUDER", "FUDGE", "FUDGY", "FUELS", "FUFFY", "FUGAL", "FUGGY", "FUGIE", "FUGIO", "FUGIT", "FUGLE", "FUGUE", "FUJIS", "FULAH", "FULLS", "FULLY", "FULTH", "FULTZ", "FULUP", "FULWA", "FUMED", "FUMER", "FUMES", "FUMET", "FUMID", "FUNDI", "FUNDS", "FUNGE", "FUNGI", "FUNGO", "FUNIC", "FUNIS", "FUNJE", "FUNKS", "FUNKY", "FUNLI", "FUNNY", "FURAL", "FURAN", "FURCA", "FURIL", "FURLS", "FUROR", "FURRY", "FURUD", "FURYL", "FURZE", "FURZY", "FUSED", "FUSEE", "FUSEL", "FUSES", "FUSHT", "FUSIL", "FUSSY", "FUSTY", "FUSUS", "FUTWA", "FUZED", "FUZEE", "FUZES", "FUZIL", "FUZZY", "FYCES", "FYKES", "FYTTE", "GABBY", "GABLE", "GABON", "GADDI", "GADER", "GADES", "GADGE", "GADID", "GADIS", "GADSO", "GADUS", "GAELS", "GAFFE", "GAFFS", "GAGED", "GAGEE", "GAGER", "GAGES", "GAGOR", "GAILY", "GAINE", "GAINS", "GAIST", "GAITS", "GAITT", "GAIUS", "GAIZE", "GALAH", "GALAS", "GALAX", "GALBE", "GALEA", "GALEE", "GALEI", "GALEN", "GALES", "GALET", "GALEY", "GALGA", "GALIK", "GALLA", "GALLI", "GALLS", "GALLY", "GALOP", "GALUT", "GALVO", "GAMBA", "GAMBE", "GAMBS", "GAMED", "GAMER", "GAMES", "GAMEY", "GAMIC", "GAMIN", "GAMMA", "GAMMY", "GAMPS", "GAMUT", "GANAM", "GANCH", "GANDA", "GANEF", "GANEV", "GANGA", "GANGE", "GANGS", "GANJA", "GANOF", "GANSA", "GANSY", "GANTA", "GANZA", "GAOLS", "GAPED", "GAPER", "GAPES", "GAPPY", "GARAD", "GARAU", "GARBO", "GARBS", "GARCE", "GARDE", "GARDY", "GAREH", "GARLE", "GARNI", "GARON", "GAROO", "GARSE", "GARTH", "GARUA", "GARUM", "GASAN", "GASES", "GASHY", "GASPS", "GASPY", "GASSY", "GASTS", "GATCH", "GATED", "GATER", "GATES", "GATHA", "GATOR", "GAUBY", "GAUCY", "GAUDS", "GAUDY", "GAUGE", "GAULS", "GAULT", "GAUMS", "GAUMY", "GAUNT", "GAURA", "GAURE", "GAURS", "GAUSS", "GAUZE", "GAUZY", "GAVEL", "GAVIA", "GAVOT", "GAWBY", "GAWKS", "GAWKY", "GAWSY", "GAYAL", "GAYER", "GAYLY", "GAZED", "GAZEE", "GAZEL", "GAZER", "GAZES", "GAZET", "GAZON", "GAZOZ", "GCONV", "GEARS", "GEASE", "GEAST", "GEBUR", "GECKO", "GECKS", "GEDDS", "GEEKS", "GEESE", "GEEST", "GEHEY", "GEIRA", "GEISA", "GEIST", "GEKKO", "GELDS", "GELEE", "GELID", "GELLY", "GELTS", "GEMEL", "GEMMA", "GEMMY", "GEMOT", "GEMSE", "GEMUL", "GENAE", "GENAL", "GENEP", "GENES", "GENET", "GENIC", "GENIE", "GENII", "GENIN", "GENIO", "GENIP", "GENIT", "GENNY", "GENOA", "GENOM", "GENOS", "GENRE", "GENRO", "GENTS", "GENTY", "GENUA", "GENUS", "GENYS", "GEODE", "GEOFF", "GEOID", "GEOTY", "GERAH", "GERBE", "GERBO", "GERIM", "GERIP", "GERMS", "GERMY", "GESAN", "GESSO", "GESTE", "GESTS", "GETAE", "GETAH", "GETAS", "GETFD", "GETIC", "GETID", "GETUP", "GEUMS", "GEYAN", "GHAIN", "GHANA", "GHAST", "GHATS", "GHAUT", "GHAZI", "GHBOR", "GHEES", "GHENT", "GHESS", "GHOLE", "GHOOM", "GHOST", "GHOUL", "GHYLL", "GIANT", "GIBBI", "GIBBY", "GIBED", "GIBEL", "GIBER", "GIBES", "GIBLI", "GIBUS", "GIDDY", "GIFTS", "GIGAS", "GIGGE", "GIGHE", "GIGOT", "GIGUE", "GIHER", "GILDS", "GILES", "GILET", "GILIA", "GILIM", "GILLS", "GILLY", "GILPY", "GILSE", "GILTS", "GILTY", "GIMEL", "GIMME", "GIMPS", "GIMPY", "GINEP", "GINKS", "GINNY", "GINZO", "GIPON", "GIPPO", "GIPPY", "GIPSY", "GIRBA", "GIRDS", "GIRJA", "GIRLS", "GIRLY", "GIRNS", "GIRNY", "GIRON", "GIROS", "GIRSE", "GIRSH", "GIRTH", "GIRTS", "GISEL", "GISLA", "GISMO", "GISTS", "GITIM", "GIUST", "GIVEN", "GIVER", "GIVES", "GIVEY", "GIVIN", "GIZMO", "GLACE", "GLACK", "GLADE", "GLADS", "GLADY", "GLAGA", "GLAIK", "GLAIR", "GLAKY", "GLALI", "GLAND", "GLANS", "GLARE", "GLARY", "GLASS", "GLAUM", "GLAUR", "GLAUX", "GLAVE", "GLAZE", "GLAZY", "GLEAD", "GLEAM", "GLEAN", "GLEBA", "GLEBE", "GLEBY", "GLEDE", "GLEDS", "GLEDY", "GLEED", "GLEEK", "GLEEN", "GLEES", "GLEET", "GLEIR", "GLEIT", "GLENE", "GLENN", "GLENS", "GLENT", "GLEYS", "GLIAL", "GLICK", "GLIDE", "GLIFF", "GLIKE", "GLIME", "GLIMS", "GLINK", "GLINT", "GLISK", "GLISS", "GLIST", "GLOAM", "GLOAT", "GLOBE", "GLOBS", "GLOBY", "GLOEA", "GLOGG", "GLOME", "GLOMI", "GLOMS", "GLOOD", "GLOOM", "GLOPS", "GLORE", "GLORY", "GLOSS", "GLOST", "GLOUT", "GLOVE", "GLOWS", "GLOZE", "GLUCK", "GLUED", "GLUER", "GLUES", "GLUEY", "GLUMA", "GLUME", "GLUMP", "GLUON", "GLUTS", "GLYNN", "GLYPH", "GNARL", "GNARR", "GNARS", "GNASH", "GNAST", "GNATS", "GNAWN", "GNAWS", "GNIDE", "GNOFF", "GNOME", "GOADS", "GOALA", "GOALS", "GOATS", "GOATY", "GOAVE", "GOBAN", "GOBBE", "GOBBY", "GOBET", "GOBIA", "GOBIO", "GOBOS", "GODET", "GODLY", "GOERS", "GOETY", "GOFER", "GOGGA", "GOGOS", "GOING", "GOLDI", "GOLDS", "GOLDY", "GOLEE", "GOLEM", "GOLES", "GOLET", "GOLFS", "GOLGI", "GOLLY", "GOLOE", "GOLPE", "GOMBO", "GOMER", "GONAD", "GONAL", "GONDI", "GONER", "GONEY", "GONGS", "GONIA", "GONID", "GONIF", "GONNA", "GONNE", "GONOF", "GONYS", "GONZO", "GOODS", "GOODY", "GOOEY", "GOOFS", "GOOFY", "GOOKS", "GOOKY", "GOOLS", "GOOMA", "GOONS", "GOONY", "GOOPS", "GOOPY", "GOOSE", "GOOSY", "GOPAK", "GORAL", "GORAN", "GORCE", "GORED", "GORER", "GORES", "GORGE", "GORIC", "GORKI", "GORRA", "GORRY", "GORSE", "GORST", "GORSY", "GOSSY", "GOTCH", "GOTER", "GOTHA", "GOTHS", "GOTOS", "GOTRA", "GOTTA", "GOUDA", "GOUDY", "GOUGE", "GOUMI", "GOURA", "GOURD", "GOURY", "GOUTS", "GOUTY", "GOWAN", "GOWDS", "GOWDY", "GOWKS", "GOWNS", "GOXES", "GOYIM", "GOYIN", "GOYLE", "GRAAL", "GRABS", "GRACE", "GRACY", "GRADE", "GRADS", "GRAFF", "GRAFT", "GRAIL", "GRAIN", "GRAIP", "GRAMA", "GRAME", "GRAMP", "GRAMS", "GRAMY", "GRANA", "GRAND", "GRANE", "GRANK", "GRANO", "GRANT", "GRAPE", "GRAPH", "GRAPY", "GRASP", "GRASS", "GRATA", "GRATE", "GRAVE", "GRAVY", "GRAYS", "GRAZE", "GREAT", "GREBE", "GREBO", "GRECE", "GRECO", "GREED", "GREEK", "GREEN", "GREES", "GREET", "GREGE", "GREGG", "GREGO", "GREIN", "GREIT", "GRENE", "GRETA", "GRETE", "GREWT", "GREYS", "GRICE", "GRIDE", "GRIDS", "GRIEF", "GRIFF", "GRIFT", "GRIGS", "GRIKE", "GRILL", "GRIME", "GRIMM", "GRIMP", "GRIMY", "GRIND", "GRINS", "GRINT", "GRIOT", "GRIPE", "GRIPH", "GRIPS", "GRIPT", "GRIPY", "GRISE", "GRIST", "GRITH", "GRITS", "GROAN", "GROAT", "GROFF", "GROGS", "GROIN", "GROMA", "GROND", "GRONT", "GROOF", "GROOM", "GROOP", "GROOT", "GROOW", "GROPE", "GROSS", "GROSZ", "GROTE", "GROTS", "GROUF", "GROUP", "GROUT", "GROVE", "GROVY", "GROWL", "GROWN", "GROWS", "GRUBS", "GRUEL", "GRUES", "GRUFF", "GRUFT", "GRUIS", "GRUME", "GRUMP", "GRUNT", "GRUSH", "GRUSS", "GRUYS", "GRYDE", "GRYPE", "GRYPH", "GTEAU", "GUABA", "GUACO", "GUAKA", "GUAMA", "GUANA", "GUANO", "GUANS", "GUARA", "GUARD", "GUARS", "GUARY", "GUASA", "GUATO", "GUAVA", "GUAZA", "GUBAT", "GUBBO", "GUCKI", "GUCKS", "GUDES", "GUDGE", "GUDOK", "GUELF", "GUESS", "GUEST", "GUFFS", "GUFFY", "GUGAL", "GUIAC", "GUIBA", "GUIDE", "GUIDO", "GUIDS", "GUIGE", "GUIJO", "GUILD", "GUILE", "GUILT", "GUILY", "GUIRO", "GUISE", "GUJAR", "GULAE", "GULAR", "GULAS", "GULCH", "GULES", "GULFS", "GULFY", "GULIX", "GULLS", "GULLY", "GULPH", "GULPS", "GULPY", "GUMBO", "GUMBY", "GUMLY", "GUMMA", "GUMMY", "GUNDA", "GUNDI", "GUNDY", "GUNGE", "GUNJA", "GUNKS", "GUNKY", "GUNNE", "GUNNY", "GUPPY", "GURAN", "GURDY", "GURGE", "GURIC", "GURLE", "GURLY", "GURRY", "GURSH", "GURTS", "GURUS", "GUSER", "GUSHY", "GUSLA", "GUSLE", "GUSSY", "GUSTO", "GUSTS", "GUSTY", "GUTSY", "GUTTA", "GUTTE", "GUTTI", "GUTTY", "GUYED", "GUYER", "GUYOT", "GUZUL", "GWEED", "GWELY", "GWINE", "GYBED", "GYBES", "GYGES", "GYGIS", "GYMEL", "GYNIC", "GYPPO", "GYPSY", "GYRAL", "GYRED", "GYRES", "GYRIC", "GYRON", "GYROS", "GYRUS", "GYVED", "GYVES", "HAAFS", "HAARS", "HABAB", "HABBE", "HABET", "HABIT", "HABLE", "HABUB", "HABUS", "HACEK", "HACHE", "HACHT", "HACKS", "HACKY", "HADAL", "HADDO", "HADED", "HADES", "HADIT", "HADJI", "HADNT", "HADST", "HAEMS", "HAETS", "HAFIS", "HAFIZ", "HAFTS", "HAGAR", "HAGGY", "HAGIA", "HAGUE", "HAICK", "HAIDA", "HAIKA", "HAIKH", "HAIKS", "HAIKU", "HAILS", "HAILY", "HAINE", "HAIRE", "HAIRS", "HAIRY", "HAITI", "HAJES", "HAJIB", "HAJIS", "HAJJI", "HAKAM", "HAKEA", "HAKES", "HAKIM", "HAKKA", "HALAL", "HALAS", "HALCH", "HALDU", "HALED", "HALER", "HALES", "HALFA", "HALFY", "HALID", "HALKE", "HALLO", "HALLS", "HALMA", "HALMS", "HALOA", "HALOS", "HALSE", "HALTE", "HALTS", "HALVA", "HALVE", "HALWE", "HAMAL", "HAMAN", "HAMEL", "HAMES", "HAMLI", "HAMMY", "HAMSA", "HAMUS", "HAMZA", "HANAP", "HANCE", "HANCH", "HANDS", "HANDY", "HANGE", "HANGS", "HANIF", "HANKS", "HANKT", "HANKY", "HANNA", "HANOI", "HANSA", "HANSE", "HANTS", "HAOLE", "HAOMA", "HAORI", "HAPAX", "HAPLY", "HAPPY", "HARAM", "HARAS", "HARBI", "HARDS", "HARDY", "HARED", "HAREM", "HARES", "HARIM", "HARKA", "HARKS", "HARLE", "HARLS", "HARMS", "HARNS", "HARPA", "HARPS", "HARPY", "HARRE", "HARRY", "HARSH", "HARST", "HARTS", "HASAN", "HASHT", "HASHY", "HASID", "HASKY", "HASNT", "HASPS", "HASTA", "HASTE", "HASTY", "HATCH", "HATED", "HATEL", "HATER", "HATES", "HATHI", "HATTE", "HATTI", "HATTY", "HAUGH", "HAULD", "HAULM", "HAULS", "HAULT", "HAUNT", "HAUSA", "HAUSE", "HAUST", "HAUTE", "HAVEL", "HAVEN", "HAVER", "HAVES", "HAVOC", "HAWED", "HAWER", "HAWKS", "HAWKY", "HAWOK", "HAWSE", "HAYDN", "HAYED", "HAYER", "HAYES", "HAYEY", "HAYNE", "HAZAN", "HAZED", "HAZEL", "HAZEN", "HAZER", "HAZES", "HAZLE", "HDQRS", "HEADS", "HEADY", "HEALD", "HEALS", "HEAPS", "HEAPY", "HEARD", "HEARS", "HEART", "HEATH", "HEATS", "HEAVE", "HEAVY", "HEAZY", "HEBEN", "HECCO", "HECHT", "HECKS", "HECTE", "HEDER", "HEDGE", "HEDGY", "HEEDS", "HEEDY", "HEELS", "HEEZE", "HEEZY", "HEFTS", "HEFTY", "HEIAU", "HEIDI", "HEIGH", "HEILD", "HEILS", "HEILY", "HEINZ", "HEIRS", "HEIST", "HEIZE", "HELAS", "HELCO", "HELEN", "HELGE", "HELIO", "HELIX", "HELLO", "HELLS", "HELLY", "HELMS", "HELOE", "HELOT", "HELPS", "HELVE", "HEMAD", "HEMAL", "HEMAN", "HEMEN", "HEMES", "HEMIC", "HEMIN", "HEMOL", "HEMPS", "HEMPY", "HENAD", "HENCE", "HENDY", "HENEN", "HENGE", "HENNA", "HENNY", "HENRY", "HENTS", "HEPAR", "HERAT", "HERBA", "HERBS", "HERBY", "HERDS", "HEREM", "HERES", "HERLS", "HERMA", "HERMI", "HERMO", "HERMS", "HERNE", "HERNS", "HERON", "HEROS", "HERRY", "HERSE", "HERTZ", "HERVE", "HESTS", "HETHS", "HETTY", "HEUAU", "HEUCH", "HEUGH", "HEVEA", "HEVED", "HEWED", "HEWEL", "HEWER", "HEWGH", "HEXAD", "HEXED", "HEXER", "HEXES", "HEXIS", "HEXYL", "HEYGH", "HIANT", "HIATE", "HIBLA", "HICHT", "HICHU", "HICKS", "HICKY", "HIDED", "HIDEL", "HIDER", "HIDES", "HIELD", "HIEMS", "HIENZ", "HIERA", "HIGHS", "HIGHT", "HIGRA", "HIJRA", "HIKED", "HIKER", "HIKES", "HILAR", "HILCH", "HILDA", "HILLO", "HILLS", "HILLY", "HILSA", "HILTS", "HILUM", "HILUS", "HIMNE", "HINAU", "HINCH", "HINDI", "HINDS", "HINDU", "HINEY", "HINGE", "HINNY", "HINTS", "HIPER", "HIPMI", "HIPPA", "HIPPI", "HIPPO", "HIPPY", "HIRAM", "HIRED", "HIREN", "HIRER", "HIRES", "HIRSE", "HIRST", "HISIS", "HISPA", "HISSY", "HISTS", "HITCH", "HITHE", "HIVED", "HIVER", "HIVES", "HOAGY", "HOARD", "HOARS", "HOARY", "HOAST", "HOBBY", "HOBOE", "HOBOS", "HOCCO", "HOCKS", "HOCKY", "HOCUS", "HODAD", "HODDY", "HODGE", "HOERS", "HOGAN", "HOGEN", "HOGGS", "HOGGY", "HOGNI", "HOICK", "HOISE", "HOIST", "HOKAN", "HOKED", "HOKER", "HOKES", "HOKEY", "HOKKU", "HOKUM", "HOLDS", "HOLED", "HOLER", "HOLES", "HOLEY", "HOLIA", "HOLKS", "HOLLA", "HOLLO", "HOLLY", "HOLMS", "HOLTS", "HOMAM", "HOMED", "HOMER", "HOMES", "HOMEY", "HOMME", "HOMOS", "HONAN", "HONDA", "HONDO", "HONED", "HONER", "HONES", "HONEY", "HONGS", "HONKS", "HONKY", "HONOR", "HONZO", "HOOCH", "HOODS", "HOODY", "HOOEY", "HOOFS", "HOOFY", "HOOKA", "HOOKS", "HOOKY", "HOOLY", "HOOPS", "HOOSE", "HOOSH", "HOOTS", "HOOVE", "HOOYE", "HOPAK", "HOPED", "HOPER", "HOPES", "HOPIS", "HOPPO", "HOPPY", "HORAE", "HORAH", "HORAL", "HORAS", "HORDE", "HORIM", "HORLA", "HORME", "HORNS", "HORNY", "HOROL", "HORRY", "HORSE", "HORST", "HORSY", "HOSEA", "HOSED", "HOSEL", "HOSEN", "HOSES", "HOSTA", "HOSTS", "HOTCH", "HOTEL", "HOTLY", "HOTTA", "HOUGH", "HOULT", "HOUND", "HOURI", "HOURS", "HOUSE", "HOUSS", "HOUSY", "HOUVE", "HOVEL", "HOVEN", "HOVER", "HOWDY", "HOWEA", "HOWEL", "HOWES", "HOWFF", "HOWFS", "HOWKS", "HOWLS", "HOWSO", "HOYLE", "HSIEN", "HSUAN", "HUACA", "HUACO", "HUARI", "HUAVE", "HUBBA", "HUBBY", "HUCHO", "HUCKS", "HUFFS", "HUFFY", "HUGER", "HUILE", "HULAS", "HULCH", "HULKS", "HULKY", "HULLO", "HULLS", "HUMAN", "HUMBO", "HUMET", "HUMIC", "HUMID", "HUMIN", "HUMIT", "HUMOR", "HUMPH", "HUMPS", "HUMPY", "HUMUS", "HUNCH", "HUNDI", "HUNKS", "HUNKY", "HUNTS", "HURDS", "HURLS", "HURLY", "HURON", "HURRI", "HURRY", "HURST", "HURTS", "HURTY", "HUSHO", "HUSHT", "HUSKS", "HUSKY", "HUSSY", "HUTCH", "HUTIA", "HUTRE", "HUZZA", "HUZZY", "HYBLA", "HYDRA", "HYDRO", "HYENA", "HYING", "HYLAS", "HYLEG", "HYLIC", "HYMEN", "HYMNS", "HYNDE", "HYOID", "HYPED", "HYPER", "HYPES", "HYPHA", "HYPHO", "HYPOS", "HYRAX", "HYRSE", "HYRST", "HYSON", "IAMBE", "IAMBI", "IAMBS", "IANUS", "IBERI", "IBOTA", "ICACO", "ICASM", "ICENI", "ICHOR", "ICHTH", "ICICA", "ICIER", "ICILY", "ICING", "ICKER", "ICKLE", "ICONS", "ICONV", "ICTIC", "ICTUS", "IDAHO", "IDAIC", "IDANT", "IDCUE", "IDDAT", "IDDHI", "IDDIO", "IDEAL", "IDEAN", "IDEAS", "IDENT", "IDEST", "IDETA", "IDGAH", "IDIOM", "IDION", "IDIOT", "IDISM", "IDIST", "IDITE", "IDLED", "IDLER", "IDLES", "IDOLA", "IDOLS", "IDOSE", "IDRYL", "IDYLL", "IDYLS", "IERNE", "IFINT", "IFREE", "IFRIT", "IGARA", "IGDYR", "IGHLY", "IGLOO", "IGLUS", "IGNAW", "IGNIS", "IHLAT", "IHRAM", "IIASA", "IJMAA", "IJORE", "IKARY", "IKONA", "IKONS", "ILAMA", "ILEAC", "ILEAL", "ILEON", "ILEUM", "ILEUS", "ILIAC", "ILIAD", "ILIAL", "ILIAN", "ILIAU", "ILIMA", "ILION", "ILIUM", "ILLER", "ILLTH", "ILLUS", "ILOKO", "IMAGE", "IMAGO", "IMAMS", "IMAUM", "IMBAN", "IMBAT", "IMBED", "IMBER", "IMBUE", "IMCNT", "IMIDE", "IMIDO", "IMIDS", "IMINE", "IMINO", "IMMEW", "IMMIS", "IMMIT", "IMMIX", "IMMOV", "IMMUN", "IMPAR", "IMPED", "IMPEL", "IMPEN", "IMPER", "IMPIS", "IMPLY", "IMPOT", "IMPUT", "IMSHI", "IMVIA", "INACT", "INAJA", "INANE", "INAPT", "INARK", "INARM", "INBOW", "INBYE", "INCAN", "INCAS", "INCLE", "INCOG", "INCOR", "INCRA", "INCUR", "INCUS", "INCUT", "INDAN", "INDEF", "INDEW", "INDEX", "INDIA", "INDIC", "INDII", "INDIN", "INDIV", "INDOL", "INDOW", "INDRA", "INDRI", "INDUC", "INDUE", "INDUS", "INDYL", "INEPT", "INERI", "INERM", "INERT", "INEYE", "INFER", "INFIN", "INFIT", "INFIX", "INFOS", "INFRA", "INGAN", "INGEM", "INGER", "INGLE", "INGLU", "INGOT", "INIAL", "INIGO", "INION", "INJUN", "INKED", "INKEN", "INKER", "INKET", "INKIE", "INKLE", "INKOS", "INKRA", "INLAW", "INLAY", "INLET", "INMEW", "INNED", "INNER", "INNET", "INOMA", "INONE", "INORB", "INORG", "INPUT", "INROL", "INRUB", "INRUN", "INSEA", "INSEE", "INSEP", "INSET", "INSOL", "INSTR", "INSUE", "INTEL", "INTER", "INTIL", "INTNL", "INTRA", "INTRO", "INTSV", "INTUE", "INULA", "INURE", "INURN", "INUST", "INVAR", "INVOY", "INWIT", "IODAL", "IODIC", "IODID", "IODIN", "IODOL", "IONIC", "IORTN", "IOTAS", "IOWAN", "IPHIS", "IRADE", "IRANI", "IRAQI", "IRATE", "IRBIS", "IRENA", "IRENE", "IREOS", "IRFAN", "IRGUN", "IRIAN", "IRIDO", "IRING", "IRISH", "IRKED", "IROHA", "IROKO", "IRONE", "IRONS", "IRONY", "IROUS", "IRPEX", "IRRED", "IRREG", "IRVIN", "IRWIN", "ISAAC", "ISAWA", "ISBAS", "ISEUM", "ISIAC", "ISING", "ISIZE", "ISLAM", "ISLAY", "ISLED", "ISLES", "ISLET", "ISLOT", "ISMAL", "ISNAD", "ISOLN", "ISORT", "ISSEI", "ISSUE", "ISTHM", "ISTLE", "ITALA", "ITALI", "ITALY", "ITCHY", "ITCZE", "ITEMS", "ITEMY", "ITERS", "ITHER", "IULUS", "IVIED", "IVIES", "IVORY", "IVRAY", "IXIAS", "IXION", "IXORA", "IXTLE", "IZARD", "IZARS", "IZING", "IZOTE", "IZTLE", "IZUMI", "IZZAT", "JABIA", "JABOT", "JABUL", "JACAL", "JACHT", "JACKO", "JACKS", "JACKY", "JACOB", "JADED", "JADES", "JAGAT", "JAGER", "JAGGS", "JAGGY", "JAGIR", "JAGLA", "JAGRA", "JAGUA", "JAHVE", "JAILS", "JAIME", "JAINA", "JAKES", "JAKEY", "JAKOB", "JAKOS", "JAKUN", "JALAP", "JALEE", "JALET", "JALOP", "JALOR", "JALUR", "JAMAN", "JAMBE", "JAMBO", "JAMBS", "JAMES", "JAMIE", "JAMMY", "JANES", "JANET", "JANOS", "JANTU", "JANTY", "JANUA", "JANUS", "JAPAN", "JAPED", "JAPER", "JAPES", "JAPYX", "JARDE", "JARED", "JARLS", "JARMO", "JARRA", "JARRY", "JARVY", "JASEY", "JASON", "JASPE", "JATHA", "JATKI", "JATNI", "JATOS", "JAUKS", "JAUNT", "JAUPS", "JAVAN", "JAVAS", "JAVEL", "JAVER", "JAWAB", "JAWAN", "JAWED", "JAZEY", "JAZZY", "JEANS", "JEANY", "JEBAT", "JEBEL", "JEBUS", "JEEPS", "JEERS", "JEERY", "JEFES", "JEHAD", "JEHUP", "JEHUS", "JELAB", "JELIB", "JELLO", "JELLS", "JELLY", "JEMBE", "JEMEZ", "JEMMY", "JENNA", "JENNY", "JEREZ", "JERIB", "JERID", "JERKS", "JERKY", "JERRY", "JESSE", "JESTS", "JESUS", "JETES", "JETON", "JETTY", "JEWED", "JEWEL", "JEWIS", "JEWRY", "JHEEL", "JHOOL", "JIBBA", "JIBBS", "JIBBY", "JIBED", "JIBER", "JIBES", "JIBOA", "JIFFS", "JIFFY", "JIGGY", "JIHAD", "JILLS", "JILTS", "JIMBO", "JIMMY", "JIMPY", "JINGO", "JINGU", "JINJA", "JINKS", "JINNI", "JINNS", "JINNY", "JIQUI", "JIRGA", "JISMS", "JITRO", "JIVED", "JIVES", "JIXIE", "JIZYA", "JNANA", "JOCKO", "JOCKS", "JOCUM", "JODEL", "JOEYS", "JOHAN", "JOHNS", "JOINS", "JOINT", "JOIST", "JOKED", "JOKER", "JOKES", "JOKEY", "JOKUL", "JOLES", "JOLLY", "JOLTS", "JOLTY", "JOMON", "JONAH", "JONAS", "JONES", "JOOLA", "JORAM", "JOREE", "JORGE", "JORUM", "JOSEY", "JOSHI", "JOSIE", "JOSIP", "JOTAS", "JOTTY", "JOUAL", "JOUGH", "JOUGS", "JOUKS", "JOULE", "JOURN", "JOURS", "JOUST", "JOWAR", "JOWED", "JOWEL", "JOWER", "JOWLS", "JOWLY", "JOWPY", "JOYCE", "JOYED", "JUANG", "JUANS", "JUBAS", "JUBBE", "JUBES", "JUBUS", "JUDAH", "JUDAS", "JUDEX", "JUDGE", "JUDOS", "JUFTI", "JUFTS", "JUGAL", "JUGER", "JUGUM", "JUICE", "JUICY", "JUISE", "JUJUS", "JUKED", "JUKES", "JULEP", "JULES", "JULIA", "JULID", "JULIE", "JULIO", "JULUS", "JUMBA", "JUMBO", "JUMBY", "JUMMA", "JUMPS", "JUMPY", "JUNCO", "JUNDY", "JUNKS", "JUNKY", "JUNTA", "JUNTO", "JUPES", "JUPON", "JURAL", "JURAT", "JUREL", "JURIS", "JUROR", "JUSSI", "JUSTO", "JUSTS", "JUTES", "JUTIC", "JUTKA", "JUTTY", "JUVIA", "JUXTA", "JUYAS", "KAABA", "KAAMA", "KABAB", "KABAR", "KABEL", "KABOB", "KACHA", "KADIS", "KADMI", "KADOS", "KAFIR", "KAFIZ", "KAFKA", "KAFTA", "KAGOS", "KAGUS", "KAHAR", "KAHAU", "KAIAK", "KAIFS", "KAILS", "KAIMO", "KAINS", "KAIWI", "KAJAR", "KAKAN", "KAKAR", "KAKAS", "KAKIS", "KAKKE", "KALAM", "KALAN", "KALES", "KALIF", "KALIS", "KALON", "KALPA", "KAMAO", "KAMAS", "KAMBA", "KAMEL", "KAMES", "KAMIK", "KAMIS", "KANAE", "KANAP", "KANAS", "KANAT", "KANDE", "KANEH", "KANES", "KANGA", "KANJI", "KANNU", "KANSA", "KANZU", "KAONS", "KAPAI", "KAPAS", "KAPHS", "KAPOK", "KAPPA", "KAPPE", "KAPUR", "KAPUT", "KARAT", "KARBI", "KARCH", "KAREL", "KAREN", "KAREZ", "KARMA", "KARNS", "KAROO", "KAROS", "KAROU", "KARRI", "KARST", "KARTS", "KASER", "KASHA", "KASHI", "KASKA", "KASSU", "KATAR", "KATAT", "KATHA", "KATHY", "KATIE", "KATIK", "KATUN", "KAUCH", "KAURI", "KAURY", "KAVAS", "KAVER", "KAYAK", "KAYAN", "KAYOS", "KAZAK", "KAZOO", "KEACH", "KEARN", "KEATS", "KEAWE", "KEBAB", "KEBAR", "KEBBY", "KEBOB", "KECKS", "KECKY", "KEDAR", "KEDGE", "KEDGY", "KEECH", "KEEFS", "KEEKS", "KEELS", "KEENA", "KEENS", "KEEPS", "KEEST", "KEETS", "KEEVE", "KEFIR", "KEFTI", "KEIRS", "KEIST", "KEITA", "KEITH", "KELEH", "KELEK", "KELEP", "KELIA", "KELLA", "KELLY", "KELPS", "KELPY", "KELTS", "KELTY", "KEMAL", "KEMPS", "KEMPT", "KEMPY", "KENAF", "KENAI", "KENCH", "KENDO", "KENDY", "KENNO", "KENNY", "KENOS", "KENTE", "KENYA", "KEOUT", "KEPIS", "KERAT", "KERBS", "KERCH", "KEREL", "KERES", "KERFS", "KERNE", "KERNS", "KEROS", "KERRI", "KERRY", "KERVE", "KERYX", "KESAR", "KESSE", "KETAL", "KETCH", "KETEN", "KETOL", "KETTE", "KETTY", "KETYL", "KEVAN", "KEVEL", "KEVER", "KEVIL", "KEVIN", "KEVYN", "KEXES", "KEYED", "KEYWD", "KHADI", "KHAIR", "KHAJA", "KHAKI", "KHAMI", "KHANS", "KHASA", "KHASI", "KHASS", "KHATS", "KHAYA", "KHEDA", "KHILA", "KHMER", "KHOJA", "KHOKA", "KHOND", "KHUAI", "KHULA", "KHUZI", "KHVAT", "KIAAT", "KIACK", "KIAKI", "KIANG", "KIBEI", "KIBES", "KIBLA", "KICKS", "KICKY", "KIDDO", "KIDDY", "KIEFS", "KIERS", "KIEYE", "KIKAR", "KIKES", "KIKKI", "KIKOI", "KILAH", "KILAN", "KILEH", "KILEY", "KILIJ", "KILIM", "KILLS", "KILLY", "KILNS", "KILOM", "KILOS", "KILTS", "KILTY", "KIMBO", "KIMMO", "KINAH", "KINCH", "KINDS", "KINES", "KINGS", "KINGU", "KINIC", "KININ", "KINKS", "KINKY", "KINOO", "KINOS", "KINOT", "KIOEA", "KIOKO", "KIOSK", "KIOWA", "KIPPY", "KIRBY", "KIRKS", "KIRNS", "KIRVE", "KISAN", "KISHY", "KISRA", "KISSY", "KISTS", "KISWA", "KITAB", "KITAN", "KITAR", "KITED", "KITER", "KITES", "KITHE", "KITHS", "KITTY", "KIVAS", "KIVER", "KIWAI", "KIWIS", "KIYAS", "KIZIL", "KLANS", "KLAUS", "KLEIG", "KLICK", "KLIEG", "KLING", "KLINO", "KLONG", "KLOOF", "KLOPS", "KLOSH", "KLUCK", "KLUNK", "KLUTZ", "KMOLE", "KNACK", "KNAPE", "KNAPS", "KNARK", "KNARL", "KNARS", "KNAVE", "KNEAD", "KNEED", "KNEEL", "KNEES", "KNELL", "KNELT", "KNEZI", "KNIAZ", "KNICK", "KNIFE", "KNISH", "KNITS", "KNIVE", "KNOBS", "KNOCK", "KNOIT", "KNOLL", "KNOPS", "KNORR", "KNOSP", "KNOTS", "KNOUT", "KNOWE", "KNOWN", "KNOWS", "KNURL", "KNURS", "KNUTE", "KNUTH", "KNYAZ", "KOALA", "KOALI", "KOANS", "KOBAN", "KOBUS", "KODAK", "KODRO", "KOELS", "KOERI", "KOFTA", "KOGAI", "KOGIA", "KOHEN", "KOHLS", "KOHUA", "KOILA", "KOINE", "KOKAM", "KOKAN", "KOKIA", "KOKIL", "KOKIO", "KOKOS", "KOKRA", "KOKUM", "KOLAS", "KOLEA", "KOLIS", "KOLOS", "KOMBU", "KONAK", "KONDE", "KONDO", "KONGO", "KONGU", "KONIA", "KOOKA", "KOOKS", "KOOKY", "KOORG", "KOPEC", "KOPEK", "KOPHS", "KOPIS", "KOPJE", "KOPPA", "KORAH", "KORAI", "KORAN", "KOREA", "KOREC", "KORIN", "KORMA", "KOROA", "KORUN", "KORWA", "KOSHA", "KOSIN", "KOSOS", "KOTAL", "KOTAR", "KOTOS", "KOTOW", "KOUZA", "KOVIL", "KOYAN", "KRAAL", "KRAFT", "KRAIT", "KRAMA", "KRANG", "KRANS", "KRAUT", "KREBS", "KREIL", "KREIS", "KREMS", "KRENG", "KREPI", "KRILL", "KRINA", "KRISS", "KRIVU", "KROME", "KRONA", "KRONE", "KROON", "KROSA", "KRUBI", "KUBBA", "KUDOS", "KUDUS", "KUDZU", "KUFIC", "KUGEL", "KUKRI", "KUKUI", "KULAH", "KULAK", "KULAN", "KUMAN", "KUMBI", "KUMIS", "KUMNI", "KUMYK", "KUMYS", "KUNAI", "KUNBI", "KURKU", "KURMI", "KURTA", "KURUS", "KUSAM", "KUSAN", "KUSHA", "KUSSO", "KUSTI", "KUSUM", "KUTCH", "KUTTA", "KVASS", "KVINT", "KWAPA", "KWELA", "KYACK", "KYANG", "KYARS", "KYATS", "KYLIE", "KYLIN", "KYLIX", "KYLOE", "KYOTO", "KYRIE", "KYTES", "KYTHE", "KYUNG", "LAANG", "LABAN", "LABBA", "LABBY", "LABEL", "LABIA", "LABIS", "LABOR", "LABRA", "LACCA", "LACED", "LACER", "LACES", "LACET", "LACEY", "LACHE", "LACIS", "LACKS", "LACTO", "LADED", "LADEN", "LADER", "LADES", "LADIK", "LADIN", "LADLE", "LAETI", "LAEVO", "LAGAN", "LAGEN", "LAGER", "LAGLY", "LAGNA", "LAHAR", "LAICH", "LAICS", "LAIGH", "LAINE", "LAIRD", "LAIRS", "LAIRY", "LAITH", "LAITY", "LAIUS", "LAKED", "LAKER", "LAKES", "LAKEY", "LAKHS", "LAKIE", "LAKIN", "LAKKE", "LAKSA", "LALLS", "LALLY", "LAMAS", "LAMBA", "LAMBS", "LAMBY", "LAMDA", "LAMED", "LAMEL", "LAMER", "LAMES", "LAMIA", "LAMIN", "LAMMY", "LAMNA", "LAMPF", "LAMPS", "LAMUS", "LAMUT", "LANAI", "LANAO", "LANAS", "LANAZ", "LANCE", "LANCH", "LANDE", "LANDS", "LANES", "LANEY", "LANGI", "LANGO", "LANKY", "LANNY", "LANSA", "LANUM", "LAPEL", "LAPIN", "LAPIS", "LAPON", "LAPPA", "LAPPS", "LAPSE", "LAPSI", "LARCH", "LARDS", "LARDY", "LARES", "LARGE", "LARGO", "LARGY", "LARIA", "LARID", "LARIN", "LARIX", "LARKS", "LARKY", "LARON", "LARRY", "LARUM", "LARUS", "LARVA", "LARVE", "LASED", "LASER", "LASES", "LASSO", "LASSU", "LASTS", "LASTY", "LATAH", "LATAX", "LATCH", "LATED", "LATEN", "LATER", "LATEX", "LATHE", "LATHI", "LATHS", "LATHY", "LATIN", "LATKE", "LATON", "LATRO", "LATUS", "LAUAN", "LAUDE", "LAUDS", "LAUGH", "LAUIA", "LAUND", "LAURA", "LAURE", "LAURY", "LAUTU", "LAVAS", "LAVED", "LAVER", "LAVES", "LAVIC", "LAWED", "LAWKS", "LAWNS", "LAWNY", "LAWZY", "LAXER", "LAXLY", "LAYED", "LAYER", "LAYIA", "LAYNE", "LAYUP", "LAZAR", "LAZED", "LAZES", "LEACH", "LEADS", "LEADY", "LEAFS", "LEAFY", "LEAKS", "LEAKY", "LEANS", "LEANT", "LEANY", "LEAPS", "LEAPT", "LEARN", "LEARS", "LEARY", "LEASE", "LEASH", "LEAST", "LEATH", "LEAVE", "LEAVY", "LEBAN", "LEBEN", "LEBES", "LECHE", "LEDEN", "LEDGE", "LEDGY", "LEDOL", "LEDUM", "LEECH", "LEEDS", "LEEKS", "LEEKY", "LEERS", "LEERY", "LEESE", "LEETS", "LEFTS", "LEFTY", "LEGAL", "LEGER", "LEGES", "LEGGE", "LEGGY", "LEGIS", "LEGIT", "LEGOA", "LEGUA", "LEHAY", "LEHRS", "LEHUA", "LEIGH", "LEILA", "LEISS", "LEITH", "LEKHA", "LELIA", "LEMAN", "LEMEL", "LEMMA", "LEMNA", "LEMON", "LEMUR", "LENAD", "LENCA", "LENCH", "LENDS", "LENDU", "LENES", "LENIN", "LENIS", "LENNY", "LENOS", "LENSE", "LENTH", "LENTO", "LEONE", "LEORA", "LEPAL", "LEPAS", "LEPER", "LEPID", "LEPPY", "LEPRA", "LEPRE", "LEPRY", "LEPTA", "LEPUS", "LEROT", "LERWA", "LESED", "LESGH", "LESIY", "LESSN", "LESTE", "LESYA", "LETCH", "LETHE", "LETHY", "LETTY", "LETUP", "LEUCH", "LEUCO", "LEUDS", "LEUMA", "LEUNG", "LEVEE", "LEVEL", "LEVEN", "LEVER", "LEVET", "LEVIN", "LEVIR", "LEVIS", "LEWIE", "LEWIS", "LEWTH", "LEWTY", "LEXIA", "LEXIC", "LEXIS", "LHOTA", "LIANA", "LIANE", "LIANG", "LIARD", "LIARS", "LIBBY", "LIBEL", "LIBER", "LIBRA", "LIBRE", "LIBRI", "LIBYA", "LICCA", "LICET", "LICHI", "LICHT", "LICIT", "LICKS", "LIDAR", "LIDIA", "LIDOS", "LIEGE", "LIENS", "LIERS", "LIESH", "LIEST", "LIEUE", "LIEUS", "LIEUT", "LIEVE", "LIFEN", "LIFER", "LIFEY", "LIFTS", "LIGAN", "LIGAS", "LIGER", "LIGGE", "LIGHT", "LIGNE", "LIKED", "LIKEN", "LIKER", "LIKES", "LIKIN", "LILAC", "LILAS", "LILES", "LILLY", "LILTS", "LIMAN", "LIMAS", "LIMAX", "LIMBA", "LIMBI", "LIMBO", "LIMBS", "LIMBU", "LIMBY", "LIMED", "LIMEN", "LIMER", "LIMES", "LIMEY", "LIMIT", "LIMLI", "LIMMA", "LIMMU", "LIMNS", "LIMOS", "LIMPS", "LIMPY", "LIMSY", "LINAC", "LINCH", "LINDA", "LINDO", "LINDY", "LINEA", "LINED", "LINEN", "LINER", "LINES", "LINET", "LINEY", "LINGA", "LINGE", "LINGO", "LINGS", "LINGY", "LINHA", "LINIE", "LININ", "LINJA", "LINJE", "LINKS", "LINKY", "LINNE", "LINNS", "LINON", "LINOS", "LINTS", "LINTY", "LINUM", "LINUS", "LIONS", "LIPAN", "LIPIC", "LIPID", "LIPIN", "LIPPY", "LIPSE", "LIRAS", "LIROT", "LISLE", "LISPS", "LISTS", "LISTY", "LISZT", "LITAI", "LITAS", "LITCH", "LITER", "LITES", "LITHE", "LITHI", "LITHO", "LITHY", "LITRA", "LITRE", "LITUI", "LITUS", "LIVED", "LIVEN", "LIVER", "LIVES", "LIVID", "LIVOR", "LIVRE", "LIWAN", "LLAMA", "LLANO", "LLOYD", "LLUDD", "LOACH", "LOADS", "LOAFS", "LOAMS", "LOAMY", "LOANS", "LOASA", "LOATH", "LOAVE", "LOBAL", "LOBAR", "LOBBY", "LOBED", "LOBES", "LOBOS", "LOBUS", "LOCAL", "LOCHE", "LOCHI", "LOCHS", "LOCHY", "LOCKS", "LOCKY", "LOCOS", "LOCUM", "LOCUS", "LODEN", "LODES", "LODGE", "LODHA", "LODUR", "LOEIL", "LOESS", "LOFTS", "LOFTY", "LOGAN", "LOGES", "LOGGY", "LOGIA", "LOGIC", "LOGIE", "LOGIN", "LOGIS", "LOGOI", "LOGOS", "LOHAN", "LOHAR", "LOINS", "LOKAO", "LOKET", "LOLLS", "LOLLY", "LOMTA", "LONER", "LONGA", "LONGE", "LONGS", "LOOBY", "LOOCH", "LOOED", "LOOEY", "LOOFA", "LOOFS", "LOOIE", "LOOKS", "LOOKY", "LOOMS", "LOONS", "LOONY", "LOOPE", "LOOPS", "LOOPY", "LOORD", "LOORY", "LOOSE", "LOOTS", "LOPED", "LOPER", "LOPES", "LOPPY", "LORAL", "LORAN", "LORDS", "LORDY", "LORED", "LOREL", "LOREN", "LORES", "LORIC", "LORIS", "LOROS", "LORRY", "LORUM", "LOSEL", "LOSER", "LOSES", "LOSSY", "LOTAH", "LOTAN", "LOTAS", "LOTIC", "LOTOR", "LOTOS", "LOTTA", "LOTTE", "LOTTO", "LOTUS", "LOUCH", "LOUEY", "LOUGH", "LOUIE", "LOUIS", "LOULU", "LOUPE", "LOUPS", "LOURD", "LOURS", "LOURY", "LOUSE", "LOUSY", "LOUTS", "LOUTY", "LOVAT", "LOVED", "LOVEE", "LOVER", "LOVES", "LOVEY", "LOWAN", "LOWED", "LOWER", "LOWES", "LOWLY", "LOWRY", "LOWSE", "LOWTH", "LOXED", "LOXES", "LOXIA", "LOXIC", "LOYAL", "LRECL", "LUAUS", "LUBES", "LUBRA", "LUCAN", "LUCES", "LUCET", "LUCIA", "LUCID", "LUCKS", "LUCKY", "LUCRE", "LUDDY", "LUFFA", "LUFFS", "LUGER", "LUGES", "LUIAN", "LUIGI", "LUITE", "LUKAN", "LUKAS", "LUKET", "LULAB", "LULAV", "LULLS", "LULLY", "LULUS", "LUMEN", "LUMME", "LUMMY", "LUMPS", "LUMPY", "LUMUT", "LUNAR", "LUNAS", "LUNCH", "LUNDA", "LUNEL", "LUNES", "LUNET", "LUNGE", "LUNGI", "LUNGS", "LUNGY", "LUNKA", "LUNKS", "LUNTS", "LUPID", "LUPIN", "LUPIS", "LUPUS", "LURAL", "LURCH", "LURED", "LURER", "LURES", "LURID", "LURKS", "LURKY", "LURRY", "LUSER", "LUSHY", "LUSKY", "LUSTS", "LUSTY", "LUSUS", "LUTAO", "LUTEA", "LUTED", "LUTEO", "LUTER", "LUTES", "LUTRA", "LUXES", "LUXUS", "LYARD", "LYART", "LYASE", "LYCEA", "LYCEE", "LYCID", "LYCUS", "LYDIA", "LYERY", "LYGUS", "LYING", "LYKEN", "LYMPH", "LYNCH", "LYNNE", "LYRES", "LYRIC", "LYRID", "LYSED", "LYSES", "LYSIN", "LYSIS", "LYSOL", "LYSSA", "LYTHE", "LYTIC", "LYTTA", "MAANA", "MAARS", "MABEL", "MACAN", "MACAO", "MACAW", "MACCO", "MACED", "MACER", "MACES", "MACHI", "MACHO", "MACHS", "MACKS", "MACLE", "MACON", "MACRO", "MADAM", "MADGE", "MADIA", "MADID", "MADLY", "MADOC", "MADRE", "MAFEY", "MAFIA", "MAFIC", "MAFOO", "MAGAS", "MAGES", "MAGGY", "MAGHI", "MAGIC", "MAGMA", "MAGNA", "MAGOG", "MAGOT", "MAGUS", "MAHAL", "MAHAR", "MAHAT", "MAHDI", "MAHOE", "MAHRA", "MAHRI", "MAHUA", "MAHWA", "MAIDA", "MAIDS", "MAIDU", "MAIDY", "MAIID", "MAILE", "MAILL", "MAILS", "MAIMS", "MAINE", "MAINS", "MAINT", "MAIRE", "MAIRS", "MAIST", "MAIUS", "MAIZE", "MAJAS", "MAJOR", "MAJOS", "MAKAH", "MAKAR", "MAKER", "MAKES", "MAKOS", "MAKUA", "MAKUK", "MALAM", "MALAR", "MALAX", "MALAY", "MALEE", "MALEO", "MALES", "MALGR", "MALIC", "MALIE", "MALIK", "MALLS", "MALMS", "MALMY", "MALTA", "MALTO", "MALTS", "MALTY", "MALUM", "MALUS", "MALVA", "MALWA", "MAMAS", "MAMBA", "MAMBO", "MAMBU", "MAMEY", "MAMIE", "MAMMA", "MAMMY", "MAMRY", "MANAK", "MANAL", "MANAS", "MANBA", "MANDE", "MANDI", "MANDS", "MANED", "MANEH", "MANEI", "MANES", "MANET", "MANEY", "MANGA", "MANGE", "MANGI", "MANGO", "MANGY", "MANIA", "MANIC", "MANID", "MANIE", "MANIS", "MANIT", "MANIU", "MANKS", "MANKY", "MANLY", "MANNA", "MANNY", "MANOC", "MANOR", "MANOS", "MANQU", "MANSE", "MANSO", "MANTA", "MANTO", "MANTY", "MANUF", "MANUL", "MANUS", "MAORI", "MAPAU", "MAPLE", "MAPPY", "MAQUI", "MARAE", "MARAH", "MARAL", "MARAS", "MARAY", "MARCH", "MARCI", "MARCO", "MARCS", "MARDI", "MARDY", "MAREK", "MARES", "MARGA", "MARGE", "MARIA", "MARID", "MARIE", "MARIO", "MARIS", "MARKA", "MARKO", "MARKS", "MARLA", "MARLI", "MARLS", "MARLY", "MAROK", "MAROR", "MAROS", "MARRY", "MARSE", "MARSH", "MARSI", "MARTS", "MARTU", "MARTY", "MARVY", "MARYS", "MASAI", "MASER", "MASHA", "MASHY", "MASKS", "MASON", "MASSA", "MASSE", "MASSY", "MASTS", "MASTY", "MATAI", "MATAR", "MATAX", "MATCH", "MATED", "MATER", "MATES", "MATEY", "MATHA", "MATHE", "MATHS", "MATIE", "MATIN", "MATKA", "MATLO", "MATRA", "MATSU", "MATTA", "MATTE", "MATTI", "MATTS", "MATTY", "MATZA", "MATZO", "MAUBY", "MAUGH", "MAULS", "MAUND", "MAURI", "MAUTS", "MAUVE", "MAVEN", "MAVIE", "MAVIN", "MAVIS", "MAWED", "MAWKS", "MAWKY", "MAXIM", "MAXIS", "MAYAN", "MAYAS", "MAYBE", "MAYDA", "MAYED", "MAYER", "MAYEY", "MAYNT", "MAYOR", "MAYST", "MAZDA", "MAZED", "MAZEL", "MAZER", "MAZES", "MAZIC", "MAZUR", "MAZUT", "MBAYA", "MBIRA", "MBORI", "MBUBA", "MCCOY", "MCKAY", "MEACH", "MEADS", "MEALS", "MEALY", "MEANS", "MEANT", "MEANY", "MEASE", "MEATH", "MEATS", "MEATY", "MEAUL", "MEBOS", "MECCA", "MECON", "MECUM", "MEDAL", "MEDEA", "MEDIA", "MEDIC", "MEDII", "MEDIO", "MEDLE", "MEDOC", "MEECE", "MEECH", "MEEDS", "MEEKS", "MEESE", "MEETH", "MEETS", "MEGGY", "MEIJI", "MEILE", "MEINY", "MEITH", "MELAM", "MELAS", "MELBA", "MELCH", "MELDS", "MELEE", "MELES", "MELIA", "MELIC", "MELIS", "MELLS", "MELOE", "MELON", "MELOS", "MELTS", "MEMOS", "MENAD", "MENAT", "MENDE", "MENDI", "MENDS", "MENDY", "MENIC", "MENOW", "MENSA", "MENSE", "MENSK", "MENTA", "MENUS", "MEOWS", "MERAK", "MERAT", "MERCE", "MERCH", "MERCI", "MERCY", "MERED", "MEREL", "MERER", "MERES", "MERGE", "MERGH", "MERIL", "MERIT", "MERKS", "MERLE", "MERLS", "MEROP", "MEROS", "MERRY", "MERSE", "MESAD", "MESAL", "MESAS", "MESEL", "MESEM", "MESHY", "MESIC", "MESNE", "MESON", "MESSE", "MESSY", "MESUA", "METAD", "METAE", "METAL", "METAS", "METED", "METEL", "METER", "METES", "METHO", "METHS", "METIC", "METIF", "METIN", "METIS", "METOL", "METRA", "METRE", "METRO", "METUS", "METZE", "MEUNI", "MEUSE", "MEUTE", "MEWED", "MEWER", "MEWLS", "MEZZO", "MHORR", "MIAMI", "MIAOU", "MIAOW", "MIASM", "MIAUL", "MIAUW", "MICAH", "MICAS", "MICHE", "MICHT", "MICKS", "MICKY", "MICRA", "MICRO", "MIDAS", "MIDDY", "MIDER", "MIDGE", "MIDGY", "MIDIS", "MIDST", "MIENS", "MIFFS", "MIFFY", "MIGGS", "MIGHT", "MIKED", "MIKES", "MIKEY", "MIKIE", "MIKIR", "MIKRA", "MILAN", "MILCH", "MILER", "MILES", "MILHA", "MILIA", "MILIT", "MILKO", "MILKS", "MILKY", "MILLA", "MILLE", "MILLS", "MILLY", "MILOR", "MILOS", "MILPA", "MILTS", "MILTY", "MIMED", "MIMEO", "MIMER", "MIMES", "MIMIC", "MIMIR", "MIMLY", "MIMSY", "MIMUS", "MIMZY", "MINAE", "MINAH", "MINAR", "MINAS", "MINBU", "MINCE", "MINCY", "MINDS", "MINED", "MINER", "MINES", "MINGE", "MINGO", "MINGY", "MINIE", "MINIM", "MINIS", "MINKS", "MINNY", "MINOR", "MINOS", "MINOT", "MINOW", "MINTS", "MINTY", "MINUM", "MINUS", "MIQRA", "MIRAC", "MIRAK", "MIRED", "MIRES", "MIREX", "MIRID", "MIRKS", "MIRKY", "MIRLY", "MIRTH", "MIRVS", "MIRZA", "MISCE", "MISDO", "MISER", "MISES", "MISGO", "MISKY", "MISLY", "MISOS", "MISSA", "MISSY", "MISTS", "MISTY", "MITCH", "MITER", "MITES", "MITIS", "MITRA", "MITRE", "MITTS", "MITTY", "MITUA", "MIXED", "MIXEN", "MIXER", "MIXES", "MIXUP", "MIZAR", "MIZEN", "MIZZY", "MNAGE", "MNEME", "MNIUM", "MOANS", "MOATS", "MOBBY", "MOBED", "MOBIL", "MOBLE", "MOCHA", "MOCHE", "MOCHY", "MOCKS", "MOCOA", "MODAL", "MODEL", "MODEM", "MODER", "MODES", "MODGE", "MODIF", "MODOC", "MODUS", "MOECK", "MOGGY", "MOGOS", "MOGUL", "MOHAR", "MOHEL", "MOHOS", "MOHUR", "MOHWA", "MOIER", "MOILE", "MOILS", "MOIRA", "MOIRE", "MOISE", "MOISM", "MOIST", "MOITY", "MOJOS", "MOKES", "MOKUM", "MOLAL", "MOLAR", "MOLAS", "MOLDS", "MOLDY", "MOLER", "MOLES", "MOLET", "MOLGE", "MOLKA", "MOLLA", "MOLLE", "MOLLS", "MOLLY", "MOLPE", "MOLTO", "MOLTS", "MOLVI", "MOMES", "MOMMA", "MOMME", "MOMMY", "MOMUS", "MONAD", "MONAL", "MONAS", "MONAX", "MONDE", "MONDO", "MONEL", "MONER", "MONEY", "MONGO", "MONIC", "MONIE", "MONKS", "MONNY", "MONOS", "MONTE", "MONTH", "MONTU", "MONTY", "MOOCH", "MOODS", "MOODY", "MOOED", "MOOLA", "MOOLS", "MOONG", "MOONS", "MOONY", "MOORE", "MOORN", "MOORS", "MOORY", "MOOSA", "MOOSE", "MOOST", "MOOTH", "MOOTS", "MOPAN", "MOPED", "MOPER", "MOPES", "MOPEY", "MOPLA", "MOPPY", "MOPSY", "MOPUS", "MOQUI", "MORAE", "MORAL", "MORAN", "MORAS", "MORAT", "MORAY", "MORDU", "MORDV", "MOREL", "MORES", "MORGA", "MORIC", "MORIN", "MORMO", "MORNE", "MORNS", "MOROC", "MORON", "MOROR", "MORPH", "MORRA", "MORRO", "MORSE", "MORTH", "MORTS", "MORUS", "MOSAN", "MOSEL", "MOSES", "MOSEY", "MOSGU", "MOSKS", "MOSSI", "MOSSO", "MOSSY", "MOSTE", "MOSTS", "MOSUL", "MOSUR", "MOTED", "MOTEL", "MOTER", "MOTES", "MOTET", "MOTEY", "MOTHS", "MOTHY", "MOTIF", "MOTON", "MOTOR", "MOTTE", "MOTTO", "MOTTS", "MOTTY", "MOUCH", "MOUDY", "MOUES", "MOULD", "MOULE", "MOULS", "MOULT", "MOULY", "MOUND", "MOUNT", "MOURN", "MOUSE", "MOUSY", "MOUTH", "MOVED", "MOVER", "MOVES", "MOVIE", "MOWCH", "MOWED", "MOWER", "MOWHA", "MOWIE", "MOWRA", "MOWSE", "MOWTH", "MOXAS", "MOXIE", "MOYEN", "MOYLE", "MOZOS", "MPHPS", "MPRET", "MSINK", "MSTER", "MTIER", "MUANG", "MUCIC", "MUCID", "MUCIN", "MUCKS", "MUCKY", "MUCOR", "MUCRO", "MUCUS", "MUDAR", "MUDDE", "MUDDY", "MUDEE", "MUDIR", "MUDRA", "MUFFS", "MUFFY", "MUFTI", "MUFTY", "MUGGS", "MUGGY", "MUGHO", "MUGIL", "MUHLY", "MUIST", "MUJIK", "MUKRI", "MUKTI", "MULCH", "MULCT", "MULED", "MULES", "MULET", "MULEY", "MULGA", "MULLA", "MULLS", "MULSE", "MULTI", "MULTO", "MUMBO", "MUMMS", "MUMMY", "MUMPS", "MUMSY", "MUNCH", "MUNDA", "MUNGA", "MUNGE", "MUNGO", "MUNGY", "MUNIA", "MUNIC", "MUNTZ", "MUONG", "MUONS", "MURAL", "MURAN", "MURAS", "MURAT", "MURED", "MURES", "MUREX", "MURGA", "MURID", "MURKS", "MURKY", "MURLY", "MURMI", "MURPH", "MURRA", "MURRE", "MURRS", "MURRY", "MURUT", "MURVA", "MURZA", "MUSAL", "MUSAR", "MUSCA", "MUSCI", "MUSED", "MUSER", "MUSES", "MUSET", "MUSGU", "MUSHA", "MUSHY", "MUSIC", "MUSIE", "MUSIT", "MUSKS", "MUSKY", "MUSSY", "MUSTH", "MUSTS", "MUSTY", "MUTCH", "MUTED", "MUTER", "MUTES", "MUTIC", "MUTTS", "MUTUS", "MUZZY", "MYALL", "MYCOL", "MYLAR", "MYMAR", "MYNAH", "MYNAS", "MYOID", "MYOMA", "MYOPE", "MYOPS", "MYOPY", "MYRON", "MYRRH", "MYSEL", "MYSID", "MYSIS", "MYTHS", "NABAK", "NABAL", "NABBY", "NABIS", "NABLA", "NABLE", "NABOB", "NACHE", "NACHO", "NACRE", "NACRY", "NADIR", "NAEVI", "NAGEL", "NAGGY", "NAGHT", "NAGOR", "NAHOR", "NAHUA", "NAHUM", "NAIAD", "NAIAS", "NAIFS", "NAILS", "NAILY", "NAIRA", "NAIRY", "NAISH", "NAIVE", "NAKED", "NAKER", "NAKIR", "NAKOO", "NALED", "NAMAZ", "NAMBE", "NAMBY", "NAMDA", "NAMED", "NAMER", "NAMES", "NAMMA", "NAMMO", "NANAS", "NANCE", "NANCY", "NANDA", "NANDI", "NANDU", "NANES", "NANGA", "NANMU", "NANNY", "NANTS", "NANTZ", "NAOMI", "NAOTO", "NAPAL", "NAPES", "NAPOO", "NAPPA", "NAPPE", "NAPPY", "NARCO", "NARCS", "NARDS", "NARDU", "NAREN", "NARES", "NARIC", "NARIS", "NARKS", "NARKY", "NARRA", "NASAB", "NASAL", "NASAT", "NASCH", "NASSA", "NASTY", "NASUA", "NASUS", "NATAL", "NATCH", "NATES", "NATHE", "NATTY", "NATUS", "NAUCH", "NAUMK", "NAUNT", "NAVAL", "NAVAR", "NAVEL", "NAVES", "NAVET", "NAVEW", "NAVIG", "NAVIS", "NAVVY", "NAWAB", "NAWLE", "NAWOB", "NAYAR", "NAZIM", "NAZIR", "NAZIS", "NEAPS", "NEARS", "NEATH", "NEATS", "NEBBY", "NEBEL", "NECIA", "NECKS", "NECRO", "NEDDY", "NEEDN", "NEEDS", "NEEDY", "NEELA", "NEELD", "NEELE", "NEEMS", "NEEPS", "NEESE", "NEEZE", "NEFAS", "NEFFY", "NEGER", "NEGRO", "NEGUS", "NEHRU", "NEIFS", "NEIGH", "NEIST", "NEJDI", "NELLY", "NEMAS", "NEMOS", "NENES", "NENTA", "NEONS", "NEOZA", "NEPAL", "NEPER", "NEPIT", "NERAL", "NERDS", "NERDY", "NERKA", "NEROL", "NERTS", "NERTZ", "NERVE", "NERVY", "NESTS", "NESTY", "NETER", "NETOP", "NETTS", "NETTY", "NEUMA", "NEUME", "NEUMS", "NEVAT", "NEVEL", "NEVEN", "NEVER", "NEVES", "NEVOY", "NEVUS", "NEWAR", "NEWEL", "NEWER", "NEWLY", "NEWSY", "NEWTS", "NEXAL", "NEXUM", "NEXUS", "NGAIO", "NGAPI", "NGOKO", "NGOMA", "NGWEE", "NIAIS", "NIALL", "NIATA", "NIBBY", "NICER", "NICHE", "NICHT", "NICKS", "NICKY", "NICOL", "NIDAL", "NIDED", "NIDES", "NIDGE", "NIDOR", "NIDUS", "NIECE", "NIELS", "NIEPA", "NIEVE", "NIFIC", "NIFLE", "NIFTY", "NIGEL", "NIGHS", "NIGHT", "NIGRE", "NIGUA", "NIHAL", "NIHIL", "NIKAU", "NIKKO", "NIKON", "NILLS", "NILOT", "NIMBI", "NINES", "NINJA", "NINNY", "NINON", "NINOS", "NINOX", "NINTH", "NINTU", "NINUT", "NIOBE", "NIOTA", "NIPAS", "NIPPY", "NIRIS", "NIRLS", "NISAN", "NISEI", "NISSE", "NISUS", "NITCH", "NITER", "NITID", "NITON", "NITOS", "NITRE", "NITRO", "NITTA", "NITTY", "NIUAN", "NIVAL", "NIXED", "NIXER", "NIXES", "NIXIE", "NIXON", "NIZAM", "NIZEY", "NJAVE", "NOBBY", "NOBEL", "NOBIS", "NOBLE", "NOBLY", "NOBUT", "NOCHT", "NOCKS", "NODAL", "NODDI", "NODDY", "NODED", "NODES", "NODUS", "NOELS", "NOEMI", "NOGAI", "NOGAL", "NOGGS", "NOHEX", "NOHOW", "NOILS", "NOILY", "NOINT", "NOIRE", "NOISE", "NOISY", "NOKTA", "NOLLE", "NOLOS", "NOMAD", "NOMAP", "NOMAS", "NOMEN", "NOMES", "NOMIC", "NOMOI", "NOMOS", "NONAS", "NONCE", "NONDA", "NONDO", "NONES", "NONET", "NONIC", "NONLY", "NONNY", "NONYA", "NONYL", "NOOKS", "NOOKY", "NOONS", "NOOSE", "NOPAL", "NORAH", "NORIA", "NORIC", "NORIE", "NORIT", "NORMA", "NORMS", "NORNA", "NORRY", "NORSE", "NORSK", "NORTH", "NOSED", "NOSER", "NOSES", "NOSEY", "NOSIG", "NOTAL", "NOTAN", "NOTCH", "NOTED", "NOTER", "NOTES", "NOTRE", "NOTUM", "NOTUS", "NOULD", "NOUNS", "NOVAE", "NOVAS", "NOVEL", "NOVEM", "NOVUM", "NOVUS", "NOWAY", "NOWCH", "NOWED", "NOWEL", "NOWTS", "NOXAL", "NOYAU", "NPEEL", "NUADU", "NUBBY", "NUBIA", "NUCAL", "NUCHA", "NUCIN", "NUDDY", "NUDER", "NUDES", "NUDGE", "NUDIE", "NUDUM", "NUDZH", "NUGAE", "NUKES", "NULLO", "NULLS", "NUMAC", "NUMBS", "NUMDA", "NUMEN", "NUMIS", "NUMMI", "NUMPS", "NUMUD", "NUNCE", "NUNCH", "NUNKI", "NUNKS", "NUNKY", "NUNNI", "NUNRY", "NUQUE", "NURLS", "NURLY", "NURRY", "NURSE", "NURSY", "NUTSY", "NUTTY", "NYALA", "NYAYA", "NYDIA", "NYLON", "NYMIL", "NYMPH", "NYMSS", "NYORO", "NYSSA", "NYXIS", "OADAL", "OAKEN", "OAKUM", "OARED", "OARIC", "OASAL", "OASES", "OASIS", "OASTS", "OATEN", "OATER", "OATHS", "OAVES", "OBEAH", "OBELI", "OBESE", "OBEYS", "OBIAS", "OBIIT", "OBITS", "OBJET", "OBLAT", "OBLEY", "OBMIT", "OBOES", "OBOLE", "OBOLI", "OBOLS", "OCCAS", "OCCUR", "OCEAN", "OCHER", "OCHNA", "OCHRE", "OCHRO", "OCHRY", "OCKER", "OCOTE", "OCQUE", "OCREA", "OCTAD", "OCTAL", "OCTAN", "OCTET", "OCTIC", "OCTYL", "OCUBY", "OCULI", "OCYTE", "ODDER", "ODDLY", "ODELL", "ODEON", "ODEUM", "ODIST", "ODIUM", "ODOOM", "ODORS", "ODOUR", "ODYLE", "ODYLS", "OECUS", "OELET", "OENIN", "OFAYS", "OFFAL", "OFFED", "OFFER", "OFFIC", "OFTEN", "OFTER", "OFTLY", "OGAMS", "OGEED", "OGEES", "OGHAM", "OGHUZ", "OGIVE", "OGLED", "OGLER", "OGLES", "OGMIC", "OGRES", "OHARE", "OHELO", "OHIAS", "OHING", "OHMIC", "OHONE", "OICKS", "OIDIA", "OILED", "OILER", "OINKS", "OISIN", "OKAPI", "OKAYS", "OKEHS", "OKRAS", "OKRUG", "OLCHA", "OLCHI", "OLDEN", "OLDER", "OLDIE", "OLEIC", "OLEIN", "OLENA", "OLENT", "OLEOS", "OLEPY", "OLEUM", "OLIOS", "OLIVA", "OLIVE", "OLLAS", "OLLAV", "OLLIE", "OLOGY", "OLONA", "OLPAE", "OLPES", "OLSON", "OMAHA", "OMANI", "OMASA", "OMBER", "OMBRE", "OMEGA", "OMENS", "OMERS", "OMINA", "OMITS", "OMLAH", "OMNES", "OMRAH", "ONCER", "ONCES", "ONCET", "ONCIA", "ONCIN", "ONERY", "ONION", "ONIUM", "ONKER", "ONKOS", "ONLAP", "ONLAY", "ONMUN", "ONSET", "ONTAL", "ONTIC", "ONYMY", "OOBIT", "OOHED", "OOLAK", "OOLLY", "OOMPH", "OOPAK", "OOPOD", "OORIE", "OOTID", "OOZED", "OOZES", "OOZOA", "OPAHS", "OPALS", "OPATA", "OPELU", "OPENS", "OPERA", "OPHIC", "OPHIR", "OPHIS", "OPINE", "OPING", "OPIUM", "OPSIN", "OPTED", "OPTIC", "ORACH", "ORACY", "ORAGE", "ORALE", "ORALS", "ORANG", "ORANS", "ORANT", "ORAON", "ORARY", "ORATE", "ORBED", "ORBIC", "ORBIT", "ORCAS", "ORCIN", "ORDER", "ORDOS", "OREAD", "OREAS", "ORGAL", "ORGAN", "ORGIA", "ORGIC", "ORGUE", "ORIAS", "ORIBI", "ORIEL", "ORION", "ORIYA", "ORKEY", "ORLES", "ORLET", "ORLON", "ORLOP", "ORLOS", "ORMER", "ORNES", "ORNIS", "OROMO", "ORPIN", "ORPIT", "ORRIS", "ORROW", "ORSEL", "ORSON", "ORTET", "ORTHO", "ORTOL", "ORTYX", "ORVET", "ORYZA", "OSAGE", "OSAKA", "OSCAN", "OSCAR", "OSCIN", "OSELA", "OSHAC", "OSHEA", "OSIDE", "OSIER", "OSKAR", "OSMIC", "OSMIN", "OSMOL", "OSONE", "OSSAL", "OSSEA", "OSSET", "OSSIA", "OSTIA", "OSTIC", "OTARY", "OTATE", "OTHER", "OTHIN", "OTIUM", "OTKON", "OTOMI", "OTTAR", "OTTER", "OTTOS", "OTYAK", "OUABE", "OUGHT", "OUIJA", "OUKIA", "OULAP", "OUNCE", "OUNDS", "OUNDY", "OUPHE", "OUPHS", "OURIE", "OUSEL", "OUSIA", "OUSTS", "OUTAS", "OUTBY", "OUTDO", "OUTED", "OUTEN", "OUTER", "OUTGO", "OUTLY", "OUTRE", "OUVRE", "OUZEL", "OUZOS", "OVALS", "OVANT", "OVARY", "OVATE", "OVENS", "OVERS", "OVERT", "OVEST", "OVILE", "OVINE", "OVISM", "OVIST", "OVOID", "OVOLI", "OVOLO", "OVULA", "OVULE", "OWGHT", "OWING", "OWLER", "OWLET", "OWNED", "OWNER", "OWSEN", "OWSER", "OXANE", "OXBOW", "OXBOY", "OXEYE", "OXFLY", "OXIDE", "OXIDS", "OXIME", "OXIMS", "OXLIP", "OXMAN", "OXTER", "OYANA", "OYERS", "OYLET", "OZARK", "OZENA", "OZIAS", "OZONE", "PAAUW", "PABLO", "PACAS", "PACAY", "PACED", "PACER", "PACES", "PACHA", "PACHT", "PACKS", "PACOS", "PACTA", "PACTS", "PADDA", "PADDY", "PADGE", "PADLE", "PADOU", "PADRE", "PADRI", "PADUS", "PAEAN", "PAEON", "PAGAN", "PAGED", "PAGER", "PAGES", "PAGNE", "PAGOD", "PAGUS", "PAHMI", "PAHOS", "PAIKS", "PAILS", "PAINE", "PAINS", "PAINT", "PAIRS", "PAIRT", "PAISA", "PAISE", "PALAR", "PALAS", "PALAU", "PALAY", "PALCH", "PALEA", "PALED", "PALER", "PALES", "PALET", "PALEW", "PALIS", "PALKI", "PALLA", "PALLI", "PALLS", "PALLU", "PALLY", "PALMA", "PALMO", "PALMS", "PALMY", "PALPI", "PALPS", "PALSY", "PALTA", "PALUS", "PAMHY", "PAMIR", "PAMPA", "PANAK", "PANAX", "PANDA", "PANDY", "PANED", "PANEL", "PANES", "PANGA", "PANGI", "PANGS", "PANIC", "PANNA", "PANNE", "PANOS", "PANSE", "PANSY", "PANTO", "PANTS", "PANTY", "PANUS", "PAOLA", "PAOLO", "PAPAL", "PAPAS", "PAPAW", "PAPER", "PAPEY", "PAPIO", "PAPPI", "PAPPY", "PAPUA", "PAPYR", "PAQUE", "PARAH", "PARAM", "PARAO", "PARAS", "PARCH", "PARDE", "PARDI", "PARDO", "PARDS", "PARDY", "PARED", "PAREL", "PAREN", "PARER", "PARES", "PAREU", "PARGE", "PARGO", "PARIS", "PARKA", "PARKS", "PARKY", "PARLE", "PARLI", "PARLY", "PARMA", "PAROL", "PARRA", "PARRS", "PARRY", "PARSE", "PARSI", "PARTE", "PARTI", "PARTO", "PARTS", "PARTY", "PARUS", "PARVE", "PASAN", "PASCH", "PASEO", "PASES", "PASHA", "PASHM", "PASIS", "PASMO", "PASSE", "PASSO", "PASSU", "PASTA", "PASTE", "PASTS", "PASTY", "PASUL", "PATAO", "PATAS", "PATCH", "PATED", "PATEE", "PATEL", "PATEN", "PATER", "PATES", "PATHS", "PATHY", "PATIA", "PATIN", "PATIO", "PATLY", "PATSY", "PATTA", "PATTE", "PATTU", "PATTY", "PAUKY", "PAULA", "PAUSE", "PAUXI", "PAVAN", "PAVED", "PAVEN", "PAVER", "PAVES", "PAVIA", "PAVID", "PAVIN", "PAVIS", "PAWAW", "PAWED", "PAWER", "PAWKY", "PAWLS", "PAWNS", "PAXES", "PAYED", "PAYEE", "PAYEN", "PAYER", "PAYNI", "PAYOR", "PBXES", "PEACE", "PEACH", "PEAGE", "PEAGS", "PEAKS", "PEAKY", "PEALS", "PEANS", "PEARL", "PEARS", "PEART", "PEASE", "PEASY", "PEATS", "PEATY", "PEAVY", "PEBAN", "PECAN", "PECHS", "PECHT", "PECKS", "PECKY", "PECOS", "PEDAL", "PEDEE", "PEDES", "PEDRO", "PEDUM", "PEEKE", "PEEKS", "PEELE", "PEELS", "PEENS", "PEEOY", "PEEPS", "PEEPY", "PEERS", "PEERT", "PEERY", "PEEVE", "PEGGY", "PEGMA", "PEINE", "PEINS", "PEISE", "PEIZE", "PEKAN", "PEKES", "PEKIN", "PEKOE", "PELES", "PELEW", "PELFS", "PELON", "PELTA", "PELTS", "PENAL", "PENCE", "PENDA", "PENDN", "PENDS", "PENES", "PENGO", "PENIS", "PENNA", "PENNI", "PENNY", "PENSE", "PENSY", "PENTA", "PENUP", "PEONS", "PEONY", "PEPLA", "PEPOS", "PEPPY", "PEPSI", "PERAI", "PERAU", "PERCA", "PERCH", "PERCY", "PERDU", "PERDY", "PERES", "PERIL", "PERIS", "PERIT", "PERKS", "PERKY", "PERLA", "PERLE", "PERMS", "PERRY", "PERSE", "PERTY", "PERUN", "PESAH", "PESKY", "PESOS", "PESTE", "PESTS", "PETAL", "PETER", "PETIT", "PETOS", "PETRE", "PETRI", "PETRO", "PETTI", "PETTO", "PETTY", "PETUM", "PEUHL", "PEWEE", "PEWIT", "PFLAG", "PFUND", "PGNTT", "PHACA", "PHAET", "PHAGE", "PHANE", "PHANO", "PHARE", "PHARM", "PHARO", "PHASE", "PHASM", "PHEAL", "PHEBE", "PHENE", "PHENY", "PHEON", "PHIAL", "PHIES", "PHILL", "PHLOX", "PHOBY", "PHOCA", "PHOMA", "PHONE", "PHONO", "PHONS", "PHONY", "PHORA", "PHOSE", "PHOSS", "PHOTO", "PHOTS", "PHPHT", "PHREN", "PHYLA", "PHYLE", "PHYMA", "PHYSA", "PIABA", "PIALA", "PIANO", "PIANS", "PIAST", "PIBAL", "PICAE", "PICAL", "PICAS", "PICEA", "PICHI", "PICKS", "PICKY", "PICOT", "PICRA", "PICRY", "PICUL", "PICUS", "PIDAN", "PIECE", "PIEND", "PIERS", "PIERT", "PIEST", "PIETA", "PIETE", "PIETY", "PIEZO", "PIGGY", "PIGHT", "PIGLY", "PIGMY", "PIING", "PIKAS", "PIKED", "PIKEL", "PIKER", "PIKES", "PIKEY", "PIKLE", "PILAF", "PILAR", "PILAU", "PILAW", "PILCH", "PILEA", "PILED", "PILEI", "PILER", "PILES", "PILIN", "PILIS", "PILLS", "PILMY", "PILON", "PILOT", "PILUM", "PILUS", "PIMAN", "PIMAS", "PIMPS", "PINAL", "PINAS", "PINAX", "PINCH", "PINDA", "PINDY", "PINED", "PINER", "PINES", "PINEY", "PINGE", "PINGO", "PINGS", "PINIC", "PINKO", "PINKS", "PINKY", "PINNA", "PINNY", "PINON", "PINOT", "PINTA", "PINTE", "PINTO", "PINTS", "PINUP", "PINUS", "PINYL", "PIONS", "PIOTR", "PIOUS", "PIOXE", "PIPAL", "PIPED", "PIPER", "PIPES", "PIPET", "PIPEY", "PIPID", "PIPIL", "PIPIT", "PIPPY", "PIPRA", "PIQUE", "PIRNS", "PIRNY", "PIROG", "PIROL", "PIROT", "PISAN", "PISAY", "PISCO", "PISHU", "PISKY", "PISTE", "PISUM", "PITAS", "PITAU", "PITCH", "PITHS", "PITHY", "PITON", "PITTA", "PIURI", "PIUTE", "PIVOT", "PIWUT", "PIXEL", "PIXES", "PIXIE", "PIZZA", "PLACE", "PLACK", "PLAGA", "PLAGE", "PLAID", "PLAIN", "PLAIT", "PLANE", "PLANG", "PLANK", "PLANS", "PLANT", "PLASH", "PLASM", "PLASS", "PLATE", "PLATO", "PLATS", "PLATT", "PLATY", "PLAUD", "PLAYA", "PLAYS", "PLAZA", "PLEAD", "PLEAS", "PLEAT", "PLEBE", "PLEBS", "PLECK", "PLEIS", "PLENA", "PLENY", "PLEON", "PLICA", "PLIED", "PLIER", "PLIES", "PLINK", "PLINY", "PLISS", "PLOAT", "PLOCE", "PLOCK", "PLODS", "PLOMB", "PLONK", "PLOOK", "PLOPS", "PLOTE", "PLOTS", "PLOTT", "PLOTX", "PLOUK", "PLOUT", "PLOWS", "PLOYS", "PLUCK", "PLUFF", "PLUGS", "PLUMA", "PLUMB", "PLUME", "PLUMP", "PLUMS", "PLUMY", "PLUNK", "PLUPF", "PLUSH", "PLUTO", "PLYER", "PNEUM", "POACH", "POBBY", "POCAN", "POCHE", "POCKS", "POCKY", "POCUL", "POCUS", "PODAL", "PODDY", "PODEX", "PODGE", "PODGY", "PODIA", "PODOS", "POEMS", "POESY", "POETS", "POGEY", "POGGE", "POGGY", "POHNA", "POILU", "POIND", "POINT", "POIRE", "POISE", "POKAN", "POKED", "POKER", "POKES", "POKEY", "POKIE", "POKOM", "POLAB", "POLAR", "POLED", "POLER", "POLES", "POLEY", "POLIO", "POLIS", "POLIT", "POLJE", "POLKA", "POLKI", "POLLS", "POLLY", "POLOI", "POLOS", "POLYP", "POLYS", "POMAK", "POMBE", "POMBO", "POMEL", "POMES", "POMEY", "POMME", "POMMY", "POMPA", "POMPS", "PONCA", "PONCE", "PONDO", "PONDS", "PONDY", "PONES", "PONEY", "PONGA", "PONGO", "PONJA", "PONOS", "PONTO", "POOCH", "POODS", "POOHS", "POOKA", "POOLI", "POOLS", "POOLY", "POONS", "POOPS", "POORI", "POORT", "POOTY", "POOVE", "POPAL", "POPES", "POPIE", "POPPA", "POPPY", "POPSY", "PORAL", "PORCH", "PORED", "PORER", "PORES", "PORET", "PORGE", "PORGO", "PORGY", "PORIA", "PORKS", "PORKY", "PORNO", "PORNS", "POROS", "PORRY", "PORTA", "PORTE", "PORTO", "PORTS", "PORTY", "PORUS", "POSCA", "POSED", "POSER", "POSES", "POSEY", "POSHO", "POSIT", "POSSE", "POSSY", "POSTS", "POTCH", "POTER", "POTOO", "POTSY", "POTTI", "POTTO", "POTTY", "POTUS", "POUCE", "POUCH", "POUCY", "POUFF", "POUFS", "POULE", "POULP", "POULT", "POUND", "POURS", "POUSY", "POUTS", "POUTY", "POWAN", "POWER", "POWNY", "POXED", "POXES", "POYOU", "POZZY", "PRAAM", "PRADO", "PRAHM", "PRAHU", "PRAMS", "PRANA", "PRAND", "PRANG", "PRANK", "PRAOS", "PRASE", "PRATE", "PRATS", "PRATT", "PRAUS", "PRAWN", "PRAYA", "PRAYS", "PREDY", "PREED", "PREEN", "PREES", "PRELA", "PREPD", "PREPG", "PREPN", "PREPS", "PRESA", "PRESE", "PRESS", "PREST", "PRETA", "PREUX", "PREVE", "PREXY", "PREYS", "PRIAM", "PRICE", "PRICH", "PRICK", "PRICY", "PRIDE", "PRIDY", "PRIED", "PRIER", "PRIES", "PRIGS", "PRILL", "PRIMA", "PRIME", "PRIMI", "PRIMO", "PRIMP", "PRIMS", "PRIMY", "PRINE", "PRINK", "PRINT", "PRION", "PRIOR", "PRISE", "PRISM", "PRISS", "PRIUS", "PRIVY", "PRIZE", "PROAL", "PROAS", "PROBE", "PRODD", "PRODS", "PROEM", "PROFS", "PROGS", "PROKE", "PROLE", "PROMO", "PROMS", "PRONE", "PRONG", "PROOF", "PROPR", "PROPS", "PRORE", "PROSE", "PROSO", "PROSS", "PROST", "PROSY", "PROTE", "PROTO", "PROUD", "PROVE", "PROWL", "PROWS", "PROXY", "PRUDE", "PRUDY", "PRUNE", "PRUNT", "PRUTA", "PRYER", "PRYSE", "PSALM", "PSEND", "PSEUD", "PSHAV", "PSHAW", "PSIZE", "PSOAE", "PSOAI", "PSOAS", "PSORA", "PSYCH", "PUBAL", "PUBES", "PUBIC", "PUBIS", "PUCES", "PUCKA", "PUCKS", "PUDDA", "PUDDY", "PUDGE", "PUDGY", "PUDIC", "PUDSY", "PUFFS", "PUFFY", "PUGET", "PUGGI", "PUGGY", "PUGIL", "PUIST", "PUKED", "PUKER", "PUKES", "PUKKA", "PULAS", "PULED", "PULER", "PULES", "PULEX", "PULIK", "PULIS", "PULKA", "PULLI", "PULLS", "PULPS", "PULPY", "PULSE", "PUMAS", "PUMEX", "PUMPS", "PUNAN", "PUNAS", "PUNCE", "PUNCH", "PUNCT", "PUNGA", "PUNGI", "PUNGS", "PUNGY", "PUNIC", "PUNKA", "PUNKS", "PUNKT", "PUNKY", "PUNNY", "PUNTA", "PUNTI", "PUNTO", "PUNTS", "PUNTY", "PUPAE", "PUPAL", "PUPAS", "PUPIL", "PUPPY", "PURAU", "PURDA", "PURDY", "PURED", "PUREE", "PURER", "PUREY", "PURGA", "PURGE", "PURIM", "PURIN", "PURIS", "PURLS", "PURRE", "PURRS", "PURRY", "PURSE", "PURSY", "PURTY", "PUSES", "PUSHY", "PUSSY", "PUTID", "PUTON", "PUTTI", "PUTTO", "PUTTS", "PUTTY", "PYCHE", "PYGAL", "PYGMY", "PYINS", "PYLAR", "PYLIC", "PYLON", "PYNOT", "PYOID", "PYRAL", "PYRAN", "PYRES", "PYREX", "PYRIC", "PYRUS", "PYXES", "PYXIE", "PYXIS", "QAIDS", "QANAT", "QATAR", "QIANA", "QIBLA", "QIYAS", "QOPHS", "QUACK", "QUADI", "QUADS", "QUAFF", "QUAGS", "QUAIL", "QUAIS", "QUAKE", "QUAKY", "QUALE", "QUALM", "QUANT", "QUARE", "QUARK", "QUARL", "QUART", "QUASH", "QUASI", "QUASS", "QUATA", "QUATE", "QUAUK", "QUAVE", "QUAWK", "QUAYS", "QUBBA", "QUEAK", "QUEAL", "QUEAN", "QUEEN", "QUEER", "QUEET", "QUEGH", "QUELL", "QUELT", "QUEME", "QUENT", "QUERL", "QUERN", "QUERY", "QUEST", "QUEUE", "QUEYS", "QUICA", "QUICK", "QUIDS", "QUIET", "QUIFF", "QUILA", "QUILL", "QUILT", "QUINA", "QUINK", "QUINS", "QUINT", "QUIPO", "QUIPS", "QUIPU", "QUIRA", "QUIRE", "QUIRK", "QUIRL", "QUIRT", "QUIST", "QUITE", "QUITO", "QUITS", "QUITU", "QUOAD", "QUODS", "QUOIN", "QUOIT", "QUOTA", "QUOTE", "QUOTH", "QUOTT", "QURSH", "QURTI", "RAASH", "RABAL", "RABAT", "RABBI", "RABIC", "RABID", "RABIN", "RABOT", "RACED", "RACER", "RACES", "RACHE", "RACKS", "RACON", "RADAR", "RADEK", "RADII", "RADIO", "RADIX", "RADLY", "RADON", "RAFFE", "RAFFS", "RAFIK", "RAFTS", "RAFTY", "RAGAS", "RAGED", "RAGEE", "RAGER", "RAGES", "RAGGY", "RAGHU", "RAGIS", "RAHUL", "RAIAE", "RAIAS", "RAIDS", "RAILS", "RAINS", "RAINY", "RAISE", "RAJAB", "RAJAH", "RAJAS", "RAJES", "RAJIV", "RAKAN", "RAKED", "RAKEE", "RAKER", "RAKES", "RAKIS", "RAKIT", "RALES", "RALLY", "RALPH", "RAMAL", "RAMAN", "RAMBO", "RAMED", "RAMEE", "RAMET", "RAMEX", "RAMIE", "RAMMI", "RAMMY", "RAMON", "RAMPS", "RAMTA", "RAMUS", "RANAL", "RANCE", "RANCH", "RANDN", "RANDS", "RANDY", "RANEE", "RANGE", "RANGY", "RANID", "RANIS", "RANKS", "RANLI", "RANNY", "RANTS", "RANTY", "RAPED", "RAPER", "RAPES", "RAPHE", "RAPIC", "RAPID", "RAPPE", "RARER", "RASED", "RASEN", "RASER", "RASES", "RASON", "RASPS", "RASPY", "RASSE", "RASTY", "RATAL", "RATAN", "RATCH", "RATED", "RATEL", "RATER", "RATES", "RATHA", "RATHE", "RATIO", "RATOS", "RATTI", "RATTY", "RATWA", "RAULI", "RAUPO", "RAVED", "RAVEL", "RAVEN", "RAVER", "RAVES", "RAVIN", "RAWER", "RAWIN", "RAWKY", "RAWLY", "RAXED", "RAXES", "RAYAH", "RAYAN", "RAYAS", "RAYAT", "RAYED", "RAYON", "RAZED", "RAZEE", "RAZER", "RAZES", "RAZOO", "RAZOR", "REAAL", "REACH", "REACT", "READD", "READL", "READS", "READY", "REAKS", "REALM", "REALS", "REAMS", "REAMY", "REAPS", "REARM", "REARS", "REASK", "REAST", "REASY", "REATA", "REAVE", "REBAB", "REBAG", "REBAN", "REBAR", "REBBE", "REBEC", "REBED", "REBEG", "REBEL", "REBIA", "REBID", "REBOB", "REBOP", "REBOX", "REBUD", "REBUS", "REBUT", "REBUY", "RECAP", "RECCE", "RECCO", "RECCY", "RECIP", "RECIT", "RECKS", "RECON", "RECPT", "RECTA", "RECTI", "RECTO", "RECUR", "RECUT", "REDAN", "REDDS", "REDDY", "REDED", "REDES", "REDIA", "REDID", "REDIG", "REDIP", "REDLY", "REDOS", "REDOX", "REDRY", "REDUB", "REDUE", "REDUG", "REDUX", "REDYE", "REEDS", "REEDY", "REEFS", "REEFY", "REEKS", "REEKY", "REELS", "REESE", "REESK", "REEST", "REEVE", "REFAN", "REFED", "REFEL", "REFER", "REFFO", "REFIT", "REFIX", "REFLY", "REFRY", "REGAL", "REGEL", "REGES", "REGET", "REGGA", "REGIA", "REGIE", "REGIN", "REGLE", "REGMA", "REGNA", "REGUR", "REHEM", "REHID", "REHOE", "REICE", "REICH", "REIFS", "REIFY", "REIGN", "REINA", "REINK", "REINS", "REIST", "REIVE", "REJIG", "REKEY", "RELAP", "RELAX", "RELAY", "RELES", "RELET", "RELIC", "RELIG", "RELIT", "RELOT", "REMAN", "REMAP", "REMEN", "REMET", "REMEX", "REMIT", "REMIX", "REMOP", "REMUE", "REMUS", "RENAL", "RENAY", "RENDS", "RENDU", "RENEG", "RENES", "RENET", "RENEW", "RENGA", "RENIG", "RENIN", "RENKY", "RENNE", "RENTE", "RENTS", "REOIL", "REOWN", "REPAD", "REPAS", "REPAY", "REPEG", "REPEL", "REPEN", "REPEW", "REPIC", "REPIN", "REPLY", "REPOT", "REPPS", "REPRO", "REPRY", "RERAN", "REREE", "RERIG", "REROB", "REROW", "RERUB", "RERUN", "RESAT", "RESAW", "RESAY", "RESEE", "RESET", "RESEW", "RESEX", "RESID", "RESIN", "RESIT", "RESOW", "RESTR", "RESTS", "RESTY", "RESUE", "RESUN", "RESUP", "RETAG", "RETAL", "RETAN", "RETAR", "RETAX", "RETCH", "RETEM", "RETHE", "RETIA", "RETIE", "RETIN", "RETIP", "RETRO", "RETRY", "REUEL", "REUNE", "REUSE", "REVAY", "REVEL", "REVER", "REVET", "REVIE", "REVUE", "REWAN", "REWAX", "REWED", "REWET", "REWIN", "REWON", "REXEN", "REXES", "RFREE", "RHAMN", "RHEAE", "RHEAS", "RHEDA", "RHEEN", "RHEIC", "RHEIN", "RHEMA", "RHEME", "RHEUM", "RHILA", "RHINA", "RHINE", "RHINO", "RHODA", "RHOEO", "RHOMB", "RHUMB", "RHYME", "RHYMY", "RHYTA", "RIALS", "RIANT", "RIATA", "RIBAT", "RIBBY", "RIBES", "RICED", "RICER", "RICES", "RICEY", "RICHE", "RICHT", "RICIN", "RICKS", "RICKY", "RIDEN", "RIDER", "RIDES", "RIDGE", "RIDGY", "RIELS", "RIFER", "RIFFI", "RIFFS", "RIFLE", "RIFTS", "RIFTY", "RIGEL", "RIGHT", "RIGID", "RIGOL", "RIGOR", "RILED", "RILES", "RILEY", "RILLE", "RILLS", "RILLY", "RIMAL", "RIMAS", "RIMED", "RIMER", "RIMES", "RIMPI", "RINCH", "RINDE", "RINDS", "RINDY", "RINGE", "RINGS", "RINGY", "RINKA", "RINKS", "RINSE", "RIOTS", "RIPAL", "RIPED", "RIPEN", "RIPER", "RIPES", "RIPUP", "RISEN", "RISER", "RISES", "RISHI", "RISKS", "RISKY", "RISQU", "RISUS", "RITES", "RITHE", "RITSU", "RITUS", "RITZY", "RIVAL", "RIVED", "RIVEL", "RIVEN", "RIVER", "RIVES", "RIVET", "RIYAL", "RIZAR", "ROACH", "ROADS", "ROAMS", "ROANS", "ROARS", "ROAST", "ROBED", "ROBER", "ROBES", "ROBIN", "ROBLE", "ROBOT", "ROBUR", "ROCHE", "ROCKS", "ROCKY", "ROCTA", "RODEO", "RODGE", "ROGAN", "ROGER", "ROGUE", "ROGUY", "ROHAN", "ROHOB", "ROHUN", "ROILS", "ROILY", "ROIST", "ROJAK", "ROKEE", "ROKER", "ROKEY", "ROLEO", "ROLES", "ROLFE", "ROLLO", "ROLLS", "ROMAL", "ROMAN", "ROMEO", "ROMIC", "ROMPS", "ROMPU", "ROMPY", "RONCO", "RONDE", "RONDO", "RONGA", "RONIN", "RONNI", "ROODS", "ROOED", "ROOFS", "ROOFY", "ROOKS", "ROOKY", "ROOMS", "ROOMY", "ROOSA", "ROOSE", "ROOST", "ROOTI", "ROOTS", "ROOTY", "ROOVE", "ROPED", "ROPER", "ROPES", "ROPEY", "ROQUE", "RORAL", "RORIC", "RORID", "RORTY", "ROSAL", "ROSED", "ROSEL", "ROSES", "ROSET", "ROSHI", "ROSIN", "ROTAL", "ROTAN", "ROTAS", "ROTCH", "ROTER", "ROTES", "ROTGE", "ROTLS", "ROTOR", "ROTOS", "ROTSE", "ROTTA", "ROTTE", "ROUEN", "ROUES", "ROUGE", "ROUGH", "ROUGY", "ROUKY", "ROUND", "ROUPS", "ROUPY", "ROUSE", "ROUST", "ROUTE", "ROUTH", "ROUTS", "ROVED", "ROVEN", "ROVER", "ROVES", "ROVET", "ROWAN", "ROWDY", "ROWED", "ROWEL", "ROWEN", "ROWER", "ROWET", "ROWTE", "ROWTH", "ROWTY", "ROXIE", "ROYAL", "ROYET", "ROYOU", "ROZUM", "RUACH", "RUANA", "RUBBY", "RUBES", "RUBIA", "RUBIN", "RUBLE", "RUBOR", "RUBUS", "RUCHE", "RUCKS", "RUCKY", "RUDAS", "RUDDS", "RUDDY", "RUDER", "RUDGE", "RUELY", "RUERS", "RUFFE", "RUFFS", "RUFUS", "RUGAE", "RUGAL", "RUGBY", "RUGGY", "RUING", "RUINS", "RULED", "RULER", "RULES", "RUMAL", "RUMAN", "RUMBA", "RUMBO", "RUMEN", "RUMEX", "RUMLY", "RUMMY", "RUMOR", "RUMPS", "RUMPY", "RUNBY", "RUNCH", "RUNDI", "RUNED", "RUNER", "RUNES", "RUNGS", "RUNIC", "RUNNY", "RUNSY", "RUNTS", "RUNTY", "RUPEE", "RUPIA", "RUPIE", "RURAL", "RUSES", "RUSHY", "RUSIN", "RUSKS", "RUSKY", "RUSMA", "RUSOT", "RUSSE", "RUSTS", "RUSTY", "RUTCH", "RUTHS", "RUTIC", "RUTIN", "RUTTY", "RUTYL", "RUVID", "RYBAT", "RYDER", "RYKED", "RYKES", "RYNDS", "RYOTS", "SABAL", "SABAN", "SABBY", "SABED", "SABER", "SABES", "SABIA", "SABIK", "SABIN", "SABIR", "SABLE", "SABLY", "SABOT", "SABRA", "SABRE", "SABZI", "SACAE", "SACKS", "SACRA", "SACRE", "SACRO", "SACRY", "SADES", "SADHE", "SADHU", "SADIC", "SADIE", "SADIS", "SADLY", "SAETA", "SAFAR", "SAFEN", "SAFER", "SAFES", "SAGAI", "SAGAN", "SAGAS", "SAGER", "SAGES", "SAGGY", "SAGOS", "SAGRA", "SAGUM", "SAHIB", "SAHME", "SAICE", "SAIDI", "SAIDS", "SAIFY", "SAIGA", "SAIID", "SAILS", "SAILY", "SAIMY", "SAINS", "SAINT", "SAIPH", "SAIRY", "SAITE", "SAITH", "SAIVA", "SAJOU", "SAKAI", "SAKEL", "SAKER", "SAKES", "SAKHA", "SAKIS", "SAKTI", "SALAD", "SALAL", "SALAR", "SALAT", "SALAY", "SALEM", "SALEP", "SALES", "SALET", "SALIC", "SALIX", "SALLE", "SALLY", "SALMA", "SALMI", "SALMO", "SALOL", "SALON", "SALPA", "SALPS", "SALSA", "SALSE", "SALTA", "SALTS", "SALTY", "SALUD", "SALUE", "SALUS", "SALVA", "SALVE", "SALVO", "SALVY", "SAMAJ", "SAMAL", "SAMAN", "SAMAS", "SAMBA", "SAMBO", "SAMEK", "SAMEL", "SAMEN", "SAMIR", "SAMMY", "SAMOA", "SAMPI", "SAMPS", "SANAI", "SANCT", "SANCY", "SANDS", "SANDY", "SANED", "SANER", "SANES", "SANGA", "SANGH", "SANGU", "SANIT", "SANKA", "SANSI", "SANTA", "SANTO", "SANTY", "SAPAN", "SAPEK", "SAPID", "SAPIN", "SAPIT", "SAPLE", "SAPOR", "SAPPY", "SAQIB", "SARAF", "SARAH", "SARAN", "SARDS", "SAREE", "SARGE", "SARGO", "SARIF", "SARIN", "SARIP", "SARIS", "SARKS", "SARKY", "SARNA", "SAROD", "SARON", "SAROS", "SARPO", "SARRA", "SARSA", "SARSI", "SARUK", "SARUM", "SARUS", "SASAN", "SASIN", "SASSE", "SASSY", "SATAI", "SATAN", "SATED", "SATEM", "SATES", "SATIN", "SATIS", "SATYR", "SAUBA", "SAUCE", "SAUCH", "SAUCY", "SAUDI", "SAUGH", "SAULD", "SAULS", "SAULT", "SAUNA", "SAUNT", "SAURA", "SAURY", "SAUTE", "SAUTY", "SAUVE", "SAVED", "SAVER", "SAVES", "SAVEY", "SAVIN", "SAVOR", "SAVOY", "SAVVY", "SAWAH", "SAWAN", "SAWED", "SAWER", "SAWNY", "SAXES", "SAXON", "SAYAL", "SAYEE", "SAYER", "SAYID", "SAYST", "SAZEN", "SCABS", "SCADS", "SCAFF", "SCAGS", "SCALA", "SCALD", "SCALE", "SCALF", "SCALL", "SCALP", "SCALT", "SCALX", "SCALY", "SCALZ", "SCAMP", "SCAMS", "SCANS", "SCANT", "SCAPE", "SCARE", "SCARF", "SCARN", "SCARP", "SCARS", "SCART", "SCARY", "SCASE", "SCATS", "SCATT", "SCAUL", "SCAUM", "SCAUP", "SCAUR", "SCAUT", "SCAWD", "SCAWL", "SCEAT", "SCELP", "SCENA", "SCEND", "SCENE", "SCENT", "SCHAV", "SCHIZ", "SCHMO", "SCHUH", "SCHUL", "SCHWA", "SCIAN", "SCIND", "SCION", "SCIOT", "SCLAT", "SCLAV", "SCLAW", "SCLER", "SCLIM", "SCOAD", "SCOBS", "SCOFF", "SCOKE", "SCOLB", "SCOLD", "SCOMM", "SCONE", "SCOON", "SCOOP", "SCOOT", "SCOPA", "SCOPE", "SCOPS", "SCORE", "SCORN", "SCOTE", "SCOTS", "SCOTT", "SCOUK", "SCOUP", "SCOUR", "SCOUT", "SCOVE", "SCOVY", "SCOWL", "SCOWS", "SCRAB", "SCRAE", "SCRAG", "SCRAM", "SCRAN", "SCRAP", "SCRAT", "SCRAW", "SCRAY", "SCREE", "SCREW", "SCRIM", "SCRIN", "SCRIP", "SCRIT", "SCROB", "SCROD", "SCROG", "SCROO", "SCROW", "SCRUB", "SCRUF", "SCRUM", "SCUBA", "SCUDI", "SCUDO", "SCUDS", "SCUFF", "SCUFT", "SCULK", "SCULL", "SCULP", "SCULT", "SCUMS", "SCUPS", "SCURF", "SCUSE", "SCUTA", "SCUTE", "SCUTS", "SCYLD", "SCYTH", "SDUMP", "SEALS", "SEALY", "SEAMS", "SEAMY", "SEARS", "SEARY", "SEATS", "SEAVE", "SEAVY", "SEBAT", "SEBUM", "SECCO", "SECNO", "SECOS", "SECRE", "SECTS", "SECUS", "SEDAN", "SEDAT", "SEDER", "SEDGE", "SEDGY", "SEDUM", "SEECH", "SEEDS", "SEEDY", "SEEGE", "SEEKS", "SEELS", "SEELY", "SEEMS", "SEENU", "SEEPS", "SEEPY", "SEERS", "SEGAR", "SEGGY", "SEGNI", "SEGNO", "SEGOL", "SEGOS", "SEGOU", "SEGUE", "SEHYO", "SEIGE", "SEINE", "SEISE", "SEISM", "SEITY", "SEIZE", "SEKAR", "SEKER", "SEKOS", "SELAH", "SELFS", "SELLA", "SELLE", "SELLI", "SELLS", "SELLY", "SELVA", "SEMEE", "SEMEL", "SEMEN", "SEMES", "SEMIC", "SEMIH", "SEMIS", "SENAL", "SENAM", "SENCE", "SENCI", "SENDS", "SENEX", "SENGI", "SENIT", "SENNA", "SENOR", "SENSA", "SENSE", "SENSO", "SENSU", "SENTI", "SENTS", "SENVY", "SENZA", "SEORA", "SEOUL", "SEPAD", "SEPAL", "SEPIA", "SEPIC", "SEPOY", "SEPPA", "SEPTA", "SEPTI", "SEPTS", "SEQED", "SEQUA", "SEQWL", "SERAB", "SERAC", "SERAI", "SERAL", "SERAU", "SERAW", "SERED", "SEREH", "SERER", "SERES", "SERFS", "SERGE", "SERGT", "SERIC", "SERIF", "SERIN", "SERIO", "SERMO", "SERON", "SEROW", "SERRA", "SERRY", "SERTA", "SERUM", "SERUT", "SERVE", "SERVO", "SESIA", "SESMA", "SESSA", "SESTI", "SETAE", "SETAL", "SETON", "SETUP", "SEUGH", "SEVEN", "SEVER", "SEVUM", "SEWAN", "SEWAR", "SEWED", "SEWEN", "SEWER", "SEWIN", "SEXED", "SEXES", "SEXLY", "SEXTO", "SEXTS", "SFOOT", "SFREE", "SHACK", "SHADE", "SHADO", "SHADS", "SHADY", "SHAFT", "SHAGS", "SHAHI", "SHAHS", "SHAKA", "SHAKE", "SHAKO", "SHAKU", "SHAKY", "SHALE", "SHALL", "SHALT", "SHALY", "SHAMA", "SHAME", "SHAMS", "SHANE", "SHANG", "SHANK", "SHANT", "SHAPE", "SHAPS", "SHAPY", "SHARD", "SHARE", "SHARI", "SHARK", "SHARN", "SHARP", "SHAUL", "SHAUP", "SHAVE", "SHAWL", "SHAWM", "SHAWN", "SHAWS", "SHAWY", "SHAYS", "SHEAF", "SHEAL", "SHEAN", "SHEAR", "SHEAS", "SHEAT", "SHEDS", "SHEDU", "SHEEL", "SHEEN", "SHEEP", "SHEER", "SHEET", "SHEIK", "SHELA", "SHELD", "SHELF", "SHELL", "SHEMA", "SHEMU", "SHEND", "SHENG", "SHENT", "SHEOL", "SHERD", "SHETH", "SHEVA", "SHEWA", "SHEWN", "SHEWS", "SHIAH", "SHIAI", "SHICE", "SHICK", "SHIDE", "SHIED", "SHIEL", "SHIER", "SHIES", "SHIFT", "SHIKO", "SHILF", "SHILH", "SHILL", "SHILY", "SHIMS", "SHINA", "SHINE", "SHINS", "SHINY", "SHIPS", "SHIPT", "SHIRE", "SHIRK", "SHIRL", "SHIRR", "SHIRT", "SHISH", "SHISN", "SHIST", "SHITA", "SHITS", "SHIVA", "SHIVE", "SHIVS", "SHIVY", "SHLEP", "SHLUH", "SHOAD", "SHOAL", "SHOAT", "SHOCK", "SHODE", "SHOED", "SHOER", "SHOES", "SHOGI", "SHOGS", "SHOJI", "SHOJO", "SHOLA", "SHOLE", "SHONA", "SHONE", "SHOOD", "SHOOI", "SHOOK", "SHOOL", "SHOON", "SHOOP", "SHOOR", "SHOOS", "SHOOT", "SHOPE", "SHOPS", "SHORE", "SHORL", "SHORN", "SHORT", "SHOTE", "SHOTS", "SHOTT", "SHOUT", "SHOVE", "SHOWD", "SHOWN", "SHOWS", "SHOWY", "SHOYA", "SHOYU", "SHRAB", "SHRAF", "SHRAG", "SHRAM", "SHRAP", "SHRED", "SHREE", "SHREW", "SHRIP", "SHRIS", "SHROG", "SHRUB", "SHRUG", "SHUBA", "SHUCK", "SHUFF", "SHULN", "SHULS", "SHUNE", "SHUNS", "SHUNT", "SHURE", "SHURF", "SHUSH", "SHUTE", "SHUTS", "SHYAM", "SHYER", "SHYLY", "SIAFU", "SIALS", "SIBBS", "SIBBY", "SIBYL", "SICCA", "SICEL", "SICER", "SICES", "SICHT", "SICKS", "SICLE", "SIDED", "SIDER", "SIDES", "SIDHE", "SIDIA", "SIDLE", "SIDTH", "SIEGE", "SIENA", "SIEST", "SIEUR", "SIEVA", "SIEVE", "SIEVY", "SIFAC", "SIFTS", "SIGHS", "SIGHT", "SIGIL", "SIGLA", "SIGMA", "SIGNA", "SIGNS", "SIKAR", "SIKER", "SIKES", "SIKET", "SIKHS", "SIKRA", "SILAS", "SILDS", "SILEN", "SILEX", "SILKS", "SILKY", "SILLS", "SILLY", "SILOS", "SILTS", "SILTY", "SILVA", "SILYL", "SIMAL", "SIMAR", "SIMAS", "SIMBA", "SIMIA", "SIMON", "SIMPS", "SIMUL", "SINAE", "SINAL", "SINCE", "SINES", "SINEW", "SINGE", "SINGH", "SINGS", "SINHS", "SINIC", "SINKS", "SINKY", "SINON", "SINTO", "SINTU", "SINUS", "SIOUX", "SIPED", "SIPER", "SIPES", "SIPID", "SIPPY", "SIRED", "SIREE", "SIREN", "SIRES", "SIREX", "SIRIH", "SIRIS", "SIRKI", "SIRKY", "SIROC", "SIROP", "SIROS", "SIRRA", "SIRUP", "SISAL", "SISEL", "SISES", "SISSU", "SISSY", "SITAO", "SITAR", "SITCH", "SITED", "SITES", "SITHE", "SITIO", "SITKA", "SITTA", "SITUP", "SITUS", "SIUMS", "SIUSI", "SIVAN", "SIVER", "SIWAN", "SIXER", "SIXES", "SIXMO", "SIXTE", "SIXTH", "SIXTY", "SIZAL", "SIZAR", "SIZED", "SIZER", "SIZES", "SJAAK", "SKAFF", "SKAGS", "SKAIL", "SKAIR", "SKALD", "SKART", "SKATE", "SKATS", "SKEAN", "SKEAT", "SKEED", "SKEEG", "SKEEL", "SKEEN", "SKEER", "SKEES", "SKEET", "SKEGS", "SKEIF", "SKEIN", "SKELF", "SKELL", "SKELP", "SKEMP", "SKENE", "SKEPS", "SKERE", "SKERS", "SKETE", "SKEWL", "SKEWS", "SKEWY", "SKICE", "SKIDI", "SKIDS", "SKIED", "SKIER", "SKIES", "SKIEY", "SKIFF", "SKIFT", "SKIIS", "SKILL", "SKIME", "SKIMO", "SKIMP", "SKIMS", "SKINK", "SKINS", "SKINT", "SKIPS", "SKIRL", "SKIRP", "SKIRR", "SKIRT", "SKITE", "SKITS", "SKIVE", "SKIVY", "SKIWY", "SKOAL", "SKOOT", "SKOUT", "SKUAS", "SKULK", "SKULL", "SKULP", "SKUNK", "SKUSE", "SKYED", "SKYEY", "SKYRE", "SKYTE", "SLABS", "SLACK", "SLADE", "SLAGS", "SLAIN", "SLAIT", "SLAKE", "SLAKY", "SLAMP", "SLAMS", "SLANE", "SLANG", "SLANK", "SLANT", "SLAPE", "SLAPS", "SLARE", "SLART", "SLASH", "SLASK", "SLATE", "SLATH", "SLATS", "SLATY", "SLAUM", "SLAVE", "SLAVI", "SLAVS", "SLAWS", "SLAYS", "SLECK", "SLEDS", "SLEEK", "SLEEP", "SLEER", "SLEET", "SLENT", "SLEPT", "SLETE", "SLEWS", "SLEYS", "SLICE", "SLICH", "SLICK", "SLIDE", "SLIER", "SLILY", "SLIME", "SLIMS", "SLIMY", "SLINE", "SLING", "SLINK", "SLIPE", "SLIPS", "SLIPT", "SLIRT", "SLISH", "SLITE", "SLITS", "SLIVE", "SLOAN", "SLOAT", "SLOBS", "SLOCK", "SLOES", "SLOGS", "SLOID", "SLOJD", "SLOKA", "SLOKE", "SLONE", "SLONK", "SLOOM", "SLOOP", "SLOOT", "SLOPE", "SLOPS", "SLOPY", "SLORP", "SLOSH", "SLOTE", "SLOTH", "SLOTS", "SLOUR", "SLOWS", "SLOYD", "SLUBS", "SLUED", "SLUER", "SLUES", "SLUFF", "SLUGS", "SLUIG", "SLUIT", "SLUMP", "SLUMS", "SLUNG", "SLUNK", "SLURB", "SLURP", "SLURS", "SLUSH", "SLUTS", "SLYER", "SLYLY", "SLYPE", "SMACK", "SMAIK", "SMALL", "SMALM", "SMALT", "SMARM", "SMART", "SMASH", "SMAZE", "SMEAR", "SMEEK", "SMEER", "SMELL", "SMELT", "SMERK", "SMETH", "SMEWS", "SMICH", "SMIFT", "SMILE", "SMILY", "SMIRK", "SMITE", "SMITH", "SMOCK", "SMOGS", "SMOKE", "SMOKO", "SMOKY", "SMOLT", "SMOOK", "SMOOS", "SMOOT", "SMORE", "SMOTE", "SMOUS", "SMOUT", "SMRGS", "SMURR", "SMUSE", "SMUSH", "SMUTS", "SMYTH", "SNACK", "SNAFF", "SNAFU", "SNAGS", "SNAIL", "SNAKE", "SNAKY", "SNAPE", "SNAPS", "SNAPY", "SNARE", "SNARK", "SNARL", "SNARY", "SNASH", "SNAST", "SNATH", "SNAWS", "SNEAD", "SNEAK", "SNEAP", "SNECK", "SNEDS", "SNEER", "SNELL", "SNERP", "SNIBS", "SNICK", "SNIDE", "SNIES", "SNIFF", "SNIFT", "SNIGS", "SNIPE", "SNIPS", "SNIPY", "SNIRL", "SNIRT", "SNITE", "SNITS", "SNITZ", "SNIVY", "SNOBS", "SNOCK", "SNOEK", "SNOGA", "SNOKE", "SNOOD", "SNOOK", "SNOOL", "SNOOP", "SNOOT", "SNORE", "SNORK", "SNORT", "SNOTS", "SNOUT", "SNOWK", "SNOWL", "SNOWS", "SNOWY", "SNUBS", "SNUCK", "SNUFF", "SNUGS", "SNURL", "SNURP", "SNURT", "SNYED", "SNYES", "SOAKS", "SOAKY", "SOAPI", "SOAPS", "SOAPY", "SOARS", "SOARY", "SOAVE", "SOBBY", "SOBER", "SOCHT", "SOCII", "SOCKO", "SOCKS", "SOCKY", "SOCLE", "SODAS", "SODDY", "SODIC", "SODIO", "SODOM", "SOFAR", "SOFAS", "SOFER", "SOFIA", "SOFTA", "SOFTS", "SOFTY", "SOGER", "SOGET", "SOGGY", "SOIGN", "SOILS", "SOILY", "SOJAS", "SOKEN", "SOKES", "SOLAN", "SOLAR", "SOLAY", "SOLDI", "SOLDO", "SOLEA", "SOLED", "SOLEN", "SOLER", "SOLES", "SOLFA", "SOLID", "SOLIO", "SOLOD", "SOLON", "SOLOS", "SOLUM", "SOLUS", "SOLVE", "SOMAL", "SOMAS", "SOMET", "SOMMA", "SOMNE", "SONAR", "SONCY", "SONDE", "SONES", "SONGO", "SONGS", "SONGY", "SONIC", "SONJA", "SONLY", "SONNY", "SONSY", "SOOEY", "SOOKE", "SOOKY", "SOONY", "SOORD", "SOOTH", "SOOTS", "SOOTY", "SOPHS", "SOPHY", "SOPOR", "SOPPY", "SORAL", "SORAS", "SORBS", "SORDA", "SORDO", "SORDS", "SOREE", "SOREL", "SORER", "SORES", "SOREX", "SORGO", "SORNS", "SORRA", "SORRY", "SORTS", "SORTY", "SORUS", "SORVA", "SOSIA", "SOSIE", "SOTER", "SOTHO", "SOTHS", "SOTIE", "SOTIK", "SOTOL", "SOUGH", "SOULS", "SOULX", "SOULY", "SOULZ", "SOUND", "SOUPS", "SOUPY", "SOURD", "SOURS", "SOURY", "SOUSE", "SOUTH", "SOWAN", "SOWAR", "SOWED", "SOWEL", "SOWER", "SOWLE", "SOWSE", "SOWTE", "SOYAS", "SOYOT", "SOZIN", "SOZLY", "SPAAD", "SPACE", "SPACK", "SPACY", "SPADE", "SPADO", "SPAED", "SPAER", "SPAES", "SPAHI", "SPAID", "SPAIK", "SPAIL", "SPAIN", "SPAIR", "SPAIT", "SPAKE", "SPALD", "SPALE", "SPALL", "SPALT", "SPANE", "SPANG", "SPANK", "SPANN", "SPANS", "SPARE", "SPARK", "SPARM", "SPARS", "SPART", "SPARY", "SPASM", "SPASS", "SPATE", "SPATH", "SPATS", "SPAVE", "SPAWL", "SPAWN", "SPAYS", "SPEAK", "SPEAL", "SPEAN", "SPEAR", "SPECE", "SPECK", "SPECS", "SPECT", "SPEED", "SPEEL", "SPEEN", "SPEER", "SPEIL", "SPEIR", "SPEKT", "SPELK", "SPELL", "SPELT", "SPEND", "SPENT", "SPEOS", "SPERE", "SPERM", "SPETE", "SPEWS", "SPEWY", "SPHEX", "SPIAL", "SPICA", "SPICE", "SPICK", "SPICS", "SPICY", "SPIED", "SPIEL", "SPIER", "SPIES", "SPIFF", "SPIKE", "SPIKS", "SPIKY", "SPILE", "SPILL", "SPILT", "SPINA", "SPINE", "SPINK", "SPINS", "SPINY", "SPIRA", "SPIRE", "SPIRO", "SPIRT", "SPIRY", "SPISE", "SPISS", "SPITE", "SPITS", "SPITZ", "SPIVS", "SPLAD", "SPLAT", "SPLAY", "SPLET", "SPLIT", "SPOCK", "SPODE", "SPOIL", "SPOKE", "SPOKY", "SPOLE", "SPONG", "SPOOF", "SPOOK", "SPOOL", "SPOOM", "SPOON", "SPOOR", "SPOOT", "SPORE", "SPORT", "SPOSH", "SPOTS", "SPOUT", "SPRAD", "SPRAG", "SPRAT", "SPRAY", "SPREE", "SPRET", "SPREW", "SPRIG", "SPRIT", "SPROD", "SPROT", "SPRUE", "SPRUG", "SPUDS", "SPUED", "SPUES", "SPUKE", "SPUME", "SPUMY", "SPUNG", "SPUNK", "SPURL", "SPURN", "SPURS", "SPURT", "SPUTA", "SPUTE", "SPYER", "SQUAB", "SQUAD", "SQUAM", "SQUAT", "SQUAW", "SQUEG", "SQUET", "SQUIB", "SQUID", "SQUIN", "SQUIT", "SQUIZ", "SRUTI", "SSING", "SSORT", "SSTOR", "STAAB", "STABS", "STACC", "STACK", "STACY", "STADE", "STAFF", "STAGE", "STAGS", "STAGY", "STAIA", "STAID", "STAIG", "STAIL", "STAIN", "STAIO", "STAIR", "STAKE", "STALE", "STALK", "STALL", "STAMP", "STAND", "STANE", "STANG", "STANK", "STAPH", "STARE", "STARK", "STARN", "STARR", "STARS", "START", "STARW", "STARY", "STASH", "STATE", "STATS", "STAUK", "STAUN", "STAUP", "STAVE", "STAWN", "STAYS", "STCHI", "STEAD", "STEAK", "STEAL", "STEAM", "STEAN", "STECH", "STEED", "STEEK", "STEEL", "STEEM", "STEEN", "STEEP", "STEER", "STEGH", "STEID", "STEIN", "STELA", "STELE", "STELL", "STEMA", "STEMS", "STEND", "STENG", "STENO", "STENT", "STEPS", "STEPT", "STERE", "STERI", "STERK", "STERN", "STERO", "STERT", "STETS", "STEVE", "STEWS", "STEWY", "STICH", "STICK", "STIED", "STIES", "STIFE", "STIFF", "STILB", "STILE", "STILL", "STILT", "STIME", "STIMY", "STINE", "STING", "STINK", "STINT", "STION", "STIPA", "STIPE", "STIPO", "STIRE", "STIRK", "STIRP", "STIRS", "STITE", "STITH", "STIVE", "STIVY", "STOAE", "STOAI", "STOAS", "STOAT", "STOBS", "STOCK", "STOEP", "STOFF", "STOGA", "STOGY", "STOIC", "STOIT", "STOKE", "STOLA", "STOLD", "STOLE", "STOMA", "STOMP", "STOND", "STONE", "STONG", "STONK", "STONY", "STOOD", "STOOF", "STOOK", "STOOL", "STOON", "STOOP", "STOOT", "STOPA", "STOPE", "STOPS", "STOPT", "STORE", "STORK", "STORM", "STORY", "STOSH", "STOSS", "STOTT", "STOUN", "STOUP", "STOUR", "STOUT", "STOVE", "STOWP", "STOWS", "STRAD", "STRAE", "STRAG", "STRAM", "STRAP", "STRAW", "STRAY", "STREE", "STREP", "STRET", "STREW", "STREY", "STRIA", "STRID", "STRIG", "STRIP", "STRIT", "STRIX", "STROM", "STROP", "STROW", "STROY", "STRUB", "STRUE", "STRUM", "STRUT", "STRUV", "STUBB", "STUBE", "STUBS", "STUCK", "STUDE", "STUDS", "STUDY", "STUFF", "STULL", "STULM", "STUMP", "STUMS", "STUNG", "STUNK", "STUNS", "STUNT", "STUPA", "STUPE", "STUPP", "STURK", "STURT", "STUSS", "STYAN", "STYCA", "STYED", "STYES", "STYLE", "STYLI", "STYLO", "STYMY", "SUADE", "SUANT", "SUAVE", "SUBAH", "SUBAS", "SUBCH", "SUBER", "SUBET", "SUBRA", "SUBST", "SUCCI", "SUCKS", "SUCRE", "SUDAN", "SUDDS", "SUDDY", "SUDES", "SUDIC", "SUDOR", "SUDRA", "SUDSY", "SUEDE", "SUENT", "SUERS", "SUETS", "SUETY", "SUEVE", "SUEVI", "SUGAN", "SUGAR", "SUGAT", "SUGHS", "SUGIH", "SUGIS", "SUINA", "SUINE", "SUING", "SUINT", "SUIST", "SUITE", "SUITS", "SUITY", "SUKEY", "SULCI", "SULEA", "SULFA", "SULFO", "SULKA", "SULKS", "SULKY", "SULLA", "SULLY", "SUMAC", "SUMAK", "SUMEN", "SUMMA", "SUMOS", "SUMPH", "SUMPS", "SUMPT", "SUNIL", "SUNNA", "SUNNI", "SUNNS", "SUNNY", "SUNUP", "SUOMI", "SUPAI", "SUPER", "SUPES", "SUPPL", "SUPRA", "SUPVR", "SURAH", "SURAL", "SURAS", "SURAT", "SURDS", "SURED", "SURER", "SURES", "SURFS", "SURFY", "SURGE", "SURGY", "SURLY", "SURMA", "SURRA", "SURYA", "SUSAN", "SUSHI", "SUSIE", "SUSSO", "SUSSY", "SUTOR", "SUTRA", "SUTTA", "SUYOG", "SUZAN", "SVELT", "SWABS", "SWACK", "SWAGE", "SWAGS", "SWAIL", "SWAIN", "SWALE", "SWAMI", "SWAMP", "SWAMY", "SWANG", "SWANK", "SWANS", "SWAPE", "SWAPS", "SWARD", "SWARE", "SWARF", "SWARM", "SWART", "SWASH", "SWATH", "SWATI", "SWATS", "SWAYS", "SWAZI", "SWEAL", "SWEAR", "SWEAT", "SWEDE", "SWEEP", "SWEER", "SWEET", "SWEGO", "SWELL", "SWELP", "SWELT", "SWEPT", "SWERD", "SWICK", "SWIFT", "SWIGS", "SWILE", "SWILL", "SWIMS", "SWIMY", "SWINE", "SWING", "SWINK", "SWIPE", "SWIPY", "SWIRD", "SWIRE", "SWIRL", "SWISH", "SWISS", "SWITH", "SWIVE", "SWIZZ", "SWOBS", "SWOLN", "SWONK", "SWOON", "SWOOP", "SWOPS", "SWORD", "SWORE", "SWORN", "SWOSH", "SWOTS", "SWOUN", "SWUNG", "SWURE", "SYBIL", "SYBOW", "SYCEE", "SYCES", "SYCON", "SYFTN", "SYKES", "SYLID", "SYLPH", "SYLVA", "SYNCH", "SYNCS", "SYNOD", "SYNOP", "SYREN", "SYRIA", "SYRMA", "SYRUP", "SYRUS", "SYSIN", "TAATA", "TABAC", "TABBY", "TABEL", "TABER", "TABES", "TABET", "TABIC", "TABID", "TABIS", "TABLA", "TABLE", "TABOG", "TABOO", "TABOR", "TABUS", "TABUT", "TACAN", "TACCA", "TACES", "TACET", "TACHE", "TACHI", "TACHS", "TACIT", "TACKS", "TACKY", "TACOS", "TACSO", "TACTS", "TAELS", "TAFFY", "TAFIA", "TAGAL", "TAGEL", "TAGGY", "TAGUA", "TAGUS", "TAHAR", "TAHIL", "TAHIN", "TAHRS", "TAHUA", "TAICH", "TAIGA", "TAILS", "TAILY", "TAINO", "TAINS", "TAINT", "TAIPI", "TAIPO", "TAIRN", "TAISE", "TAISH", "TAJES", "TAJIK", "TAKAO", "TAKAR", "TAKED", "TAKEN", "TAKER", "TAKES", "TAKIN", "TAKYR", "TALAK", "TALAO", "TALAR", "TALAS", "TALCK", "TALCS", "TALED", "TALER", "TALES", "TALIO", "TALIS", "TALKS", "TALKY", "TALLI", "TALLY", "TALMA", "TALON", "TALPA", "TALUK", "TALUS", "TAMAL", "TAMAS", "TAMBO", "TAMED", "TAMER", "TAMES", "TAMIL", "TAMIS", "TAMMY", "TAMPA", "TAMPS", "TAMUL", "TAMUS", "TANAK", "TANAN", "TANDY", "TANGA", "TANGI", "TANGO", "TANGS", "TANGY", "TANHA", "TANIA", "TANKA", "TANKS", "TANNA", "TANNY", "TANOA", "TANSY", "TANTI", "TANTO", "TANYA", "TANZY", "TAPAS", "TAPED", "TAPEN", "TAPER", "TAPES", "TAPET", "TAPIA", "TAPIR", "TAPIS", "TAPIT", "TAPOA", "TAPPA", "TAPUL", "TAQUA", "TARAF", "TARAI", "TARAU", "TARDE", "TARDO", "TARDY", "TAREA", "TARED", "TAREQ", "TARES", "TARFA", "TARGE", "TARIE", "TARIN", "TARMI", "TARNS", "TAROC", "TAROK", "TAROS", "TAROT", "TARPS", "TARRE", "TARRI", "TARRY", "TARSE", "TARSI", "TARTE", "TARTS", "TARVE", "TASCO", "TASKS", "TASSE", "TASTE", "TASTY", "TATAR", "TATER", "TATES", "TATIE", "TATOO", "TATOU", "TATTA", "TATTY", "TAUBE", "TAULA", "TAULI", "TAUNT", "TAUPE", "TAUPO", "TAURI", "TAUTS", "TAVER", "TAVOY", "TAWED", "TAWER", "TAWGI", "TAWIE", "TAWNY", "TAWPI", "TAWPY", "TAWSE", "TAXED", "TAXER", "TAXES", "TAXIN", "TAXIR", "TAXIS", "TAXON", "TAXOR", "TAXUS", "TAYER", "TAYIR", "TAYRA", "TAZIA", "TAZZA", "TAZZE", "TCAWI", "TCHAI", "TCHWI", "TEACH", "TEAER", "TEAEY", "TEAKS", "TEALS", "TEAMS", "TEARS", "TEART", "TEARY", "TEASE", "TEASY", "TEATS", "TEATY", "TEAVE", "TEAZE", "TEBET", "TECHY", "TECLA", "TECON", "TECTA", "TECUM", "TEDDY", "TEDGE", "TEEMS", "TEENS", "TEENY", "TEEST", "TEETH", "TEETY", "TEFFS", "TEGUA", "TEHEE", "TEIAN", "TEIID", "TEIND", "TEISE", "TEJON", "TEKKE", "TEKYA", "TELAE", "TELAR", "TELEG", "TELEI", "TELES", "TELEX", "TELIA", "TELIC", "TELLS", "TELLT", "TELLY", "TELOI", "TELOS", "TELYN", "TEMAN", "TEMBE", "TEMBU", "TEMIN", "TEMNE", "TEMPE", "TEMPI", "TEMPO", "TEMPS", "TEMPT", "TEMSE", "TENAI", "TENCH", "TENDO", "TENDS", "TENET", "TENEZ", "TENGU", "TENIA", "TENIO", "TENLA", "TENNE", "TENNO", "TENNU", "TENON", "TENOR", "TENSE", "TENSO", "TENTH", "TENTS", "TENTY", "TENUE", "TEPAL", "TEPAS", "TEPEE", "TEPID", "TEPOR", "TERAI", "TERAP", "TERAS", "TERCE", "TEREK", "TERES", "TEREU", "TERGA", "TERMA", "TERMS", "TERNA", "TERNE", "TERNS", "TERRA", "TERRE", "TERRI", "TERRY", "TERSE", "TERZO", "TESLA", "TESTA", "TESTE", "TESTS", "TESTY", "TETCH", "TETEL", "TETHS", "TETON", "TETRA", "TETTY", "TETUM", "TEUCH", "TEUGH", "TEWED", "TEWEL", "TEWER", "TEWIT", "TEWLY", "TEXAN", "TEXAS", "TEXTS", "THACK", "THAIS", "THALA", "THANA", "THANE", "THANK", "THARF", "THARM", "THATD", "THATN", "THATS", "THAVE", "THAWN", "THAWS", "THAWY", "THEAH", "THEAT", "THECA", "THEEK", "THEER", "THEET", "THEFT", "THEGN", "THEIN", "THEIR", "THEMA", "THEME", "THENS", "THEOL", "THEOR", "THEOS", "THEOW", "THERE", "THERM", "THESE", "THETA", "THETE", "THEWS", "THEWY", "THEYD", "THICK", "THIEF", "THIGH", "THILK", "THILL", "THINE", "THING", "THINK", "THINS", "THIOL", "THIRD", "THIRL", "THIRT", "THISN", "THOFT", "THOKE", "THOLE", "THOLI", "THONE", "THONG", "THOOM", "THORE", "THORN", "THORO", "THORP", "THORT", "THOSE", "THOUS", "THOWT", "THRAM", "THRAP", "THRAW", "THRAX", "THREE", "THREW", "THRIP", "THROB", "THROE", "THROU", "THROW", "THRUM", "THRUV", "THUAN", "THUDS", "THUGS", "THUJA", "THULE", "THULR", "THUMB", "THUMP", "THUND", "THUNG", "THUOC", "THURL", "THURM", "THURT", "THUYA", "THYME", "THYMI", "THYMS", "THYMY", "TIANG", "TIARA", "TIBBU", "TIBBY", "TIBER", "TIBET", "TIBEY", "TIBIA", "TICAL", "TICCA", "TICER", "TICKS", "TICKY", "TICUL", "TIDAL", "TIDDY", "TIDED", "TIDES", "TIENS", "TIERS", "TIFFS", "TIFFY", "TIGER", "TIGHT", "TIGON", "TIGRE", "TIGUA", "TIKES", "TIKIS", "TIKKA", "TIKOR", "TIKUR", "TILAK", "TILDA", "TILDE", "TILED", "TILER", "TILES", "TILIA", "TILLS", "TILLY", "TILTH", "TILTS", "TILTY", "TIMAR", "TIMBE", "TIMBO", "TIMED", "TIMER", "TIMES", "TIMET", "TIMID", "TIMNE", "TIMON", "TIMOR", "TINCT", "TINEA", "TINED", "TINES", "TINGE", "TINGI", "TINGS", "TINNE", "TINNI", "TINNY", "TINSY", "TINTA", "TINTS", "TINTY", "TIPIS", "TIPIT", "TIPLE", "TIPPY", "TIPSY", "TIPUP", "TIRAZ", "TIRED", "TIRER", "TIRES", "TIRLS", "TIRMA", "TIROS", "TIRVE", "TISAR", "TISIC", "TISSU", "TITAN", "TITAR", "TITER", "TITHE", "TITIS", "TITLE", "TITRE", "TITTY", "TITUS", "TIVER", "TIWAZ", "TIZZY", "TLACO", "TMEMA", "TOADS", "TOADY", "TOAST", "TODAY", "TODDY", "TODEA", "TODUS", "TOFFS", "TOFFY", "TOFTS", "TOFUS", "TOGAE", "TOGAS", "TOGED", "TOGUE", "TOHER", "TOILE", "TOILS", "TOISE", "TOIST", "TOITS", "TOITY", "TOKAY", "TOKED", "TOKEN", "TOKES", "TOKYO", "TOLAN", "TOLAS", "TOLDO", "TOLED", "TOLES", "TOLLS", "TOLLY", "TOLUS", "TOLYL", "TOMAN", "TOMAS", "TOMBE", "TOMBS", "TOMES", "TOMIA", "TOMIN", "TOMMY", "TONAL", "TONDI", "TONDO", "TONED", "TONER", "TONES", "TONGA", "TONGS", "TONIC", "TONKA", "TONNA", "TONNE", "TONTO", "TONUS", "TOOLS", "TOONA", "TOONS", "TOOSH", "TOOTH", "TOOTS", "TOPAS", "TOPAU", "TOPAZ", "TOPED", "TOPEE", "TOPER", "TOPES", "TOPHE", "TOPHI", "TOPHS", "TOPIA", "TOPIC", "TOPIS", "TOPOG", "TOPOI", "TOPOS", "TOPPY", "TOPSL", "TOPSY", "TOQUE", "TORAH", "TORAL", "TORAN", "TORAS", "TORCH", "TORCS", "TORED", "TORES", "TORET", "TORIC", "TORII", "TORMA", "TOROS", "TORSE", "TORSI", "TORSK", "TORSO", "TORTA", "TORTE", "TORTS", "TORUS", "TORVE", "TOSCA", "TOSHY", "TOSSY", "TOTAL", "TOTED", "TOTEM", "TOTER", "TOTES", "TOTTY", "TOTUM", "TOUCH", "TOUGH", "TOULD", "TOURN", "TOURS", "TOURT", "TOUSE", "TOUST", "TOUSY", "TOUTS", "TOVAH", "TOVAR", "TOVET", "TOWAI", "TOWAN", "TOWED", "TOWEL", "TOWER", "TOWIE", "TOWNS", "TOWNY", "TOWSY", "TOXIC", "TOXIN", "TOXON", "TOYED", "TOYER", "TOYON", "TOYOS", "TOZEE", "TOZER", "TRABU", "TRACE", "TRACK", "TRACT", "TRACY", "TRADE", "TRADY", "TRAGI", "TRAIK", "TRAIL", "TRAIN", "TRAIT", "TRAMA", "TRAME", "TRAMP", "TRAMS", "TRANK", "TRANS", "TRANT", "TRAPA", "TRAPS", "TRAPT", "TRASH", "TRASS", "TRASY", "TRAVE", "TRAWL", "TRAYS", "TREAD", "TREAS", "TREAT", "TREED", "TREEN", "TREES", "TREEY", "TREFA", "TREKS", "TREMA", "TREND", "TRENT", "TRESS", "TREST", "TRETS", "TREWS", "TREYS", "TRIAC", "TRIAD", "TRIAL", "TRIAS", "TRIBE", "TRICA", "TRICE", "TRICK", "TRIED", "TRIER", "TRIES", "TRIFA", "TRIGA", "TRIGO", "TRIGS", "TRIKE", "TRILL", "TRIMS", "TRINA", "TRINE", "TRINK", "TRIOL", "TRIOR", "TRIOS", "TRIPE", "TRIPL", "TRIPS", "TRIPT", "TRIPY", "TRIST", "TRITE", "TRIXY", "TROAD", "TROAK", "TROAT", "TROCA", "TROCH", "TROCK", "TROCO", "TRODE", "TROFT", "TROGS", "TROIC", "TROIS", "TROKE", "TROLL", "TROMP", "TRONA", "TRONC", "TRONE", "TRONK", "TROOP", "TROOT", "TROOZ", "TROPE", "TROTH", "TROTS", "TROUE", "TROUT", "TROUV", "TROVE", "TROWS", "TROYS", "TRUBU", "TRUCE", "TRUCK", "TRUDY", "TRUED", "TRUER", "TRUES", "TRUFF", "TRULL", "TRULY", "TRUMP", "TRUNK", "TRUSH", "TRUSS", "TRUST", "TRUTH", "TRYMA", "TRYMS", "TRYPA", "TRYST", "TSADE", "TSADI", "TSARS", "TSERE", "TSINE", "TSKED", "TSUBA", "TSUBO", "TSUGA", "TSUMA", "TUANT", "TUARN", "TUART", "TUATH", "TUBAE", "TUBAL", "TUBAR", "TUBAS", "TUBBA", "TUBBY", "TUBED", "TUBER", "TUBES", "TUBIG", "TUBIK", "TUCKS", "TUCKY", "TUCUM", "TUDEL", "TUDOR", "TUFAN", "TUFAS", "TUFFS", "TUFTS", "TUFTY", "TUGUI", "TUISM", "TUKRA", "TULES", "TULIP", "TULLE", "TULSA", "TULSI", "TUMID", "TUMLI", "TUMMY", "TUMOR", "TUMPS", "TUNAL", "TUNAS", "TUNCA", "TUNED", "TUNER", "TUNES", "TUNGA", "TUNGO", "TUNGS", "TUNIC", "TUNIS", "TUNKA", "TUNNA", "TUNNY", "TUPEK", "TUPIK", "TUPLE", "TUQUE", "TURBO", "TURCO", "TURDS", "TURFS", "TURFY", "TURGY", "TURIO", "TURKI", "TURKS", "TURMA", "TURNS", "TURPS", "TURSE", "TURUS", "TURVY", "TUSHS", "TUSHY", "TUSKS", "TUSKY", "TUTEE", "TUTIN", "TUTLY", "TUTOR", "TUTTI", "TUTTO", "TUTTY", "TUTUS", "TUXES", "TUYER", "TUZLA", "TWAES", "TWAIN", "TWAIT", "TWALE", "TWALT", "TWANA", "TWANG", "TWANK", "TWANT", "TWATS", "TWEAG", "TWEAK", "TWEED", "TWEEG", "TWEEL", "TWEEN", "TWEET", "TWEIL", "TWERE", "TWERP", "TWICE", "TWICK", "TWIER", "TWIGS", "TWILL", "TWILT", "TWINE", "TWINK", "TWINS", "TWINT", "TWINY", "TWIRE", "TWIRK", "TWIRL", "TWIRP", "TWIST", "TWITE", "TWITS", "TWIXT", "TWOES", "TWYER", "TYCHE", "TYDIE", "TYEES", "TYIGH", "TYING", "TYKEN", "TYKES", "TYLER", "TYLUS", "TYNED", "TYNES", "TYPAL", "TYPED", "TYPER", "TYPES", "TYPEY", "TYPHA", "TYPIC", "TYPOS", "TYPPS", "TYRED", "TYRES", "TYROS", "TYSTE", "TYTHE", "TZAAM", "TZARS", "UALIS", "UAUPE", "UAYEB", "UCHEE", "UCKIA", "UDASI", "UDDER", "UDELL", "UDISH", "UGALI", "UGLIS", "UGRIC", "UHLAN", "UHLLO", "UHURU", "UIGUR", "UINAL", "UINTA", "UKASE", "ULAMA", "ULANS", "ULCER", "ULCUS", "ULEMA", "ULLER", "ULMIC", "ULMIN", "ULMUS", "ULNAD", "ULNAE", "ULNAR", "ULNAS", "ULOID", "ULPAN", "ULTRA", "ULUHI", "ULULU", "ULVAN", "ULVAS", "UMAUA", "UMBEL", "UMBER", "UMBLE", "UMBOS", "UMBRA", "UMBRE", "UMEST", "UMIAC", "UMIAK", "UMIAQ", "UMIRI", "UMIST", "UMMPS", "UMPED", "UMPTY", "UMSET", "UNACT", "UNADD", "UNAIS", "UNAMI", "UNAMO", "UNAPT", "UNARK", "UNARM", "UNARY", "UNAUS", "UNBAG", "UNBAR", "UNBAY", "UNBED", "UNBET", "UNBID", "UNBIT", "UNBOG", "UNBOW", "UNBOX", "UNBOY", "UNBUD", "UNCAP", "UNCIA", "UNCLE", "UNCOS", "UNCOW", "UNCOY", "UNCUS", "UNCUT", "UNDAM", "UNDEE", "UNDEN", "UNDER", "UNDID", "UNDIG", "UNDIM", "UNDOG", "UNDON", "UNDRY", "UNDUB", "UNDUE", "UNDUG", "UNDYE", "UNEYE", "UNFAR", "UNFED", "UNFEW", "UNFIT", "UNFIX", "UNFUR", "UNGAG", "UNGET", "UNGKA", "UNGOD", "UNGOT", "UNGUM", "UNHAD", "UNHAP", "UNHAT", "UNHEX", "UNHID", "UNHIP", "UNHIT", "UNHOT", "UNIAT", "UNICE", "UNIFY", "UNINN", "UNION", "UNISM", "UNIST", "UNITE", "UNITS", "UNITY", "UNIUS", "UNJAM", "UNKED", "UNKEN", "UNKET", "UNKEY", "UNKID", "UNKIN", "UNLAP", "UNLAW", "UNLAX", "UNLAY", "UNLED", "UNLET", "UNLID", "UNLIE", "UNLIT", "UNMAD", "UNMAN", "UNMET", "UNMEW", "UNMIX", "UNNET", "UNNEW", "UNODE", "UNOIL", "UNOLD", "UNONA", "UNORN", "UNOWN", "UNPAY", "UNPEG", "UNPEN", "UNPIN", "UNPOT", "UNPUT", "UNRAM", "UNRAY", "UNRED", "UNRID", "UNRIG", "UNRIP", "UNROW", "UNRRA", "UNRUN", "UNSAD", "UNSAY", "UNSEE", "UNSET", "UNSEW", "UNSEX", "UNSHY", "UNSIN", "UNSLY", "UNSON", "UNSTY", "UNSUN", "UNTAP", "UNTAR", "UNTAX", "UNTIE", "UNTIL", "UNTIN", "UNTOP", "UNURN", "UNUSE", "UNWAN", "UNWAX", "UNWEB", "UNWED", "UNWET", "UNWIG", "UNWIT", "UNWON", "UNWRY", "UNZEN", "UNZIP", "UPARM", "UPAYA", "UPBAR", "UPBAY", "UPBID", "UPBUY", "UPBYE", "UPCRY", "UPCUT", "UPDOS", "UPDRY", "UPEAT", "UPEND", "UPFLY", "UPGET", "UPHER", "UPJET", "UPLAY", "UPLEG", "UPLIT", "UPMIX", "UPPED", "UPPER", "UPPOP", "UPRID", "UPRIP", "UPRUN", "UPSET", "UPSEY", "UPSIT", "UPSUN", "UPSUP", "UPTIE", "UPUPA", "UPWAX", "UPWAY", "URAEI", "URALI", "URARE", "URARI", "URASE", "URATE", "URBAN", "URBIC", "URDEE", "UREAL", "UREAS", "UREDO", "UREIC", "UREID", "URENA", "URENT", "URGED", "URGER", "URGES", "URIAH", "URIAL", "URIAN", "URIEL", "URINE", "URITE", "URLAR", "URLED", "URMAN", "URNAE", "URNAL", "URSAE", "URSAL", "URSID", "URSON", "URSUK", "URSUS", "URUBU", "URUCU", "URUTU", "USAGE", "USANT", "USARA", "USENT", "USERS", "USHAK", "USHAS", "USHER", "USINE", "USING", "USKOK", "USNEA", "USNIC", "USNIN", "USQUE", "USTER", "USUAL", "USURE", "USURP", "USURY", "UTCHY", "UTEES", "UTEND", "UTERI", "UTERO", "UTHER", "UTICK", "UTILE", "UTRUM", "UTSUK", "UTTER", "UVALA", "UVATE", "UVEAL", "UVEAS", "UVIOL", "UVITO", "UVRES", "UVROU", "UVULA", "UVVER", "UZARA", "UZBAK", "UZBEG", "UZBEK", "VACHE", "VACOA", "VACUA", "VACUO", "VADIM", "VADIS", "VAGAL", "VAGAS", "VAGUE", "VAGUS", "VAILS", "VAIRE", "VAIRS", "VAIRY", "VAJRA", "VAKIA", "VAKIL", "VALES", "VALET", "VALEW", "VALID", "VALMY", "VALOR", "VALSA", "VALSE", "VALUE", "VALVA", "VALVE", "VALYL", "VAMOS", "VAMPS", "VANCE", "VANDA", "VANED", "VANES", "VANGS", "VANIR", "VAPID", "VAPOR", "VAPPA", "VARAN", "VARAS", "VARDA", "VARDY", "VAREC", "VARIA", "VARIO", "VARIX", "VARNA", "VARUS", "VARVE", "VASAL", "VASES", "VASTS", "VASTY", "VATES", "VATIC", "VAUDY", "VAULT", "VAUNT", "VEALS", "VEALY", "VEDDA", "VEDET", "VEDIC", "VEDRO", "VEENA", "VEEPS", "VEERS", "VEERY", "VEFRY", "VEGAN", "VEGAS", "VEHME", "VEILS", "VEILY", "VEINS", "VEINY", "VEJOZ", "VELAL", "VELAR", "VELDS", "VELDT", "VELIC", "VELTE", "VELUM", "VENAE", "VENAL", "VENDS", "VENED", "VENGE", "VENIE", "VENIN", "VENOM", "VENTA", "VENTS", "VENUE", "VENUS", "VEPSE", "VERAY", "VERBS", "VERBY", "VERDE", "VERDI", "VEREK", "VEREY", "VERGE", "VERGI", "VERPA", "VERRE", "VERRY", "VERSA", "VERSE", "VERSO", "VERST", "VERTS", "VERTU", "VERTY", "VERUS", "VERVE", "VESPA", "VESTA", "VESTS", "VETCH", "VETER", "VETUS", "VEUVE", "VEXED", "VEXER", "VEXES", "VEXIL", "VIAGE", "VIALS", "VIAND", "VIBES", "VIBEX", "VIBIX", "VICAR", "VICED", "VICES", "VICHY", "VICIA", "VICKI", "VICKY", "VICUA", "VICUS", "VIDEO", "VIDRY", "VIDUA", "VIDYA", "VIERS", "VIEWS", "VIEWY", "VIFDA", "VIGAS", "VIGIA", "VIGIL", "VIGOR", "VIJAO", "VIJAY", "VILER", "VILLA", "VILLE", "VILLI", "VILLS", "VIMEN", "VIMPA", "VINAL", "VINAS", "VINCA", "VINCE", "VINCI", "VINEA", "VINED", "VINER", "VINES", "VINET", "VINEW", "VINGT", "VINIC", "VINNY", "VINOD", "VINOS", "VINTA", "VINUM", "VINYL", "VIOLA", "VIOLS", "VIPER", "VIRAL", "VIREO", "VIRES", "VIRGA", "VIRGE", "VIRGO", "VIRID", "VIRLS", "VIRON", "VIRTU", "VIRUS", "VISAS", "VISED", "VISES", "VISIE", "VISIT", "VISNE", "VISON", "VISOR", "VISTA", "VISTO", "VITAE", "VITAL", "VITIS", "VITRA", "VITRO", "VITRY", "VITTA", "VIUVA", "VIVAS", "VIVAT", "VIVAX", "VIVDA", "VIVEK", "VIVER", "VIVES", "VIVID", "VIVOS", "VIVRE", "VIXEN", "VIZIR", "VIZOR", "VIZZY", "VLACH", "VOBIS", "VOCAB", "VOCAL", "VOCAT", "VOCES", "VODER", "VODKA", "VODUM", "VODUN", "VOGIE", "VOGUE", "VOGUL", "VOICE", "VOIDS", "VOILA", "VOILE", "VOLAR", "VOLED", "VOLES", "VOLET", "VOLGA", "VOLOW", "VOLTA", "VOLTE", "VOLTI", "VOLTO", "VOLTS", "VOLVA", "VOMER", "VOMIT", "VORAZ", "VOTAL", "VOTED", "VOTER", "VOTES", "VOUCH", "VOUGE", "VOULI", "VOUST", "VOWED", "VOWEL", "VOWER", "VRAIC", "VROOM", "VROUW", "VROWS", "VUCOM", "VUGGS", "VUGGY", "VUGHS", "VULGO", "VULVA", "VYASE", "VYING", "WAAPA", "WAASI", "WABBY", "WACKE", "WACKS", "WACKY", "WADDY", "WADED", "WADER", "WADES", "WADGE", "WADIS", "WADNA", "WAEFU", "WAFER", "WAFFS", "WAFTS", "WAFTY", "WAGED", "WAGER", "WAGES", "WAGET", "WAGGA", "WAGGY", "WAGON", "WAHOO", "WAIFS", "WAILS", "WAILY", "WAINS", "WAIRD", "WAIRS", "WAISE", "WAIST", "WAITS", "WAIVE", "WAKAN", "WAKAS", "WAKED", "WAKEN", "WAKER", "WAKES", "WAKHI", "WAKIF", "WAKON", "WALED", "WALER", "WALES", "WALKS", "WALLA", "WALLS", "WALLY", "WALSH", "WALTH", "WALTY", "WALTZ", "WAMEL", "WAMES", "WAMUS", "WANDS", "WANDY", "WANED", "WANES", "WANEY", "WANGA", "WANKY", "WANLE", "WANLY", "WANNA", "WANNY", "WANTS", "WANTY", "WANZE", "WAPPO", "WARCH", "WARDS", "WARED", "WARES", "WARKS", "WARLY", "WARMS", "WARNS", "WARNT", "WARPS", "WARRI", "WARSE", "WARST", "WARTH", "WARTS", "WARTY", "WARUA", "WARVE", "WASAT", "WASCO", "WASEL", "WASHO", "WASHY", "WASIR", "WASNT", "WASPS", "WASPY", "WASTE", "WASTS", "WASTY", "WATAP", "WATCH", "WATER", "WATTS", "WAUCH", "WAUGH", "WAUKS", "WAULS", "WAUNS", "WAURA", "WAUVE", "WAVED", "WAVER", "WAVES", "WAVEY", "WAWAH", "WAWLS", "WAXED", "WAXEN", "WAXER", "WAXES", "WAYAO", "WAYNE", "WAZIR", "WEAKY", "WEALD", "WEALS", "WEANS", "WEARS", "WEARY", "WEAVE", "WEBBY", "WEBER", "WECHT", "WEDEL", "WEDGE", "WEDGY", "WEEDA", "WEEDS", "WEEDY", "WEEKS", "WEENS", "WEENT", "WEENY", "WEEPS", "WEEPY", "WEESH", "WEEST", "WEETS", "WEETY", "WEEZE", "WEFTS", "WEFTY", "WEHEE", "WEIGH", "WEIRD", "WEIRS", "WEISM", "WEKAS", "WEKAU", "WELCH", "WELDS", "WELLS", "WELLY", "WELSH", "WELTS", "WEMMY", "WENCH", "WENDE", "WENDI", "WENDS", "WENDY", "WENNY", "WEREN", "WERSH", "WESTE", "WESTS", "WESTY", "WETLY", "WEVET", "WEZEN", "WHACK", "WHALE", "WHALM", "WHALP", "WHALY", "WHAME", "WHAMP", "WHAMS", "WHAND", "WHANG", "WHANK", "WHAPS", "WHARE", "WHARF", "WHARL", "WHARP", "WHART", "WHASE", "WHATA", "WHATD", "WHATS", "WHAUK", "WHAUP", "WHAUR", "WHEAL", "WHEAM", "WHEAT", "WHEEL", "WHEEM", "WHEEN", "WHEEP", "WHEER", "WHEFT", "WHEIN", "WHEKI", "WHELK", "WHELM", "WHELP", "WHENS", "WHERE", "WHETS", "WHEWL", "WHEWS", "WHEWT", "WHEYS", "WHIBA", "WHICH", "WHICK", "WHIDS", "WHIFF", "WHIFT", "WHIGS", "WHILE", "WHILK", "WHILL", "WHILS", "WHIMS", "WHINE", "WHING", "WHINS", "WHINY", "WHIPS", "WHIPT", "WHIRL", "WHIRR", "WHIRS", "WHISH", "WHISK", "WHISP", "WHISS", "WHIST", "WHITE", "WHITS", "WHITY", "WHIZZ", "WHOLE", "WHOLL", "WHOMP", "WHONE", "WHOOF", "WHOOP", "WHOOT", "WHOPS", "WHORE", "WHORL", "WHORT", "WHORY", "WHOSE", "WHOSO", "WHSLE", "WHUFF", "WHULK", "WHUMP", "WHUSH", "WHUTE", "WICCA", "WICHT", "WICKS", "WICKY", "WIDDY", "WIDEN", "WIDER", "WIDES", "WIDOW", "WIDTH", "WIELD", "WIERD", "WIFED", "WIFES", "WIFIE", "WIGAN", "WIGGY", "WIGHT", "WILCO", "WILDS", "WILED", "WILES", "WILGA", "WILLI", "WILLS", "WILLY", "WILTS", "WINCE", "WINCH", "WINDS", "WINDY", "WINDZ", "WINED", "WINER", "WINES", "WINEY", "WINGS", "WINGY", "WINKS", "WINLY", "WINNA", "WINOS", "WINZE", "WIPED", "WIPER", "WIPES", "WIRED", "WIRER", "WIRES", "WIROS", "WIRRA", "WISED", "WISEN", "WISER", "WISES", "WISHA", "WISHT", "WISHY", "WISPS", "WISPY", "WISSE", "WISTE", "WISTS", "WITAN", "WITCH", "WITED", "WITEN", "WITES", "WITHE", "WITHY", "WITTY", "WIVED", "WIVER", "WIVES", "WIYAT", "WIYOT", "WIZEN", "WIZES", "WLITY", "WLOKA", "WOADS", "WOADY", "WOALD", "WOCAS", "WODEN", "WODGE", "WODGY", "WOFUL", "WOGUL", "WOIBE", "WOKAS", "WOKEN", "WOLDS", "WOLDY", "WOLFS", "WOLLY", "WOLOF", "WOLVE", "WOMAN", "WOMBS", "WOMBY", "WOMEN", "WONGA", "WONKY", "WONNA", "WONTS", "WOODS", "WOODY", "WOOED", "WOOER", "WOOFS", "WOOFY", "WOOLD", "WOOLF", "WOOLS", "WOOLY", "WOOMP", "WOONS", "WOOPS", "WOOSH", "WOOTZ", "WOOZY", "WOPSY", "WORDS", "WORDY", "WORKS", "WORKY", "WORLD", "WORMS", "WORMY", "WORRY", "WORSE", "WORST", "WORTH", "WORTS", "WOUCH", "WOUGH", "WOULD", "WOUND", "WOVEN", "WOWED", "WRACK", "WRAMP", "WRANG", "WRAPS", "WRAPT", "WRAST", "WRATH", "WRAWL", "WREAK", "WREAT", "WRECK", "WRENS", "WREST", "WRICK", "WRIDE", "WRIED", "WRIER", "WRIES", "WRING", "WRIST", "WRITE", "WRITH", "WRITS", "WRIVE", "WROKE", "WRONG", "WROOT", "WROTE", "WROTH", "WRUNG", "WRYER", "WRYLY", "WUDGE", "WUNNA", "WURLY", "WURST", "WUZZY", "WYLED", "WYLES", "WYNDS", "WYNNE", "WYNNS", "WYSON", "WYSTY", "WYTED", "WYTES", "WYVER", "XEBEC", "XENIA", "XENIC", "XENON", "XENOS", "XENYL", "XERES", "XERIC", "XEROX", "XERUS", "XICAK", "XINCA", "XOANA", "XUREL", "XVIII", "XXIII", "XYLAN", "XYLEM", "XYLIA", "XYLIC", "XYLOL", "XYLON", "XYLYL", "XYRID", "XYRIS", "XYSTI", "XYSTS", "YABBI", "YABBY", "YABOO", "YACAL", "YACCA", "YACHT", "YACKS", "YADIM", "YAFFS", "YAGER", "YAGIS", "YAGUA", "YAHAN", "YAHOO", "YAIRD", "YAJNA", "YAKAN", "YAKIN", "YAKKA", "YAKUT", "YALLA", "YAMEL", "YAMEN", "YAMEO", "YAMPA", "YAMPH", "YAMUN", "YANAN", "YANGS", "YANKS", "YANKY", "YAPLY", "YAPOK", "YAPON", "YAPPY", "YAQUI", "YARAK", "YARAY", "YARDS", "YARER", "YARKE", "YARLY", "YARNS", "YARRY", "YARTH", "YASHT", "YASNA", "YAUDS", "YAULD", "YAUPS", "YAWED", "YAWEY", "YAWLS", "YAWNS", "YAWNY", "YAWPS", "YAZOO", "YCLAD", "YEANS", "YEARA", "YEARD", "YEARN", "YEARS", "YEAST", "YECCH", "YECHS", "YECHY", "YEECH", "YEGGS", "YELEK", "YELKS", "YELLS", "YELPS", "YEMEN", "YENTA", "YENTE", "YEPLY", "YERBA", "YERGA", "YERKS", "YERTH", "YERVA", "YESES", "YESSO", "YESTY", "YETIS", "YETTS", "YEUKS", "YEUKY", "YEVEN", "YEZDI", "YEZZY", "YFERE", "YGAPO", "YIELD", "YIKES", "YILLS", "YINCE", "YINST", "YIPES", "YIRDS", "YIRRS", "YIRTH", "YLEMS", "YOBBO", "YOCCO", "YOCKS", "YODEL", "YODHS", "YODLE", "YOGAS", "YOGEE", "YOGHS", "YOGIC", "YOGIN", "YOGIS", "YOICK", "YOJAN", "YOKED", "YOKEL", "YOKER", "YOKES", "YOLKS", "YOLKY", "YOMER", "YOMIM", "YOMIN", "YOMUD", "YONIC", "YONIS", "YORES", "YOUFF", "YOUNG", "YOURE", "YOURN", "YOURS", "YOURT", "YOUSE", "YOUTH", "YOUVE", "YOUZE", "YOVEN", "YOWED", "YOWES", "YOWIE", "YOWLS", "YQUEM", "YTTER", "YUANS", "YUCCA", "YUCCH", "YUCHI", "YUCKS", "YUCKY", "YUGAS", "YUKON", "YULAN", "YULES", "YUMAN", "YUMMY", "YUNCA", "YUPON", "YURAK", "YUROK", "YURTA", "YURTS", "YURUK", "ZABRA", "ZABTI", "ZAIRE", "ZAKAH", "ZAKAT", "ZAMAN", "ZAMBO", "ZAMIA", "ZANDE", "ZANTE", "ZANZA", "ZANZE", "ZAPAS", "ZAPUS", "ZAQUE", "ZARFS", "ZAXES", "ZAYAT", "ZAYIN", "ZAZEN", "ZEALS", "ZEBEC", "ZEBRA", "ZEBUB", "ZEBUS", "ZEINS", "ZEISM", "ZEISS", "ZEIST", "ZEMMI", "ZEMNI", "ZENDO", "ZERDA", "ZERMA", "ZEROS", "ZESTS", "ZESTY", "ZETAS", "ZHMUD", "ZIARA", "ZIBET", "ZIEGA", "ZIFFS", "ZIGAN", "ZIHAR", "ZILCH", "ZILLA", "ZILLS", "ZIMBI", "ZIMME", "ZIMMI", "ZIMMY", "ZINCO", "ZINCS", "ZINCY", "ZINEB", "ZINGS", "ZINGY", "ZINKE", "ZINKY", "ZIPPY", "ZIRAI", "ZIRAK", "ZIRAM", "ZITIS", "ZIZEL", "ZIZIA", "ZIZIT", "ZLOTE", "ZLOTY", "ZMUDZ", "ZOAEA", "ZOCCO", "ZOEAE", "ZOEAL", "ZOEAS", "ZOGAN", "ZOHAK", "ZOISM", "ZOIST", "ZOKOR", "ZOLLE", "ZOMBI", "ZONAL", "ZONAR", "ZONDA", "ZONED", "ZONER", "ZONES", "ZONIC", "ZONTA", "ZOOID", "ZOOKS", "ZOOMS", "ZOONA", "ZOONS", "ZOOTY", "ZOQUE", "ZORIL", "ZORIS", "ZORRO", "ZOSMA", "ZOWIE", "ZUCCO", "ZUDDA", "ZULUS", "ZUNIS", "ZYGAL", "ZYGON", "ZYMES", "ZYMIC", "ZYMIN"];

// src/solver/solver.ts
function scoreGuess(guess, answer) {
  let code = 0;
  let greens = 0;
  let place = 1;
  for (let i = 0; i < 5; i++) {
    if (guess[i] === answer[i]) {
      greens |= 1 << i;
      code += 2 * place;
    }
    place *= 3;
  }
  let used = greens;
  place = 1;
  for (let i = 0; i < 5; i++) {
    if (!(greens & 1 << i)) {
      for (let j = 0; j < 5; j++) {
        if (!(used & 1 << j) && guess[i] === answer[j]) {
          used |= 1 << j;
          code += place;
          break;
        }
      }
    }
    place *= 3;
  }
  return code;
}
function feedbackCells(word, code) {
  return [...word].map((letter, index) => ({
    letter,
    status: ["absent", "present", "correct"][Math.floor(code / 3 ** index) % 3]
  }));
}

// src/types/playTypes.ts
var PLAY_SESSIONS_KEY = "wordlePlaySessions";
var PLAY_SELECTION_KEY = "wordlePlaySelection";
var PLAY_READER_AVERAGES_KEY = "wordlePlayReaderAverages";
function localPuzzleDate(now = /* @__PURE__ */ new Date()) {
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}
function playStatus(rows) {
  if (rows.some(
    (row) => row.length === 5 && row.every((cell) => cell.status === "correct")
  ))
    return "won";
  return rows.length >= 6 ? "lost" : "playing";
}

// src/utils/playHistory.ts
var SHOW_UNPLAYED_KEY = "wordleShowUnplayed";
function hasUserGame(game) {
  if (!game) return false;
  const guesses = game.guesses;
  return Boolean(
    game.won || game.completed || typeof game.attempts === "number" && game.attempts > 0 || typeof guesses === "number" && guesses > 0 || game.guessPattern?.some(
      (row) => row.some((cell) => Boolean(cell.letter?.trim()))
    ) || Array.isArray(guesses) && guesses.some(
      (row) => typeof row === "string" ? Boolean(row.trim()) : Array.isArray(row) && row.some(
        (cell) => typeof cell === "string" ? Boolean(cell.trim()) : Boolean(cell?.letter || cell?.value)
      )
    )
  );
}
function gamesWithPlaySessions(games, sessions, readers = {}) {
  const byDate = new Map(games.map((game) => [game.date, game]));
  for (const session of Object.values(sessions)) {
    if (hasUserGame(byDate.get(session.date)) || !session.rows.length || session.status === "playing" && session.canPlay !== false)
      continue;
    byDate.set(session.date, {
      ...byDate.get(session.date),
      date: session.date,
      attempts: session.rows.length,
      won: session.status === "won",
      completed: session.status !== "playing",
      hardMode: false,
      guessPattern: session.rows,
      solution: session.answer || (session.status === "won" ? session.rows[session.rows.length - 1]?.map((cell) => cell.letter).join("") : void 0),
      ...byDate.get(session.date)?.nytReaderSource === "manual" ? {} : readers[session.date],
      metadata: {
        ...byDate.get(session.date)?.metadata,
        extensionPlayMode: session.mode
      }
    });
  }
  return [...byDate.values()];
}
function buildGameHistory(games, showUnplayed, today = localPuzzleDate()) {
  const byDate = new Map(
    games.filter(
      (game) => /^\d{4}-\d{2}-\d{2}$/.test(game.date) && Number.isFinite(Date.parse(game.date)) && new Date(game.date).toISOString().slice(0, 10) === game.date && game.date >= "2021-06-19" && game.date <= today
    ).map((game) => [game.date, game])
  );
  if (showUnplayed) {
    const start = [...byDate.keys()].sort()[0] || today;
    const cursor = /* @__PURE__ */ new Date(`${start}T12:00:00Z`);
    while (cursor.toISOString().slice(0, 10) <= today) {
      const date = cursor.toISOString().slice(0, 10);
      if (!byDate.has(date))
        byDate.set(date, { date, attempts: 0, won: false, hardMode: false });
      cursor.setUTCDate(cursor.getUTCDate() + 1);
    }
  }
  return [...byDate.values()].filter((game) => showUnplayed || hasUserGame(game)).sort((a, b) => b.date.localeCompare(a.date));
}

// src/extension/background/playService.ts
var dictionary = new Set(words_default.map((word) => word.toUpperCase()));
var nytUrl = "https://www.nytimes.com/games/wordle/index.html";
var queue = Promise.resolve();
var playWindowId;
function checkDate(date) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(Date.parse(date)) || new Date(date).toISOString().slice(0, 10) !== date || date > localPuzzleDate())
    throw new Error("Choose today or an available past puzzle.");
}
async function readSession(date) {
  checkDate(date);
  const stored = await chrome.storage.local.get(PLAY_SESSIONS_KEY);
  const session = stored[PLAY_SESSIONS_KEY]?.[date];
  const game = (await ExtensionStorage.getInstance().getAllGames()).find(
    (item) => item.date === date
  );
  if (hasUserGame(game))
    return {
      date,
      mode: date === localPuzzleDate() ? "live" : "replay",
      rows: game?.guessPattern || [],
      draft: "",
      status: game?.won ? "won" : game?.completed ? "lost" : "playing",
      canPlay: false
    };
  if (session) {
    if (session.mode !== "live" || date === localPuzzleDate() || session.rows.length)
      return {
        ...session,
        canPlay: session.status === "playing" && session.canPlay !== false && !(session.mode === "live" && date < localPuzzleDate())
      };
  }
  return {
    date,
    mode: date === localPuzzleDate() ? "live" : "replay",
    rows: [],
    draft: "",
    status: "playing",
    canPlay: true
  };
}
async function saveSession(session) {
  const stored = await chrome.storage.local.get(PLAY_SESSIONS_KEY);
  await chrome.storage.local.set({
    [PLAY_SESSIONS_KEY]: {
      ...stored[PLAY_SESSIONS_KEY],
      [session.date]: session
    }
  });
}
async function replayAnswer(date) {
  if (date >= localPuzzleDate())
    throw new Error("Today's answer must come from NYT gameplay.");
  const games = await ExtensionStorage.getInstance().getAllGames();
  const answer = games.find((game) => game.date === date)?.solution?.trim().toUpperCase();
  if (answer && /^[A-Z]{5}$/.test(answer)) return answer;
  const key = "wordlePastPuzzles";
  const stored = await chrome.storage.local.get(key);
  const cached = stored[key]?.[date];
  if (cached?.print_date === date && /^[A-Za-z]{5}$/.test(cached.solution))
    return cached.solution.toUpperCase();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 1e4);
  try {
    const response = await fetch(
      `https://www.nytimes.com/svc/wordle/v2/${date}.json`,
      { signal: controller.signal }
    );
    if (!response.ok) throw new Error("Puzzle unavailable");
    const puzzle = await response.json();
    if (puzzle.print_date !== date || !/^[A-Za-z]{5}$/.test(puzzle.solution))
      throw new Error("Unrecognized puzzle");
    await chrome.storage.local.set({
      [key]: {
        ...stored[key],
        [date]: { print_date: date, solution: puzzle.solution }
      }
    });
    return puzzle.solution.toUpperCase();
  } catch {
    throw new Error(
      "Could not retrieve this past puzzle from NYT. Try again later."
    );
  } finally {
    clearTimeout(timer);
  }
}
async function liveTab(session, create) {
  const tabs = await chrome.tabs.query({
    url: "https://www.nytimes.com/games/wordle*"
  });
  const tab = tabs.find((item) => item.id === session.nytTabId) || tabs[0];
  if (tab) return tab;
  if (!create)
    throw new Error("NYT tab unavailable. Reopen this view to retry.");
  return chrome.tabs.create({ url: nytUrl, active: false });
}
async function sendToNyt(tabId, message, wait) {
  const deadline = Date.now() + (wait ? 15e3 : 0);
  do {
    try {
      return await chrome.tabs.sendMessage(tabId, message);
    } catch {
      if (Date.now() >= deadline)
        throw new Error(
          "NYT is not ready. Open its tab, finish any prompts, then reopen this view."
        );
      await new Promise((resolve) => setTimeout(resolve, 500));
    }
  } while (Date.now() < deadline);
  throw new Error(
    "NYT is not ready. Open its tab, finish any prompts, then reopen this view."
  );
}
function applyLive(session, response, tabId) {
  if (!response?.success)
    throw new Error(response?.error || "Could not read the NYT board.");
  const rows = response.rows;
  if (!Array.isArray(rows) || rows.length > 6 || !rows.every(
    (row) => Array.isArray(row) && row.length === 5 && row.every(
      (cell) => /^[A-Z]$/.test(cell.letter) && ["correct", "present", "absent"].includes(cell.status)
    )
  ))
    throw new Error(
      "NYT returned an unrecognized board. Open its tab to continue."
    );
  return {
    date: session.date,
    mode: "live",
    rows,
    draft: rows.length === session.rows.length ? session.draft : "",
    draftClient: rows.length === session.rows.length ? session.draftClient : void 0,
    status: playStatus(rows),
    nytTabId: tabId,
    canPlay: session.canPlay !== false && !(!session.nytTabId && !session.rows.length && rows.length > 0)
  };
}
function handlePlayMessage(message) {
  const operation = queue.then(() => handle(message));
  queue = operation.catch(() => void 0);
  return operation;
}
async function handle(message) {
  const today = localPuzzleDate();
  if (message.type === "GET_PLAY_CATALOG" /* GET_PLAY_CATALOG */) {
    const games = await ExtensionStorage.getInstance().getAllGames();
    const stored = await chrome.storage.local.get([
      PLAY_SELECTION_KEY,
      PLAY_SESSIONS_KEY,
      SHOW_UNPLAYED_KEY
    ]);
    const history = buildGameHistory(
      gamesWithPlaySessions(games, stored[PLAY_SESSIONS_KEY] || {}),
      true,
      today
    );
    const dates = history.filter((game) => !hasUserGame(game)).map((game) => game.date);
    const selection = stored[PLAY_SELECTION_KEY];
    return {
      success: true,
      today,
      dates,
      history: history.map((game) => ({
        date: game.date,
        played: hasUserGame(game)
      })),
      showUnplayed: stored[SHOW_UNPLAYED_KEY] === true,
      date: history.some((game) => game.date === selection) ? selection : today
    };
  }
  const date = message.date || today;
  let session = await readSession(date);
  if (message.type === "OPEN_PLAY_WINDOW" /* OPEN_PLAY_WINDOW */) {
    await chrome.storage.local.set({ [PLAY_SELECTION_KEY]: date });
    const url = chrome.runtime.getURL("popup.html") + "?popout=1";
    if (playWindowId !== void 0) {
      try {
        await chrome.windows.update(playWindowId, { focused: true });
        return { success: true };
      } catch {
        playWindowId = void 0;
      }
    }
    const created = await chrome.windows.create({
      url,
      type: "popup",
      width: 400,
      height: 660
    });
    playWindowId = created.id;
    return { success: true };
  }
  if (message.type === "OPEN_NYT_PLAY_TAB" /* OPEN_NYT_PLAY_TAB */) {
    const tab = await liveTab(session, true);
    if (tab.id !== void 0)
      await chrome.tabs.update(tab.id, { active: true });
    return { success: true };
  }
  if (message.type === "GET_PLAY_SESSION" /* GET_PLAY_SESSION */) {
    if (session.canPlay) await saveSession(session);
    await chrome.storage.local.set({ [PLAY_SELECTION_KEY]: date });
    return { success: true, session };
  }
  if (session.status !== "playing")
    throw new Error("This game is already finished.");
  if (session.canPlay === false)
    throw new Error("Play is only available on dates without a user game.");
  if (message.type === "SAVE_PLAY_DRAFT" /* SAVE_PLAY_DRAFT */) {
    if (message.expectedRows !== session.rows.length)
      return { success: true, session };
    if (!/^[A-Za-z]{0,5}$/.test(message.draft || ""))
      throw new Error("Use up to five letters.");
    session = {
      ...session,
      draft: (message.draft || "").toUpperCase(),
      draftClient: message.client
    };
  } else if (message.type === "RESET_PLAY_REPLAY" /* RESET_PLAY_REPLAY */) {
    if (session.mode !== "replay")
      throw new Error("Today's official game cannot be reset.");
    session = { date, mode: "replay", rows: [], draft: "", status: "playing" };
  } else if (message.type === "CONNECT_NYT_PLAY" /* CONNECT_NYT_PLAY */) {
    if (session.mode !== "live")
      throw new Error("Only today's game connects to NYT.");
    const tab = await liveTab(session, !message.poll);
    if (tab.id === void 0) throw new Error("Could not open NYT.");
    const response = await sendToNyt(
      tab.id,
      {
        type: "NYT_PLAY_STATE" /* NYT_PLAY_STATE */,
        date,
        prepare: !message.poll
      },
      !message.poll
    );
    session = applyLive(session, response, tab.id);
  } else if (message.type === "SUBMIT_PLAY_GUESS" /* SUBMIT_PLAY_GUESS */) {
    const guess = message.guess?.trim().toUpperCase() || "";
    if (!/^[A-Z]{5}$/.test(guess))
      return {
        success: false,
        invalidGuess: true,
        error: "Enter a five-letter word."
      };
    if (session.status !== "playing")
      throw new Error("This game is already finished.");
    if (message.expectedRows !== session.rows.length)
      throw new Error(
        "The board changed in another window. Check it before submitting again."
      );
    if (session.mode === "replay") {
      const answer = await replayAnswer(date);
      if (!dictionary.has(guess) && guess !== answer)
        return {
          success: false,
          invalidGuess: true,
          error: "Not in the replay word list."
        };
      const rows = [
        ...session.rows,
        feedbackCells(guess, scoreGuess(guess, answer))
      ];
      session = {
        date,
        mode: "replay",
        rows,
        draft: "",
        status: playStatus(rows)
      };
      if (session.status !== "playing") session.answer = answer;
    } else {
      const tab = await liveTab(session, false);
      if (tab.id === void 0)
        throw new Error("NYT tab unavailable. Reopen this view to retry.");
      const response = await sendToNyt(
        tab.id,
        {
          type: "NYT_PLAY_GUESS" /* NYT_PLAY_GUESS */,
          date,
          guess,
          expectedRows: message.expectedRows
        },
        false
      );
      if (!response?.success && response?.rows) {
        await saveSession(
          applyLive(session, { success: true, rows: response.rows }, tab.id)
        );
      }
      if (response?.invalidGuess) return response;
      session = applyLive(session, response, tab.id);
    }
  } else throw new Error("Unknown play request.");
  await saveSession(session);
  return { success: true, session };
}

// src/extension/background/background.ts
var log2 = logger_default.log;
var errorLog2 = logger_default.error;
var storageService;
var SCRAPE_STATUS_STORAGE_KEY = "wordleBotScrapeStatus";
var dashboardTabId = null;
var currentScrapeStatus = {
  phase: "idle",
  gamesFound: 0,
  gamesProcessed: 0,
  newGames: 0,
  duplicates: 0,
  errors: 0,
  lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
  statusMessage: "Idle",
  error: null
};
async function updateScrapeStatus(update) {
  const nextPhase = update.phase ?? currentScrapeStatus.phase;
  currentScrapeStatus = {
    ...currentScrapeStatus,
    ...update,
    phase: nextPhase,
    lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
  };
  try {
    await chrome.storage.local.set({
      [SCRAPE_STATUS_STORAGE_KEY]: currentScrapeStatus
    });
  } catch (storageError) {
    errorLog2("[Background] Failed to persist scrape status:", storageError);
  }
  log2("[Background] =====> Sending WORDLE_BOT_SCRAPE_STATUS_UPDATED message:", currentScrapeStatus);
  chrome.runtime.sendMessage({
    type: "WORDLE_BOT_SCRAPE_STATUS_UPDATED" /* WORDLE_BOT_SCRAPE_STATUS_UPDATED */,
    status: currentScrapeStatus
  }).then(() => {
    log2("[Background] =====> STATUS_UPDATED message sent successfully");
  }).catch((err) => {
    log2("[Background] =====> STATUS_UPDATED message failed:", err);
  });
}
async function loadInitialScrapeStatus() {
  try {
    const result = await chrome.storage.local.get([SCRAPE_STATUS_STORAGE_KEY]);
    if (result && result[SCRAPE_STATUS_STORAGE_KEY]) {
      currentScrapeStatus = {
        ...currentScrapeStatus,
        ...result[SCRAPE_STATUS_STORAGE_KEY]
      };
    } else {
      await chrome.storage.local.set({
        [SCRAPE_STATUS_STORAGE_KEY]: currentScrapeStatus
      });
    }
  } catch (error) {
    errorLog2("[Background] Failed to hydrate scrape status from storage:", error);
  }
}
var initialScrapeStatus = loadInitialScrapeStatus().catch(() => {
});
chrome.runtime.onInstalled.addListener(async (details) => {
  log2("[Background] Extension installed:", details.reason);
  try {
    storageService = ExtensionStorage.getInstance();
    await storageService.initialize();
    if (details.reason === "install") {
      await initializeExtension();
    } else if (details.reason === "update") {
      await handleExtensionUpdate(details.previousVersion);
    }
  } catch (error) {
    errorLog2("[Background] Extension initialization failed:", error);
  }
});
chrome.runtime.onMessage.addListener(
  (message, sender, sendResponse) => {
    log2("[BACKGROUND DEBUG] Received message:", message.type, message);
    log2("[BACKGROUND DEBUG] Sender:", sender);
    handleExtensionMessage(message, sender).then((response) => {
      log2("[BACKGROUND DEBUG] Sending response:", response);
      sendResponse(response ?? null);
    }).catch((error) => {
      console.error("[BACKGROUND DEBUG] Message handling error:", error);
      sendResponse({
        success: false,
        error: error.message
      });
    });
    return true;
  }
);
async function initializeExtension() {
  try {
    await chrome.storage.sync.set({
      preferences: {
        theme: "system",
        defaultTimeFrame: "30d",
        showBenchmarks: true,
        enableNotifications: false,
        autoImport: true
      },
      lastSyncTime: Date.now(),
      version: chrome.runtime.getManifest().version
    });
    console.log("[Background] Extension initialized with default settings");
  } catch (error) {
    console.error("[Background] Failed to initialize extension:", error);
  }
}
async function handleExtensionUpdate(previousVersion) {
  try {
    console.log(`[Background] Updating from version ${previousVersion}`);
    if (previousVersion && compareVersions(previousVersion, "1.0.0") < 0) {
      await migrateToV1();
    }
    await chrome.storage.sync.set({
      version: chrome.runtime.getManifest().version,
      lastUpdateTime: Date.now()
    });
  } catch (error) {
    console.error("[Background] Failed to handle extension update:", error);
  }
}
async function handleExtensionMessage(message, _sender) {
  switch (message.type) {
    case "GET_PLAY_CATALOG" /* GET_PLAY_CATALOG */:
    case "GET_PLAY_SESSION" /* GET_PLAY_SESSION */:
    case "SAVE_PLAY_DRAFT" /* SAVE_PLAY_DRAFT */:
    case "SUBMIT_PLAY_GUESS" /* SUBMIT_PLAY_GUESS */:
    case "RESET_PLAY_REPLAY" /* RESET_PLAY_REPLAY */:
    case "CONNECT_NYT_PLAY" /* CONNECT_NYT_PLAY */:
    case "OPEN_PLAY_WINDOW" /* OPEN_PLAY_WINDOW */:
    case "OPEN_NYT_PLAY_TAB" /* OPEN_NYT_PLAY_TAB */:
      return handlePlayMessage(message);
    case "IMPORT_GAME_RESULT" /* IMPORT_GAME_RESULT */:
      return handleImportGameResult(message);
    case "GET_QUICK_STATS" /* GET_QUICK_STATS */:
      return handleGetQuickStats(message);
    case "GET_DASHBOARD_DATA" /* GET_DASHBOARD_DATA */:
      return handleGetDashboardData(message);
    case "GET_NYT_READER_AVERAGE" /* GET_NYT_READER_AVERAGE */:
      return handleGetNytReaderAverage(message);
    case "OPEN_DASHBOARD_TAB" /* OPEN_DASHBOARD_TAB */:
      return handleOpenDashboardTab(message);
    case "SYNC_DATA" /* SYNC_DATA */:
      return handleSyncData();
    case "EXPORT_DATA" /* EXPORT_DATA */:
      return handleExportData();
    case "CLEAR_DATA" /* CLEAR_DATA */:
      return handleClearData();
    case "START_WORDLE_BOT_SCRAPE" /* START_WORDLE_BOT_SCRAPE */:
      return handleStartWordleBotScrape(message);
    case "BULK_IMPORT_GAMES":
      console.log(`[Background] =====> Received BULK_IMPORT_GAMES message`);
      return handleBulkImportGames(message.games);
    case "WORDLE_BOT_SCRAPE_PROGRESS" /* WORDLE_BOT_SCRAPE_PROGRESS */:
      return handleWordleBotScrapeProgress(message);
    case "WORDLE_BOT_SCRAPE_COMPLETE" /* WORDLE_BOT_SCRAPE_COMPLETE */:
      return handleWordleBotScrapeComplete(message);
    case "WORDLE_BOT_SCRAPE_ERROR" /* WORDLE_BOT_SCRAPE_ERROR */:
      return handleWordleBotScrapeError(message);
    case "GET_WORDLE_BOT_SCRAPE_STATUS" /* GET_WORDLE_BOT_SCRAPE_STATUS */:
      return handleGetWordleBotScrapeStatus();
    default:
      throw new Error(`Unknown message type: ${message.type}`);
  }
}
async function handleGetNytReaderAverage(message) {
  if (!storageService) {
    storageService = ExtensionStorage.getInstance();
    await storageService.initialize();
  }
  const games = await storageService.getAllGames();
  const importedGame = games.find((game2) => game2.date === message.date);
  let game = importedGame;
  if (!hasUserGame(game)) {
    const stored = await chrome.storage.local.get([PLAY_SESSIONS_KEY, PLAY_READER_AVERAGES_KEY]);
    game = gamesWithPlaySessions(games, stored[PLAY_SESSIONS_KEY] || {}, stored[PLAY_READER_AVERAGES_KEY] || {}).find((game2) => game2.date === message.date);
  }
  if (!game) return { success: true, game: null };
  let hardMode;
  if (typeof message.hardMode === "boolean") {
    const words = game.guessPattern?.map(
      (row) => row.map((cell) => cell.letter).join("").toUpperCase()
    ).filter((word) => /^[A-Z]{5}$/.test(word));
    if (!words?.length || JSON.stringify(words) !== JSON.stringify(message.words)) {
      return { success: false, game: null };
    }
    hardMode = message.hardMode;
  }
  if (game.nytReaderSource === "manual") return { success: true, game };
  const readers = await fetchNytReaderAverage({
    ...game,
    hardMode: hardMode ?? game.hardMode
  });
  if (!hasUserGame(importedGame)) {
    if (readers && game.metadata?.extensionPlayMode) {
      const stored = await chrome.storage.local.get(PLAY_READER_AVERAGES_KEY);
      const averages = stored[PLAY_READER_AVERAGES_KEY] || {};
      const previous = averages[game.date];
      if (previous?.nytReaderAverage !== readers.nytReaderAverage || previous?.nytReaderMode !== readers.nytReaderMode || previous?.nytReaderSource !== readers.nytReaderSource)
        await chrome.storage.local.set({
          [PLAY_READER_AVERAGES_KEY]: { ...averages, [game.date]: readers }
        });
    }
    return { success: true, game: readers ? { ...game, ...readers } : game };
  }
  return {
    success: true,
    game: readers ? await storageService.updateReaderAverage(game.date, readers, hardMode) : game
  };
}
async function handleImportGameResult(message) {
  try {
    console.log("[Background] Importing game result:", message.gameResult);
    if (!storageService) {
      storageService = ExtensionStorage.getInstance();
      await storageService.initialize();
    }
    await storageService.saveGame(message.gameResult);
    console.log("[Background] Game result saved successfully");
    const games = await storageService.getAllGames();
    await updateExtensionBadge(games);
    return { success: true };
  } catch (error) {
    console.error("[Background] Failed to import game result:", error);
    throw error;
  }
}
async function handleGetQuickStats(message) {
  try {
    const result = await chrome.storage.local.get(["games"]);
    const games = result.games || [];
    console.log(`[BACKGROUND DEBUG] GET_QUICK_STATS: Total games in storage: ${games.length}`);
    console.log(`[BACKGROUND DEBUG] GET_QUICK_STATS: Timeframe requested: ${message.timeFrame}`);
    if (games.length > 0) {
      console.log(`[BACKGROUND DEBUG] GET_QUICK_STATS: Sample game dates:`, games.slice(0, 5).map((g2) => g2.date));
    }
    const filteredGames = filterGamesByTimeFrame(games, message.timeFrame);
    console.log(`[BACKGROUND DEBUG] GET_QUICK_STATS: Filtered games count: ${filteredGames.length}`);
    if (filteredGames.length > 0) {
      console.log(`[BACKGROUND DEBUG] GET_QUICK_STATS: Filtered game dates:`, filteredGames.map((g2) => g2.date));
      console.log(
        `[BACKGROUND DEBUG] GET_QUICK_STATS: Filtered game details:`,
        filteredGames.map((g2) => {
          const turns = (() => {
            if (typeof g2.attempts === "number" && !Number.isNaN(g2.attempts)) {
              return g2.attempts;
            }
            if (typeof g2.guesses === "number" && !Number.isNaN(g2.guesses)) {
              return g2.guesses;
            }
            if (typeof g2.steps === "number" && !Number.isNaN(g2.steps)) {
              return g2.steps;
            }
            if (Array.isArray(g2.guessPattern)) {
              return g2.guessPattern.length;
            }
            return 0;
          })();
          return {
            date: g2.date,
            turns,
            won: g2.won === true
          };
        })
      );
    }
    const statistics = calculateStatistics(filteredGames, games);
    console.log(`[BACKGROUND DEBUG] GET_QUICK_STATS: Calculated statistics:`, statistics);
    let lastGame = null;
    if (games.length > 0) {
      const sortedGames = [...games].sort(
        (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
      );
      lastGame = sortedGames[0];
      console.log(`[BACKGROUND DEBUG] GET_QUICK_STATS: Last game:`, lastGame);
    }
    return {
      success: true,
      statistics,
      lastGame,
      timeFrame: message.timeFrame
    };
  } catch (error) {
    console.error("[Background] Failed to get quick stats:", error);
    throw error;
  }
}
async function handleGetDashboardData(message) {
  try {
    if (!storageService) {
      storageService = ExtensionStorage.getInstance();
      await storageService.initialize();
    }
    const [games, preferences] = await Promise.all([
      storageService.getAllGames(),
      storageService.getPreferences()
    ]);
    const benchmarksResult = await chrome.storage.local.get(["benchmarks"]);
    return {
      success: true,
      games,
      benchmarks: benchmarksResult.benchmarks || [],
      preferences: preferences || {},
      timeFrames: message.timeFrames || ["7d", "30d", "90d", "all"]
    };
  } catch (error) {
    console.error("[Background] Failed to get dashboard data:", error);
    throw error;
  }
}
async function handleSyncData() {
  try {
    console.log("[Background] Synchronizing data...");
    const { preferences } = await chrome.storage.sync.get(["preferences"]);
    if (preferences?.cloudSync) {
      console.log("[Background] Cloud sync is enabled, syncing data...");
    }
    await chrome.storage.sync.set({
      lastSyncTime: Date.now()
    });
  } catch (error) {
    console.error("[Background] Failed to sync data:", error);
    throw error;
  }
}
async function handleExportData() {
  try {
    const result = await chrome.storage.local.get(["games"]);
    const games = result.games || [];
    const exportData = {
      version: chrome.runtime.getManifest().version,
      exportDate: (/* @__PURE__ */ new Date()).toISOString(),
      games
    };
    return {
      data: JSON.stringify(exportData, null, 2),
      filename: `wordle-stats-${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.json`
    };
  } catch (error) {
    console.error("[Background] Failed to export data:", error);
    throw error;
  }
}
async function handleClearData() {
  try {
    await chrome.storage.local.clear();
    await chrome.storage.sync.remove(["lastSyncTime", "lastImportTime"]);
    chrome.action.setBadgeText({ text: "" });
    console.log("[Background] All data cleared");
  } catch (error) {
    console.error("[Background] Failed to clear data:", error);
    throw error;
  }
}
var scraperTabId = null;
async function handleStartWordleBotScrape(message) {
  try {
    console.log(`[BACKGROUND DEBUG] Starting WordleBot scrape (mode: ${message.mode})`);
    console.log("[BACKGROUND DEBUG] Storage service available:", !!storageService);
    await initialScrapeStatus;
    if ((currentScrapeStatus.phase === "checking" || currentScrapeStatus.phase === "importing") && Date.now() - Date.parse(currentScrapeStatus.lastUpdated) < 3e5) {
      return { success: true, skipped: true, reason: "A history import is already running." };
    }
    await updateScrapeStatus({
      phase: "checking",
      mode: message.mode,
      gamesFound: 0,
      gamesProcessed: 0,
      newGames: 0,
      duplicates: 0,
      errors: 0,
      error: null,
      dateRange: null,
      statusMessage: "Checking history"
    });
    if (!storageService) {
      console.log("[BACKGROUND DEBUG] Initializing storage service...");
      storageService = ExtensionStorage.getInstance();
      await storageService.initialize();
    }
    const stopAtDate = message.stopAtDate;
    console.log("[BACKGROUND DEBUG] Storing scrape parameters in storage...");
    await chrome.storage.local.set({
      wordleBotScrapeParams: {
        mode: message.mode,
        stopAtDate,
        maxIterations: message.maxIterations || 200,
        timestamp: Date.now()
      }
    });
    console.log("[BACKGROUND DEBUG] Creating WordleBot tab...");
    const tab = await chrome.tabs.create({
      url: "https://www.nytimes.com/interactive/2022/upshot/wordle-bot.html",
      active: false
    });
    scraperTabId = tab.id || null;
    console.log("[BACKGROUND DEBUG] Opened WordleBot tab:", scraperTabId);
    console.log("[BACKGROUND DEBUG] Tab created, content script will auto-start scraping");
    return { success: true, ...scraperTabId ? { tabId: scraperTabId } : {}, message: "Scraping started" };
  } catch (error) {
    console.error("[Background] Failed to start WordleBot scrape:", error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    await updateScrapeStatus({
      phase: "error",
      statusMessage: "Failed to start scrape",
      error: errorMessage
    });
    if (scraperTabId) {
      chrome.tabs.remove(scraperTabId).catch(() => {
      });
      scraperTabId = null;
    }
    throw error;
  }
}
async function handleGetWordleBotScrapeStatus() {
  console.log("[Background] GET_WORDLE_BOT_SCRAPE_STATUS requested, returning:", currentScrapeStatus);
  return {
    success: true,
    status: {
      ...currentScrapeStatus
    }
  };
}
async function handleBulkImportGames(games) {
  try {
    console.log(`[Background] =====> handleBulkImportGames called with ${games.length} games`);
    const startTime = performance.now();
    if (!storageService) {
      console.log(`[Background] =====> Initializing storage service...`);
      storageService = ExtensionStorage.getInstance();
      await storageService.initialize();
      console.log(`[Background] =====> Storage service initialized`);
    }
    console.log(`[Background] =====> Calling storageService.bulkImportGames...`);
    const result = await storageService.bulkImportGames(games);
    const duration = (performance.now() - startTime).toFixed(0);
    console.log(`[Background] =====> Bulk import complete in ${duration}ms:`, result);
    const allGames = await storageService.getAllGames();
    await updateExtensionBadge(allGames);
    return { success: true, ...result };
  } catch (error) {
    console.error("[Background] Failed to bulk import games:", error);
    return { success: false, imported: 0, duplicates: 0, errors: games.length };
  }
}
async function handleWordleBotScrapeProgress(message) {
  console.log("[Background] Scrape progress:", message);
  const progressStatusMessage = (() => {
    const gamesFound = message.gamesFound ?? currentScrapeStatus.gamesFound ?? 0;
    const gamesProcessed = message.gamesProcessed ?? currentScrapeStatus.gamesProcessed ?? 0;
    switch (message.status) {
      case "ready":
        return gamesFound > 0 ? `Found ${gamesFound} game${gamesFound === 1 ? "" : "s"}. Preparing import...` : "Preparing import...";
      case "processing":
        return `Processing games (${gamesProcessed}/${gamesFound})`;
      case "processed":
        return "All games processed. Finalizing...";
      case "loading":
        return `Importing ${gamesFound} game${gamesFound === 1 ? "" : "s"}...`;
      default:
        return "Importing games";
    }
  })();
  await updateScrapeStatus({
    phase: "importing",
    gamesFound: message.gamesFound ?? currentScrapeStatus.gamesFound,
    gamesProcessed: message.gamesProcessed ?? currentScrapeStatus.gamesProcessed,
    duplicates: message.duplicatesSkipped ?? currentScrapeStatus.duplicates,
    statusMessage: progressStatusMessage,
    error: null
  });
  chrome.runtime.sendMessage(message).catch(() => {
  });
  return { success: true };
}
async function handleWordleBotScrapeComplete(message) {
  console.log("[Background] Scrape complete:", message);
  const partial = message.errors > 0 && (message.newGames || 0) + (message.duplicates || 0) > 0;
  try {
    if (!storageService) {
      storageService = ExtensionStorage.getInstance();
      await storageService.initialize();
    }
    await storageService.updateScraperMetadata({
      lastScrape: (/* @__PURE__ */ new Date()).toISOString(),
      lastScrapeMode: currentScrapeStatus.mode || "auto",
      totalScraped: message.totalGames,
      lastError: message.errors ? `${message.errors} games failed to import` : ""
    });
  } catch (metadataError) {
    console.error("[Background] Failed to update scraper metadata after completion:", metadataError);
  }
  const completedTabId = scraperTabId;
  if (completedTabId) {
    setTimeout(() => {
      chrome.tabs.remove(completedTabId).catch(() => {
      });
      if (scraperTabId === completedTabId) scraperTabId = null;
    }, 2e3);
  }
  await updateScrapeStatus({
    phase: message.errors ? partial ? "warning" : "error" : "complete",
    gamesFound: message.totalGames ?? currentScrapeStatus.gamesFound,
    gamesProcessed: message.totalGames ?? currentScrapeStatus.gamesProcessed,
    newGames: message.newGames ?? currentScrapeStatus.newGames,
    duplicates: message.duplicates ?? currentScrapeStatus.duplicates,
    errors: message.errors ?? currentScrapeStatus.errors,
    statusMessage: message.errors ? `Import incomplete: ${message.errors} games failed. Retry to fill history.` : message.newGames && message.newGames > 0 ? `Added ${message.newGames} new game${message.newGames === 1 ? "" : "s"}` : "Scrape complete",
    error: message.errors ? "Some games were not saved. Retry the import." : null,
    dateRange: message.dateRange ?? currentScrapeStatus.dateRange
  });
  console.log("[Background] Forwarding COMPLETE message to popup");
  try {
    await chrome.runtime.sendMessage(message);
    console.log("[Background] COMPLETE message forwarded successfully");
  } catch (err) {
    console.log("[Background] Could not forward to popup:", err);
  }
  const completedAt = currentScrapeStatus.lastUpdated;
  setTimeout(() => {
    if (currentScrapeStatus.phase !== "complete" || currentScrapeStatus.lastUpdated !== completedAt) return;
    updateScrapeStatus({
      phase: "idle",
      gamesFound: 0,
      gamesProcessed: 0,
      newGames: 0,
      duplicates: 0,
      errors: 0,
      statusMessage: "Idle",
      error: null,
      dateRange: null,
      mode: null
    }).catch(() => {
    });
  }, 5e3);
  return { success: true };
}
async function handleWordleBotScrapeError(message) {
  console.error("[Background] Scrape error:", message);
  try {
    if (!storageService) {
      storageService = ExtensionStorage.getInstance();
      await storageService.initialize();
    }
    await storageService.updateScraperMetadata({
      lastError: message.error
    });
  } catch (metadataError) {
    console.error("[Background] Failed to update scraper metadata after error:", metadataError);
  }
  if (scraperTabId) {
    chrome.tabs.remove(scraperTabId).catch(() => {
    });
    scraperTabId = null;
  }
  await updateScrapeStatus({
    phase: "error",
    statusMessage: message.error ? `Scrape failed: ${message.error}` : "Scrape failed",
    error: message.error ?? "Unknown error",
    errors: currentScrapeStatus.errors + 1
  });
  chrome.runtime.sendMessage(message).catch(() => {
  });
  return { success: true };
}
async function updateExtensionBadge(games) {
  try {
    const statistics = calculateStatistics(games);
    const streak = statistics.currentStreak;
    if (streak > 0) {
      chrome.action.setBadgeText({
        text: streak.toString()
      });
      chrome.action.setBadgeBackgroundColor({
        color: "#22c55e"
      });
    } else {
      chrome.action.setBadgeText({ text: "" });
    }
  } catch (error) {
    console.error("[Background] Failed to update badge:", error);
  }
}
function filterGamesByTimeFrame(games, timeFrame) {
  if (timeFrame === "all") return games;
  const now = /* @__PURE__ */ new Date();
  const cutoffDate = /* @__PURE__ */ new Date();
  switch (timeFrame) {
    case "7d":
      cutoffDate.setDate(now.getDate() - 7);
      break;
    case "30d":
      cutoffDate.setDate(now.getDate() - 30);
      break;
    case "90d":
      cutoffDate.setDate(now.getDate() - 90);
      break;
    default:
      return games;
  }
  console.log(`[BACKGROUND DEBUG] filterGamesByTimeFrame: Cutoff date for ${timeFrame}: ${cutoffDate.toISOString()}`);
  const filtered = games.filter((game) => {
    if (!game.date) return false;
    const gameDate = new Date(game.date);
    return gameDate >= cutoffDate;
  });
  console.log(`[BACKGROUND DEBUG] filterGamesByTimeFrame: Filtered ${filtered.length} games from ${games.length} total (cutoff: ${cutoffDate.toISOString()})`);
  return filtered;
}
function calculateStatistics(games, allGames) {
  if (games.length === 0) {
    return {
      winRate: 0,
      averageGuesses: 0,
      currentStreak: 0,
      maxStreak: 0,
      gameCount: 0,
      winCount: 0,
      guessDistribution: [0, 0, 0, 0, 0, 0, 0]
    };
  }
  const getAttemptCount = (game) => {
    if (typeof game.attempts === "number") return game.attempts;
    if (typeof game.guesses === "number") return game.guesses;
    if (typeof game.steps === "number") return game.steps;
    return 0;
  };
  const playedGames = games.filter((game) => getAttemptCount(game) > 0);
  if (playedGames.length === 0) {
    return {
      winRate: 0,
      averageGuesses: 0,
      currentStreak: 0,
      maxStreak: 0,
      gameCount: 0,
      winCount: 0,
      guessDistribution: [0, 0, 0, 0, 0, 0, 0]
    };
  }
  const wins = playedGames.filter((game) => game.won);
  const winRate = wins.length / playedGames.length * 100;
  const totalGuesses = wins.reduce((sum, game) => sum + getAttemptCount(game), 0);
  const averageGuesses = wins.length > 0 ? totalGuesses / wins.length : 0;
  const guessDistribution = [0, 0, 0, 0, 0, 0, 0];
  for (const game of playedGames) {
    const attempts = getAttemptCount(game);
    if (!game.won) {
      guessDistribution[6] = (guessDistribution[6] ?? 0) + 1;
      continue;
    }
    if (attempts >= 1 && attempts <= 6) {
      const index = attempts - 1;
      guessDistribution[index] = (guessDistribution[index] ?? 0) + 1;
    }
  }
  const gamesToUseForStreaks = allGames || games;
  const playedGamesForStreaks = gamesToUseForStreaks.filter(
    (game) => getAttemptCount(game) > 0
  );
  const sortedAllGames = [...playedGamesForStreaks].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );
  let currentStreak = 0;
  for (let i = sortedAllGames.length - 1; i >= 0; i--) {
    if (sortedAllGames[i].won) {
      currentStreak++;
    } else {
      break;
    }
  }
  let maxStreak = 0;
  let tempStreak = 0;
  for (let i = 0; i < sortedAllGames.length; i++) {
    if (sortedAllGames[i].won) {
      tempStreak++;
      maxStreak = Math.max(maxStreak, tempStreak);
    } else {
      tempStreak = 0;
    }
  }
  console.log(`[BACKGROUND DEBUG] calculateStatistics: Using ${gamesToUseForStreaks.length} games for streaks, ${playedGames.length} played games for other stats`);
  console.log(`[BACKGROUND DEBUG] calculateStatistics: currentStreak=${currentStreak}, maxStreak=${maxStreak}`);
  return {
    winRate,
    averageGuesses,
    currentStreak,
    maxStreak,
    gameCount: playedGames.length,
    winCount: wins.length,
    guessDistribution
  };
}
function compareVersions(version1, version2) {
  const v1parts = version1.split(".").map(Number);
  const v2parts = version2.split(".").map(Number);
  for (let i = 0; i < Math.max(v1parts.length, v2parts.length); i++) {
    const v1part = v1parts[i] || 0;
    const v2part = v2parts[i] || 0;
    if (v1part < v2part) return -1;
    if (v1part > v2part) return 1;
  }
  return 0;
}
async function migrateToV1() {
  console.log("[Background] Migrating to version 1.0.0");
}
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === dashboardTabId) {
    dashboardTabId = null;
  }
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tabId === dashboardTabId && tab.url && !tab.url.includes("dashboard.html")) {
    dashboardTabId = null;
  }
  if (changeInfo.status === "complete" && tab.url && tab.url.includes("dashboard.html")) {
    dashboardTabId = tabId;
  }
});
async function handleOpenDashboardTab(_message) {
  const dashboardUrl = chrome.runtime.getURL("dashboard.html");
  const destination = dashboardUrl + (_message.page === "play" ? "#/play" : "");
  const dashboardPattern = `chrome-extension://${chrome.runtime.id}/dashboard.html*`;
  if (dashboardTabId !== null) {
    try {
      const existingTab = await chrome.tabs.get(dashboardTabId);
      if (existingTab?.url?.startsWith(dashboardUrl) && existingTab.id !== void 0) {
        if (existingTab.windowId !== void 0) {
          await chrome.windows.update(existingTab.windowId, { focused: true });
        }
        await chrome.tabs.update(existingTab.id, { active: true, ..._message.page === "play" ? { url: destination } : {} });
        if (_message.page !== "play") await chrome.tabs.reload(existingTab.id);
        return { success: true, reused: true, tabId: existingTab.id };
      }
    } catch {
      dashboardTabId = null;
    }
  }
  try {
    const matchingTabs = await chrome.tabs.query({ url: [dashboardPattern] });
    const tabToUse = matchingTabs.find((tab) => tab.id !== void 0);
    if (tabToUse && tabToUse.id !== void 0) {
      dashboardTabId = tabToUse.id;
      if (tabToUse.windowId !== void 0) {
        await chrome.windows.update(tabToUse.windowId, { focused: true });
      }
      await chrome.tabs.update(tabToUse.id, { active: true, ..._message.page === "play" ? { url: destination } : {} });
      if (_message.page !== "play") await chrome.tabs.reload(tabToUse.id);
      return { success: true, reused: true, tabId: tabToUse.id };
    }
  } catch (queryError) {
    errorLog2("[Background] Failed to query dashboard tabs:", queryError);
  }
  const createdTab = await chrome.tabs.create({ url: destination });
  dashboardTabId = createdTab.id ?? null;
  return { success: true, reused: false, tabId: createdTab.id ?? void 0 };
}
